﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources;

public record Blockade
{
    public Guid OwnerId { get; }

    public DateTime? DateTo { get; }
    
    private Blockade(Guid ownerId, DateTime? dateTo)
    {
        OwnerId = ownerId;
        DateTo = dateTo;
    }
    
    public static Blockade CreateTemporary(Guid ownerId, TimeSpan timeSpan)
    {
        return new Blockade(ownerId, SystemClock.Now.Add(timeSpan));
    }
    
    public static Blockade CreatePermanent(Guid ownerId)
    {
        return new Blockade(ownerId, null);
    }

    public bool HasBlockadeForDifferentOwner(Guid ownerId)
    {
        if (ownerId != this.OwnerId)
        {
            if (DateTo == null)
            {
                return true;
            }

            if (SystemClock.Now <= DateTo)
            {
                return true;
            }
        }

        return false;
    }
}