CREATE TABLE availability.resources (
    id UUID NOT NULL,
    is_withdrawn BOOL NOT NULL,
    blockade_owner_id UUID NULL,
    blockade_date_to TIMESTAMP NULL,
    CONSTRAINT pk_availability_resources_id PRIMARY KEY (id)
);