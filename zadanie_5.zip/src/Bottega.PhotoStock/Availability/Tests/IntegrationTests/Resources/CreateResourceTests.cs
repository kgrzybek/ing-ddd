﻿using Bottega.PhotoStock.Availability.Application.Resources.CreateResource;
using Bottega.PhotoStock.Availability.Application.Resources.GetResource;
using Bottega.PhotoStock.Availability.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Availability.IntegrationTests.Resources;

[TestFixture]
public class CreateResourceTests : TestBase
{
    [Test]
    public async Task WhenCreateResource_ThenIsCreated()
    {
        // When
        var resourceId = Guid.NewGuid();
        await AvailabilityModule.ExecuteCommand(new CreateResourceCommand(resourceId));

        // Then
        var resource = await AvailabilityModule.ExecuteQuery(new GetResourceQuery(resourceId));
        resource.IsWithdrawn.Should().BeFalse();
        resource.ResourceId.Should().Be(resourceId);
        resource.BlockadeDateTo.Should().BeNull();
        resource.BlockadeOwnerId.Should().BeNull();
    }
}