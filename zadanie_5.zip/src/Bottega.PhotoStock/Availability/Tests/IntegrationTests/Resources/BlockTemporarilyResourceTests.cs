﻿using Availability.Domain.Resources.Rules;
using Bottega.PhotoStock.Availability.Application.Resources.BlockTemporarily;
using Bottega.PhotoStock.Availability.Application.Resources.CreateResource;
using Bottega.PhotoStock.Availability.Application.Resources.GetResource;
using Bottega.PhotoStock.Availability.IntegrationTests.SeedWork;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using FluentAssertions;

namespace Bottega.PhotoStock.Availability.IntegrationTests.Resources;

[TestFixture]
public class BlockTemporarilyResourceTests : TestBase
{
    [Test]
    public async Task GivenResource_WhenBlockTemporarily_ThenIsBlocked()
    {
        // Given
        var resourceId = Guid.NewGuid();
        await AvailabilityModule.ExecuteCommand(new CreateResourceCommand(resourceId));
        var currentDate = new DateTime(2023, 2, 2);
        SystemClock.Set(currentDate);
        var ownerId = Guid.NewGuid();
        
        // When
        await AvailabilityModule.ExecuteCommand(new BlockTemporarilyCommand(
            resourceId,
            ownerId,
            TimeSpan.FromHours(1)));

        // Then
        var resource = await AvailabilityModule.ExecuteQuery(new GetResourceQuery(resourceId));
        resource.IsWithdrawn.Should().BeFalse();
        resource.ResourceId.Should().Be(resourceId);
        resource.BlockadeDateTo.Should().Be(currentDate.Add(TimeSpan.FromHours(1)));
        resource.BlockadeOwnerId.Should().Be(ownerId);
    }
    
    [Test]
    public async Task GivenResourceBlockedTemporarily_AndBlockadeNotExpired_WhenBlockTemporarilyByDiffOwner_ThenCannotBeBlocked()
    {
        // Given
        var resourceId = Guid.NewGuid();
        await AvailabilityModule.ExecuteCommand(new CreateResourceCommand(resourceId));
        var currentDate = new DateTime(2023, 2, 2);
        SystemClock.Set(currentDate);
        var ownerId = Guid.NewGuid();
        
        await AvailabilityModule.ExecuteCommand(new BlockTemporarilyCommand(
            resourceId,
            ownerId,
            TimeSpan.FromHours(1)));
        
        // When
        SystemClock.Set(currentDate.AddMinutes(30));
        var differentOwnerId = Guid.NewGuid();
        
        Func<Task> blockTemporarily = async () => await AvailabilityModule.ExecuteCommand(new BlockTemporarilyCommand(
            resourceId,
            differentOwnerId,
            TimeSpan.FromHours(1)));
        
        // Then
        await blockTemporarily.Should().ThrowAsync<BusinessRuleValidationException>()
            .Where(x => 
                x.BrokenRule.GetType() == typeof(ThereAreNoOtherBlockadesRule));
    }
}