﻿using Availability.Domain.Resources;
using FluentAssertions;
using NUnit.Framework;

namespace Availability.Domain.UnitTests.Resources.Blockades;

[TestFixture]
public class BlockadeTests
{
    [Test]
    public void GivenPermanentBlockade_WhenCheckWhetherHasBlockadeForDifferentOwner_ThenReturnTrue()
    {
        // Given
        var ownerId = Guid.NewGuid();
        var blockade = Blockade.CreatePermanent(ownerId);
        
        // When
        var differentOwnerId = Guid.NewGuid();
        var hasBlockadeForDifferentOwner = blockade.HasBlockadeForDifferentOwner(differentOwnerId);
        
        // Then
        hasBlockadeForDifferentOwner.Should().BeTrue();
    }
    
    [Test]
    public void GivenPermanentBlockade_WhenCheckWhetherHasBlockadeForTheSameOwner_ThenReturnFalse()
    {
        // Given
        var ownerId = Guid.NewGuid();
        var blockade = Blockade.CreatePermanent(ownerId);
        
        // When
        var hasBlockadeForDifferentOwner = blockade.HasBlockadeForDifferentOwner(ownerId);
        
        // Then
        hasBlockadeForDifferentOwner.Should().BeFalse();
    }
    
    [Test]
    public void GivenTemporaryBlockade_WhenCheckWhetherHasBlockadeForDifferentOwner_ThenReturnTrue()
    {
        // Given
        var ownerId = Guid.NewGuid();
        var blockade = Blockade.CreateTemporary(ownerId, TimeSpan.FromHours(1));
        
        // When
        var differentOwnerId = Guid.NewGuid();
        var hasBlockadeForDifferentOwner = blockade.HasBlockadeForDifferentOwner(differentOwnerId);
        
        // Then
        hasBlockadeForDifferentOwner.Should().BeTrue();
    }
    
    [Test]
    public void GivenTemporaryBlockade_WhenCheckWhetherHasBlockadeForTheSameOwner_ThenReturnFalse()
    {
        // Given
        var ownerId = Guid.NewGuid();
        var blockade = Blockade.CreateTemporary(ownerId, TimeSpan.FromHours(1));
        
        // When
        var hasBlockadeForDifferentOwner = blockade.HasBlockadeForDifferentOwner(ownerId);
        
        // Then
        hasBlockadeForDifferentOwner.Should().BeFalse();
    }
}