﻿using Availability.Domain.Resources;
using Availability.Domain.Resources.Events;
using Availability.Domain.Resources.Rules;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.DomainTests;
using FluentAssertions;
using NUnit.Framework;

namespace Availability.Domain.UnitTests.Resources;

[TestFixture]
public class UnblockTests
{
    [Test]
    public void GivenResourceBlockedTemporarily_WhenUnblockByTheSameOwner_ThenIsUnblocked()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());
        
        SystemClock.Set(new DateTime(2023, 1, 10, 11, 0 , 0));
        var ownerId = Guid.NewGuid();
        var time = TimeSpan.FromHours(1);
        resource.BlockTemporarily(ownerId, time);
        
        // When
        resource.Unblock(ownerId);
        
        // Then
        resource.Should().PublishDomainEvent<ResourceUnblockedDomainEvent>();
    }
    
    [Test]
    public void GivenResourceBlockedTemporarily_WhenUnblockByDifferentOwner_ThenCannotBeUnblocked()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());
        
        SystemClock.Set(new DateTime(2023, 1, 10, 11, 0 , 0));
        var ownerId = Guid.NewGuid();
        var time = TimeSpan.FromHours(1);
        resource.BlockTemporarily(ownerId, time);
        
        // When
        var anotherOwnerId = Guid.NewGuid();
        Action blockTemporarily = () => resource.Unblock(anotherOwnerId);
        
        // Then
        blockTemporarily.Should().BreakRule<ThereAreNoOtherBlockadesRule>();
    }
}