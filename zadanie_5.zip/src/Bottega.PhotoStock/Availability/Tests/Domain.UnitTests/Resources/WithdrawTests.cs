﻿using Availability.Domain.Resources;
using Availability.Domain.Resources.Events;
using Bottega.PhotoStock.BuildingBlocks.DomainTests;
using FluentAssertions;
using NUnit.Framework;

namespace Availability.Domain.UnitTests.Resources;

[TestFixture]
public class WithdrawTests
{
    [Test]
    public void GivenNewResource_WhenWithdraw_ThenIsWithdrawn()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());
        
        // When
        resource.Withdraw();
        
        // Then
        resource.Should().PublishDomainEvent<ResourceWithdrawnDomainEvent>();
    }
}