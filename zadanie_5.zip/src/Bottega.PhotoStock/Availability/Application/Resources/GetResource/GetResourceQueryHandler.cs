using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Dapper;

namespace Bottega.PhotoStock.Availability.Application.Resources.GetResource;

public class GetResourceQueryHandler : IQueryHandler<GetResourceQuery, ResourceDto>
{
    private readonly IDbConnectionFactory _connectionFactory;

    public GetResourceQueryHandler(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<ResourceDto> Handle(GetResourceQuery query, CancellationToken cancellationToken)
    {
        var connection = _connectionFactory.GetOpenConnection();

        const string sql = $@"SELECT 
                        resource.id {nameof(ResourceDto.ResourceId)},
                        resource.is_withdrawn {nameof(ResourceDto.IsWithdrawn)},
                        resource.blockade_date_to {nameof(ResourceDto.BlockadeDateTo)},
                        resource.blockade_owner_id {nameof(ResourceDto.BlockadeOwnerId)}
                    FROM availability.resources resource 
                    WHERE resource.id = :resourceId";

        return await connection.QuerySingleAsync<ResourceDto>(sql, new
        {
            query.ResourceId
        });
    }
}