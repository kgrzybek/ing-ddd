﻿using System.Reflection;
using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;
using MediatR.Extensions.Autofac.DependencyInjection;
using Module = Autofac.Module;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Mediation;
    
public class MediatorModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterScope<UnitOfWork, IUnitOfWork>();

        var assemblies = new List<Assembly> { Assemblies.Application, Assemblies.Infrastructure };

        builder.RegisterMediatR(assemblies);
        builder.RegisterHandlerDecorators();
    }
}
