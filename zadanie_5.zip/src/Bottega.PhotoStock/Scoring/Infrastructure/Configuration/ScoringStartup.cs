﻿using Autofac;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Mediation;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration;

public static class ScoringStartup
{
    private static IContainer? _container;

    public static void Initialize(
        string connectionString)
    {
        ConfigureCompositionRoot(
            connectionString);
    }

    private static void ConfigureCompositionRoot(
        string connectionString)
    {
        var containerBuilder = new ContainerBuilder();
        
        containerBuilder.RegisterModule(new DataAccessModule(connectionString));
        containerBuilder.RegisterModule(new MediatorModule());

        _container = containerBuilder.Build();

        ScoringCompositionRoot.SetContainer(_container);
    }
}