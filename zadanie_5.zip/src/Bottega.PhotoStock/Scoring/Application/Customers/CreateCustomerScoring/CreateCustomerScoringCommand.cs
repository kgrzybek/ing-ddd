﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Application.Customers.CreateCustomerScoring;

public class CreateCustomerScoringCommand : CommandBase
{
    public CreateCustomerScoringCommand(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}