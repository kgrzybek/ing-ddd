﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Application.Customers.ChangeCustomerScoring;

public class ChangeCustomerScoringCommand : CommandBase
{
    public ChangeCustomerScoringCommand(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}