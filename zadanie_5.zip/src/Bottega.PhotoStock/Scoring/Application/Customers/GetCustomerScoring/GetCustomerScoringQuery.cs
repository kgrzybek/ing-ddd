﻿using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Scoring.Application.Customers.GetCustomerScoring;

public class GetCustomerScoringQuery : QueryBase<CustomerScoringDto>
{
    public GetCustomerScoringQuery(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}