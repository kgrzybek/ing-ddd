namespace Bottega.PhotoStock.Scoring.Application.Customers.GetCustomerScoring;

public class CustomerScoringDto
{
    public Guid CustomerId { get; set; }
    
    public decimal LoanLimitValue { get; set; }
    
    public string LoanLimitCurrencyCode { get; set; }
}