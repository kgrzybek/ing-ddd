﻿using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

namespace Bottega.PhotoStock.Scoring.Domain.Customers;

public class LoanLimitConfiguration
{
    public LoanLimitConfiguration(
        Percentage percentageOfTotalOrders,
        CurrentLoanLimitConfiguration configuration)
    {
        _percentageOfTotalOrders = percentageOfTotalOrders;
        _currentConfiguration = configuration;
        Id = Guid.NewGuid();
    }

    private LoanLimitConfiguration()
    {
        // Only for EF.
    }

    public Guid Id { get; private set; }

    private Percentage _percentageOfTotalOrders;
    
    private CurrentLoanLimitConfiguration _currentConfiguration;

    public static LoanLimitConfiguration Create(
        Percentage percentageOfTotalOrders,
        CurrentLoanLimitConfiguration configuration)
    {
        return new LoanLimitConfiguration(percentageOfTotalOrders, configuration);
    }
}