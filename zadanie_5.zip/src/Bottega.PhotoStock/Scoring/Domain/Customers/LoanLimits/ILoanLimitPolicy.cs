namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public interface ILoanLimitPolicy
{
    Money Calculate();
}