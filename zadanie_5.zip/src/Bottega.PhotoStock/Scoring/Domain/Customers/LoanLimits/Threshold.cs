namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public record Threshold(Money From, Money To, Money LoanLimit);