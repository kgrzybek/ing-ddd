﻿using Bottega.PhotoStock.Scoring.Application.Customers.CreateCustomerScoring;
using Bottega.PhotoStock.Scoring.Application.Customers.GetCustomerScoring;
using Bottega.PhotoStock.Scoring.IntegrationTests.SeedWork;
using FluentAssertions;
using NUnit.Framework;

namespace Bottega.PhotoStock.Scoring.IntegrationTests.Customers;

public class CreateCustomerScoringTests : TestBase
{
    [Test]
    public async Task WhenCreateCustomerScoring_ThenIsCreated()
    {
        // When
        var customerId = Guid.NewGuid();
        await ScoringModule.ExecuteCommand(new CreateCustomerScoringCommand(customerId));
        
        // Then
        var scoring = await ScoringModule.ExecuteQuery(new GetCustomerScoringQuery(customerId));
        scoring.CustomerId.Should().Be(customerId);
        scoring.LoanLimitValue.Should().Be(0);
        scoring.LoanLimitCurrencyCode.Should().Be("PLN");
    }
}