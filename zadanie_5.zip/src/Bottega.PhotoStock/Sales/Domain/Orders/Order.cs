﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Bottega.PhotoStock.Sales.Domain.Orders.Events;

namespace Bottega.PhotoStock.Sales.Domain.Orders;

public class Order : Entity
{
    private Order(Guid customerId, Money beforeDiscountValue, Money discount, Money afterDiscountValue)
    {
        CustomerId = customerId;
        _discount = discount;
        _beforeDiscountValue = beforeDiscountValue;
        _afterDiscountValue = afterDiscountValue;
        
        this.AddDomainEvent(new OrderCreatedDomainEvent(
            CustomerId,
            _beforeDiscountValue.Amount, 
            _discount.Amount,
            _afterDiscountValue.Amount));
    }

    public Guid CustomerId { get; }

    private Money _discount;

    private Money _beforeDiscountValue;

    private Money _afterDiscountValue;

    public static Order Create(
        Guid customerId,
        IDiscountPolicy discountPolicy,
        List<OrderLine> orderLines)
    {
        var beforeDiscountValue = OrderCalculator.CalculateBeforeDiscountValue(orderLines);
        var discount = discountPolicy.Calculate(orderLines);
        var afterDiscountValue = beforeDiscountValue - discount;
        
        return new Order(customerId, beforeDiscountValue, discount, afterDiscountValue);
    }
}