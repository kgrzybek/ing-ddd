namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public class NoDiscountPolicy : IDiscountPolicy
{
    public Money Calculate(List<OrderLine> orderLines)
    {
        return Money.Of(0);
    }
}