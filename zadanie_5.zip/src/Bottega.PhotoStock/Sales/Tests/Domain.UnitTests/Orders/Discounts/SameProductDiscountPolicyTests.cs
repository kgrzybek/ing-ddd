﻿using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using FluentAssertions;

namespace Bottega.PhotoStock.Sales.Domain.UnitTests.Orders.Discounts;

[TestFixture]
public class SameProductDiscountPolicyTests
{
    [Test]
    public void GivenOneProductWithQuantity2_AndConfigurationIs2_WhenCalculate_ThenDiscountIsApplied()
    {
        // Given
        var policy = new SameProductDiscountPolicy(2, Percentage.Of(10));
        
        var orderLines = new List<OrderLine>();
        orderLines.Add(new OrderLine(Guid.NewGuid(),1, Money.Of(50)));
        orderLines.Add(new OrderLine(Guid.NewGuid(),2, Money.Of(100)));

        // When
        var discount = policy.Calculate(orderLines);
        
        // Then
        discount.Should().Be(Money.Of(10));
    }
    
    [Test]
    public void GivenOneProductWithQuantity3_AndConfigurationIs2_WhenCalculate_ThenDiscountIsApplied()
    {
        // Given
        var policy = new SameProductDiscountPolicy(2, Percentage.Of(10));
        
        var orderLines = new List<OrderLine>();
        orderLines.Add(new OrderLine(Guid.NewGuid(),1, Money.Of(50)));
        orderLines.Add(new OrderLine(Guid.NewGuid(),3, Money.Of(100)));

        // When
        var discount = policy.Calculate(orderLines);
        
        // Then
        discount.Should().Be(Money.Of(10));
    }
    
    [Test]
    public void GivenOneProductWithQuantity4_AndConfigurationIs2_WhenCalculate_ThenDiscountIsAppliedForTwoProducts()
    {
        // Given
        var policy = new SameProductDiscountPolicy(2, Percentage.Of(10));
        
        var orderLines = new List<OrderLine>();
        orderLines.Add(new OrderLine(Guid.NewGuid(),1, Money.Of(50)));
        orderLines.Add(new OrderLine(Guid.NewGuid(),4, Money.Of(100)));

        // When
        var discount = policy.Calculate(orderLines);
        
        // Then
        discount.Should().Be(Money.Of(20));
    }
}