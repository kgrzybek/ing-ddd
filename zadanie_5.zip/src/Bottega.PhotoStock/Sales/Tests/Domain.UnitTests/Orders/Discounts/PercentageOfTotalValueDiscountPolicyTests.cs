﻿using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using FluentAssertions;

namespace Bottega.PhotoStock.Sales.Domain.UnitTests.Orders.Discounts;

[TestFixture]
public class PercentageOfTotalValueDiscountPolicyTests
{
    [Test]
    public void PercentageOfTotalValueDiscountPolicy_WhenCalculate_ThenDiscountIsPercentageOfOnTotalValue()
    {
        // Given
        var policy = new PercentageOfTotalValueDiscountPolicy(Percentage.Of(10));
        
        var orderLines = new List<OrderLine>();
        orderLines.Add(new OrderLine(Guid.NewGuid(),1, Money.Of(50)));
        orderLines.Add(new OrderLine(Guid.NewGuid(),2, Money.Of(100)));

        // When
        var discount = policy.Calculate(orderLines);
        
        // Then
        discount.Should().Be(Money.Of(25));
    }
}