﻿using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using FluentAssertions;

namespace Bottega.PhotoStock.Sales.Domain.UnitTests.Orders.Discounts;

[TestFixture]
public class DiscountPolicyFactoryTests
{
    [Test]
    public void GivenNoDiscountIsConfigured_WhenCreateDiscountPolicy_ThenNoDiscountIsCreated()
    {
        // When
        var discountPolicy = DiscountPolicyFactory.Create(
            DiscountPolicyConfiguration.NoDiscount,
            2,
            Percentage.Of(10),
            Percentage.Of(20)
        );
        
        // Then
        discountPolicy.Should().BeOfType(typeof(NoDiscountPolicy));
    }
    
    [Test]
    public void GivenSameProductDiscountIsConfigured_WhenCreateDiscountPolicy_ThenSameProductDiscountIsCreated()
    {
        // When
        var discountPolicy = DiscountPolicyFactory.Create(
            DiscountPolicyConfiguration.SameProduct,
            2,
            Percentage.Of(10),
            Percentage.Of(20)
        );
        
        // Then
        discountPolicy.Should().BeOfType(typeof(SameProductDiscountPolicy));
    }
    
    [Test]
    public void GivenPercentageOfTotalValueDiscountPolicyIsConfigured_WhenCreateDiscountPolicy_ThenPercentageOfTotalValueDiscountPolicyIsCreated()
    {
        // When
        var discountPolicy = DiscountPolicyFactory.Create(
            DiscountPolicyConfiguration.PercentageOfTotalValue,
            2,
            Percentage.Of(10),
            Percentage.Of(20)
        );
        
        // Then
        discountPolicy.Should().BeOfType(typeof(PercentageOfTotalValueDiscountPolicy));
    }
}