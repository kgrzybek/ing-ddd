﻿namespace Bottega.PhotoStock.Payments.Domain;

public record Money
{
    public decimal Amount { get; }
    
    public string CurrencyCode { get; }

    private Money(decimal amount, string currencyCode)
    {
        Amount = amount;
        CurrencyCode = currencyCode;
    }
    
    public static Money Of(decimal value, string currencyCode)
    {
        return new Money(value, currencyCode);
    }

    public static Money operator +(Money left, Money right)
    {
        if (left.CurrencyCode != right.CurrencyCode)
        {
            throw new ArgumentException("Currencies don't match.");
        }
        
        return Of(left.Amount + right.Amount, left.CurrencyCode);
    }
    
    public static Money operator -(Money left, Money right)
    {
        if (left.CurrencyCode != right.CurrencyCode)
        {
            throw new ArgumentException("Currencies don't match.");
        }
        
        return Of(left.Amount - right.Amount, left.CurrencyCode);
    }
}