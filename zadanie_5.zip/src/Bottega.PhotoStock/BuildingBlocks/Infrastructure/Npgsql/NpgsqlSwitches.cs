﻿namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Npgsql;

public static class NpgsqlSwitches
{
    public static void RegisterEnableLegacyTimestampBehavior()
    {
        // Allow to save DateTime without Kind=UTC in database.
        AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
    }
}