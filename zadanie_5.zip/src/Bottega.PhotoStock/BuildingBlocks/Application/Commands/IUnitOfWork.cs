namespace Bottega.PhotoStock.BuildingBlocks.Application.Commands;

public interface IUnitOfWork
{
    Task<int> CommitAsync(CancellationToken cancellationToken);
}