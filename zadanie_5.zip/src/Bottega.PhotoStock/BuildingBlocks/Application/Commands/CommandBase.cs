﻿namespace Bottega.PhotoStock.BuildingBlocks.Application.Commands;

public abstract class CommandBase : ICommand
{
    public Guid Id { get; private set; }

    protected CommandBase()
    {
        this.Id = Guid.NewGuid();
    }

    protected CommandBase(Guid id)
    {
        this.Id = id;
    }
}

public abstract class CommandBase<TResult> : ICommand<TResult>
{
    public Guid Id { get; private set; }

    protected CommandBase()
    {
        this.Id = Guid.NewGuid();
    }
    
    protected CommandBase(Guid id)
    {
        this.Id = id;
    }
}