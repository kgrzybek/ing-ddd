namespace Bottega.PhotoStock.BuildingBlocks.Domain;

public interface IRepository
{
}