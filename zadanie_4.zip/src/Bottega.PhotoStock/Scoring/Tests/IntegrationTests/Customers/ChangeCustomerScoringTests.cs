﻿using Bottega.PhotoStock.Scoring.Application.Customers.ChangeCustomerScoring;
using Bottega.PhotoStock.Scoring.Application.Customers.CreateCustomerScoring;
using Bottega.PhotoStock.Scoring.Application.Customers.CreateLoanLimitConfiguration;
using Bottega.PhotoStock.Scoring.Application.Customers.GetCustomerScoring;
using Bottega.PhotoStock.Scoring.Application.Customers.Orders.RegisterOrder;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Bottega.PhotoStock.Scoring.IntegrationTests.SeedWork;
using FluentAssertions;
using NUnit.Framework;

namespace Bottega.PhotoStock.Scoring.IntegrationTests.Customers;

public class ChangeCustomerScoringTests : TestBase
{
    [Test]
    public async Task GivenLoanLimitConfigurationSetToPercentage_AndTwoCustomerOrders_WhenChangeScoring_ThenLoanLimitIsSet()
    {
        // Given
        var customerId = Guid.NewGuid();
        
        await ScoringModule.ExecuteCommand(new CreateLoanLimitConfigurationCommand(
            0.1m,
            CurrentLoanLimitConfiguration.Percentage.Code));
        
        await ScoringModule.ExecuteCommand(new CreateCustomerScoringCommand(customerId));

        await ScoringModule.ExecuteCommand(new RegisterOrderCommand(
            Guid.NewGuid(),
            customerId,
            100,
            "PLN"));
        
        await ScoringModule.ExecuteCommand(new RegisterOrderCommand(
            Guid.NewGuid(),
            customerId,
            400,
            "PLN"));

        // When
        await ScoringModule.ExecuteCommand(new ChangeCustomerScoringCommand(customerId));
        
        // Then
        var scoring = await ScoringModule.ExecuteQuery(new GetCustomerScoringQuery(customerId));
        scoring.CustomerId.Should().Be(customerId);
        scoring.LoanLimitValue.Should().Be(50);
        scoring.LoanLimitCurrencyCode.Should().Be("PLN");
    }
}