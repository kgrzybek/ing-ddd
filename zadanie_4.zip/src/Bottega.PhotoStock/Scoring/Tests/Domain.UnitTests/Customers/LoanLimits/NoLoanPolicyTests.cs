using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using FluentAssertions;

namespace Bottega.PhotoStock.Scoring.Domain.UnitTests.Customers.LoanLimits;

[TestFixture]
public class NoLoanPolicyTests
{
    [Test]
    public void WhenNoLoanPolicy_ThenLoanLimitIsZero()
    {
        // Given
        var noLoanPolicy = new NoLoanPolicy();
        
        // When
        var loanLimit = noLoanPolicy.Calculate();
        
        // Then
        loanLimit.Should().Be(Money.Of(0));
    }
}