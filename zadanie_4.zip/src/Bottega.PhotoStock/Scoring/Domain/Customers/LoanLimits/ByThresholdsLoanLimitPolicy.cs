namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public class ByThresholdsLoanLimitPolicy : ILoanLimitPolicy
{
    private readonly List<Threshold> _thresholds;

    private readonly List<OrderData> _orders;

    public ByThresholdsLoanLimitPolicy(List<Threshold> thresholds, List<OrderData> orders)
    {
        _thresholds = thresholds;
        _orders = orders;
    }

    public Money Calculate()
    {
        var allOrdersValue = _orders.Select(x => x.Value).Sum();

        var threshold = _thresholds.Single(x => x.From <= allOrdersValue && x.To >= allOrdersValue);

        return threshold.LoanLimit;
    }
}