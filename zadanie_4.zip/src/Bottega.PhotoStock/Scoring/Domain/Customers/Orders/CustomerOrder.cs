﻿using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.Orders;

public class CustomerOrder
{
    public Guid OrderId { get; private set; }

    private Guid _customerId;

    private Money _orderValue;

    private CustomerOrder()
    {
        // Only for EF.
    }

    public CustomerOrder(
        Guid orderId,
        Guid customerId,
        Money orderValue)
    {
        OrderId = orderId;
        _customerId = customerId;
        _orderValue = orderValue;
    }

    public static CustomerOrder RegisterOrder(Guid orderId, Guid customerId, Money value)
    {
        return new CustomerOrder(orderId, customerId, value);
    }
}