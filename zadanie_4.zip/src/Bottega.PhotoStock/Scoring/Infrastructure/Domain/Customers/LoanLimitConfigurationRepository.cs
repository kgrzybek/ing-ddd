﻿using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Domain.Customers;

public class LoanLimitConfigurationRepository : ILoanLimitConfigurationRepository
{
    private readonly ScoringContext _scoringContext;

    public LoanLimitConfigurationRepository(ScoringContext scoringContext)
    {
        _scoringContext = scoringContext;
    }

    public async Task Add(LoanLimitConfiguration loanLimitConfiguration)
    {
        await _scoringContext.LoanLimitConfigurations.AddAsync(loanLimitConfiguration);
    }
}