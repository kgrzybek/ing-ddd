using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;

public class UnitOfWork : IUnitOfWork
{
    private readonly DbContext _context;

    public UnitOfWork(
        DbContext context)
    {
        _context = context;
    }
    
    public async Task<int> CommitAsync(CancellationToken cancellationToken)
    {
        var result = await _context.SaveChangesAsync(cancellationToken);

        return result;
    }
}