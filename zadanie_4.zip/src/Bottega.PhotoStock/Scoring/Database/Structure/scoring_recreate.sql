CREATE SCHEMA IF NOT EXISTS scoring AUTHORIZATION "SYSTEM";

DROP TABLE IF EXISTS scoring.blacklist_customers;
CREATE TABLE scoring.blacklist_customers (
    customer_id UUID NOT NULL,
    CONSTRAINT pk_scoring_blacklist_customers_customer_id PRIMARY KEY (customer_id)
);

DROP TABLE IF EXISTS scoring.customer_orders;
CREATE TABLE scoring.customer_orders (
    order_id UUID NOT NULL,
    customer_id UUID NOT NULL,
    order_value DECIMAL(18, 2) NOT NULL,
    order_currency VARCHAR(20) NOT NULL,
    CONSTRAINT pk_scoring_customer_orders_order_id PRIMARY KEY (order_id)
);

DROP TABLE IF EXISTS scoring.customer_scorings;
CREATE TABLE scoring.customer_scorings (
    customer_id UUID NOT NULL,
    loan_limit_value DECIMAL(18, 2) NOT NULL,
    loan_limit_currency VARCHAR(20) NOT NULL,
    CONSTRAINT pk_scoring_customer_scorings_customer_id PRIMARY KEY (customer_id)
);

DROP TABLE IF EXISTS scoring.loan_limit_configurations;
CREATE TABLE scoring.loan_limit_configurations (
   id UUID NOT NULL,
   percentage_total_orders DECIMAL(18, 4) NOT NULL,
   current_configuration_code VARCHAR(20) NOT NULL,
   CONSTRAINT pk_scoring_loan_limit_configurations_id PRIMARY KEY (id)
);

DROP TABLE IF EXISTS scoring.loan_limit_thresholds;
CREATE TABLE scoring.loan_limit_thresholds (
   id UUID NOT NULL,
   from_value DECIMAL(18, 2) NOT NULL,
   from_currency VARCHAR(20) NOT NULL,
   to_value DECIMAL(18, 2) NOT NULL,
   to_currency VARCHAR(20) NOT NULL,
   loan_limit_value DECIMAL(18, 2) NOT NULL,
   loan_limit_currency VARCHAR(20) NOT NULL,
   CONSTRAINT pk_scoring_loan_limit_thresholds_id PRIMARY KEY (id)
);
