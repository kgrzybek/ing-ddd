CREATE TABLE scoring.blacklist_customers (
    customer_id UUID NOT NULL,
    CONSTRAINT pk_scoring_blacklist_customers_customer_id PRIMARY KEY (customer_id)
);