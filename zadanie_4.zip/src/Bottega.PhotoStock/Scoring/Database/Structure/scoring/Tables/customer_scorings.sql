CREATE TABLE scoring.customer_scorings (
    customer_id UUID NOT NULL,
    loan_limit_value DECIMAL(18, 2) NOT NULL,
    loan_limit_currency VARCHAR(20) NOT NULL,
    CONSTRAINT pk_scoring_customer_scorings_customer_id PRIMARY KEY (customer_id)
);