﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Application.Customers.CreateLoanLimitConfiguration;

public class CreateLoanLimitConfigurationCommand : CommandBase
{
    public CreateLoanLimitConfigurationCommand(decimal percentageTotalOrders, string currentConfigurationCode)
    {
        PercentageTotalOrders = percentageTotalOrders;
        CurrentConfigurationCode = currentConfigurationCode;
    }

    public decimal PercentageTotalOrders { get; }
    
    public string CurrentConfigurationCode { get; }
}