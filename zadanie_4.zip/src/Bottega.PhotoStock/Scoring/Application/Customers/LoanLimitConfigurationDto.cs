﻿namespace Bottega.PhotoStock.Scoring.Application.Customers;

public class LoanLimitConfigurationDto
{
    public decimal PercentageTotalOrders { get; set; }
    
    public string CurrentConfigurationCode { get; set; }
}