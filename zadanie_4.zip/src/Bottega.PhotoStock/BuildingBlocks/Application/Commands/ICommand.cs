﻿using MediatR;

namespace Bottega.PhotoStock.BuildingBlocks.Application.Commands;

public interface ICommand<out TResult> : IRequest<TResult>
{
    Guid Id { get; }
}

public interface ICommand : IRequest
{
    Guid Id { get; }
}