﻿namespace Bottega.PhotoStock.Sales.Domain.Orders;

public record OrderLine(Guid ProductId, int Quantity, Money UnitPrice);