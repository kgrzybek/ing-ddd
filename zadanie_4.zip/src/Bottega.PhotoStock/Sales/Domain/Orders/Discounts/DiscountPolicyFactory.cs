﻿namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public static class DiscountPolicyFactory
{
    public static IDiscountPolicy Create(
        DiscountPolicyConfiguration configuration,
        int sameProductsNumber,
        Percentage sameProductsPercentage,
        Percentage percentageOfTotalValue)
    {
        if (configuration == DiscountPolicyConfiguration.SameProduct)
        {
            return new SameProductDiscountPolicy(sameProductsNumber, sameProductsPercentage);
        }

        if (configuration == DiscountPolicyConfiguration.PercentageOfTotalValue)
        {
            return new PercentageOfTotalValueDiscountPolicy(percentageOfTotalValue);
        }

        return new NoDiscountPolicy();
    }
}