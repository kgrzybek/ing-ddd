﻿using Bottega.PhotoStock.Availability.Infrastructure.Configuration;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.IntegrationTests;
using Dapper;

namespace Bottega.PhotoStock.Availability.IntegrationTests.SeedWork;

public class TestBase
{
    private readonly string _connectionString;
    
    protected IDbConnectionFactory DbConnectionFactory { get; }
    
    protected AvailabilityModule AvailabilityModule { get; }
    
    protected TestBase()
    {
        _connectionString = "Host=localhost:9950;Username=SYSTEM;Password=p@ssword111;Database=postgres-db;";
        AvailabilityModule = new AvailabilityModule();
        DbConnectionFactory = new DbConnectionFactory(_connectionString);
    }
    
    [SetUp]
    public async Task BeforeEachTest()
    {
        SystemClock.Reset();

        await ClearDatabase();
        
        AvailabilityStartup.Initialize(_connectionString);
    }

    private async Task ClearDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();

        const string sql = "DELETE FROM availability.resources; ";

        await connection.ExecuteScalarAsync(sql);
    }
}