using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration.DataAccess;

public class AvailabilityContext :
    DbContext
{
    
#pragma warning disable CS8618
    public AvailabilityContext(DbContextOptions<AvailabilityContext> options)
        : base(options)
#pragma warning restore CS8618
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // optionsBuilder.UseLoggerFactory(_loggerFactory);
        // optionsBuilder.EnableDetailedErrors();
        // optionsBuilder.EnableSensitiveDataLogging();
    } 
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("availability");
        modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
    }
}