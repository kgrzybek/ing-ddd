﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources.Events;

public class ResourceTemporarilyBlockedDomainEvent : DomainEventBase
{
    public ResourceTemporarilyBlockedDomainEvent(Guid resourceId, Guid ownerId, DateTime dateTo)
    {
        OwnerId = ownerId;
        DateTo = dateTo;
        ResourceId = resourceId;
    }
    
    public Guid ResourceId { get; }

    public Guid OwnerId { get; }
    
    public DateTime DateTo { get; }
}