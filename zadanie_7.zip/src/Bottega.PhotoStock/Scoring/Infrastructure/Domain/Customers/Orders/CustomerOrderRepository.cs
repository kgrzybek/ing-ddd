﻿using Bottega.PhotoStock.Scoring.Domain.Customers.Orders;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Domain.Customers.Orders;

public class CustomerOrderRepository : ICustomerOrderRepository
{
    private readonly ScoringContext _scoringContext;

    public CustomerOrderRepository(ScoringContext scoringContext)
    {
        _scoringContext = scoringContext;
    }

    public async Task Add(CustomerOrder customerOrder)
    {
        await _scoringContext.CustomerOrders.AddAsync(customerOrder);
    }
}