﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Bottega.PhotoStock.Scoring.Application;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration;

public class ScoringModule : IScoringModule
{
    public async Task ExecuteCommand(ICommand command, CancellationToken cancellationToken = default)
    {
        await CommandExecutor.Execute(command, cancellationToken);
    }

    public async Task<TResult> ExecuteQuery<TResult>(
        IQuery<TResult> query, CancellationToken cancellationToken = default)
    {
        return await QueryExecutor.ExecuteQueryAsync(query, cancellationToken);
    }
}