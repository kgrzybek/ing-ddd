﻿namespace Bottega.PhotoStock.Scoring.Application.Customers;

public class LoanLimitThresholdDto
{
    public decimal FromValue { get; set; }
    
    public string FromCurrencyCode { get; set; }
    
    public decimal ToValue { get; set; }
    
    public string ToCurrencyCode { get; set; }
    
    public decimal LoanLimitValue { get; set; }
    
    public string LoanLimitValueCurrencyCode { get; set; }
}