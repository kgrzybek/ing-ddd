﻿namespace Bottega.PhotoStock.Scoring.Application.Customers;

public class CustomerOrderDto
{
    public Guid CustomerId { get; set; }
    
    public decimal OrderValue { get; set; }
    
    public string OrderCurrencyCode { get; set; }
}