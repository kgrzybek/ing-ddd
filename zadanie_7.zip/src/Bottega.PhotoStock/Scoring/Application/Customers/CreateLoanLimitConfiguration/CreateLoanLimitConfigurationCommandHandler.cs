﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.CreateLoanLimitConfiguration;

public class CreateLoanLimitConfigurationCommandHandler : ICommandHandler<CreateLoanLimitConfigurationCommand>
{
    private readonly ILoanLimitConfigurationRepository _loanLimitConfigurationRepository;

    public CreateLoanLimitConfigurationCommandHandler(ILoanLimitConfigurationRepository loanLimitConfigurationRepository)
    {
        _loanLimitConfigurationRepository = loanLimitConfigurationRepository;
    }

    public async Task<Unit> Handle(CreateLoanLimitConfigurationCommand command, CancellationToken cancellationToken)
    {
        var loanLimitConfiguration = LoanLimitConfiguration.Create(
            Percentage.FromFraction(command.PercentageTotalOrders),
            CurrentLoanLimitConfiguration.OfCode(command.CurrentConfigurationCode));

        await _loanLimitConfigurationRepository.Add(loanLimitConfiguration);

        return Unit.Value;
    }
}