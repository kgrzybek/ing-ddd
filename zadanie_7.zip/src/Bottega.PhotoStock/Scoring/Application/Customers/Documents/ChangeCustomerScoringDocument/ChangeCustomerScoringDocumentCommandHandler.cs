﻿using System.Data;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.Documents;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Dapper;
using Marten;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Documents.ChangeCustomerScoringDocument;

public class ChangeCustomerScoringDocumentCommandHandler : ICommandHandler<ChangeCustomerScoringDocumentCommand>
{
    private readonly IDocumentSession _documentSession;

    private readonly IDbConnectionFactory _connectionFactory;

    public ChangeCustomerScoringDocumentCommandHandler(
        IDbConnectionFactory connectionFactory,
        IDocumentSession documentSession)
    {
        _connectionFactory = connectionFactory;
        _documentSession = documentSession;
    }

    public async Task<Unit> Handle(ChangeCustomerScoringDocumentCommand command, CancellationToken cancellationToken)
    {
        var customerScoring = await _documentSession.Query<CustomerScoringDocument>()
            .SingleAsync(x => x.CustomerId == command.CustomerId, token: cancellationToken);

        if (customerScoring == null)
        {
            throw new ArgumentException("Invalid CustomerId");
        }

        var connection = _connectionFactory.GetOpenConnection();

        var isCustomerBlacklisted = await IsBlacklisted(connection, command.CustomerId);
        
        var thresholds = await GetThresholds(connection);
        
        var orders = await GetOrders(connection, command.CustomerId);

        var configuration = await GetLoanLimitConfiguration(connection);

        var loanLimitPolicy = LoanLimitPolicyFactory.Create(
            isCustomerBlacklisted,
            thresholds,
            orders,
            Percentage.FromFraction(configuration.PercentageTotalOrders),
            CurrentLoanLimitConfiguration.OfCode(configuration.CurrentConfigurationCode)
        );

        customerScoring.ChangeLoanLimit(loanLimitPolicy);
        
        _documentSession.Store(customerScoring);

        await _documentSession.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }

    private static async Task<LoanLimitConfigurationDto> GetLoanLimitConfiguration(IDbConnection connection)
    {
        const string sql = $@"SELECT 
                limit_configuration.percentage_total_orders {nameof(LoanLimitConfigurationDto.PercentageTotalOrders)},
                limit_configuration.current_configuration_code {nameof(LoanLimitConfigurationDto.CurrentConfigurationCode)}
            FROM scoring.loan_limit_configurations limit_configuration limit 1";

        return await connection.QuerySingleAsync<LoanLimitConfigurationDto>(sql);
    }

    private async Task<List<Threshold>> GetThresholds(IDbConnection connection)
    {
        string sql =
            $@"SELECT 
                threshold.from_value {nameof(LoanLimitThresholdDto.FromValue)},
                threshold.from_currency {nameof(LoanLimitThresholdDto.FromCurrencyCode)},
                threshold.to_value {nameof(LoanLimitThresholdDto.ToValue)},
                threshold.to_currency {nameof(LoanLimitThresholdDto.ToCurrencyCode)},
                threshold.loan_limit_value {nameof(LoanLimitThresholdDto.LoanLimitValue)},
                threshold.loan_limit_currency {nameof(LoanLimitThresholdDto.LoanLimitValueCurrencyCode)}
            FROM scoring.loan_limit_thresholds threshold";
        
        var thresholdDtos = await connection.QueryAsync<LoanLimitThresholdDto>(sql);

        return thresholdDtos.Select(x => new Threshold(
                Money.Of(x.FromValue, x.FromCurrencyCode),
                Money.Of(x.ToValue, x.ToCurrencyCode),
                Money.Of(x.LoanLimitValue, x.LoanLimitValueCurrencyCode)))
            .ToList();
    }
    
    private static async Task<List<OrderData>> GetOrders(IDbConnection connection, Guid customerId)
    {
        string sql =
            $@"SELECT 
                customer_order.customer_id {nameof(CustomerOrderDto.CustomerId)},
                customer_order.order_value {nameof(CustomerOrderDto.OrderValue)},
                customer_order.order_currency {nameof(CustomerOrderDto.OrderCurrencyCode)}
            FROM scoring.customer_orders customer_order
            WHERE customer_order.customer_id = :customerId";
        
        var orderDtos = await connection.QueryAsync<CustomerOrderDto>(sql,
            new
            {
                customerId
            });

        return orderDtos.Select(x => new OrderData(
                Money.Of(x.OrderValue, x.OrderCurrencyCode)))
            .ToList();
    }

    private static async Task<bool> IsBlacklisted(IDbConnection connection, Guid customerId)
    {
        string sql = "SELECT COUNT(customer_id) " +
                     "FROM scoring.blacklist_customers blacklist_customer " +
                     "WHERE blacklist_customer.customer_id = :customerId";
        var count = await connection.ExecuteScalarAsync<int>(sql, new
        {
            customerId
        });

        return count > 0;
    }
}