﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Documents.ChangeCustomerScoringDocument;

public class ChangeCustomerScoringDocumentCommand : CommandBase
{
    public ChangeCustomerScoringDocumentCommand(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}