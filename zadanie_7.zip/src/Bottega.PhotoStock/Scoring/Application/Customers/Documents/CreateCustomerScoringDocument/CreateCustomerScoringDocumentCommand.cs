﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Documents.CreateCustomerScoringDocument;

public class CreateCustomerScoringDocumentCommand : CommandBase
{
    public CreateCustomerScoringDocumentCommand(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}