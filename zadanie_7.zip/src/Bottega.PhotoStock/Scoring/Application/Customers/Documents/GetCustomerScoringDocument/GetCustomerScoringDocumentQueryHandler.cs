using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.Documents;
using Marten;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Documents.GetCustomerScoringDocument;

public class GetCustomerScoringDocumentQueryHandler : IQueryHandler<GetCustomerScoringDocumentQuery, CustomerScoringDocumentSnapshot>
{
    private readonly IDocumentSession _documentSession;

    public GetCustomerScoringDocumentQueryHandler(
        IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<CustomerScoringDocumentSnapshot> Handle(GetCustomerScoringDocumentQuery query, CancellationToken cancellationToken)
    {
        var customerScoring = await _documentSession.Query<CustomerScoringDocument>()
            .SingleAsync(x => x.CustomerId == query.CustomerId, cancellationToken);

        return customerScoring.ToSnapshot();
    }
}