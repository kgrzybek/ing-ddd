CREATE TABLE scoring.loan_limit_configurations (
   id UUID NOT NULL,
   percentage_total_orders DECIMAL(18, 4) NOT NULL,
   current_configuration_code VARCHAR(20) NOT NULL,
   CONSTRAINT pk_scoring_loan_limit_configurations_id PRIMARY KEY (id)
);