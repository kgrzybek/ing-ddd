﻿namespace Bottega.PhotoStock.Scoring.Domain.Customers.Documents;

public record CustomerScoringDocumentSnapshot(Guid CustomerId, decimal LoanLimitValue, string LoanLimitCurrencyCode)
{
}