﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Scoring.Domain.Customers;

public interface ICustomerScoringRepository : IRepository
{
    public Task Add(CustomerScoring customerScoring);

    public ValueTask<CustomerScoring?> GetById(Guid customerId);
}