﻿using Newtonsoft.Json;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public record Money
{
    public decimal Amount { get; }
    
    public string CurrencyCode { get; }

    [JsonConstructor]
    private Money(decimal amount, string currencyCode)
    {
        Amount = amount;
        CurrencyCode = currencyCode;
    }
    
    public static Money Of(decimal value, string currencyCode)
    {
        return new Money(value, currencyCode);
    }
    
    public static Money Of(decimal value)
    {
        return new Money(value, "PLN");
    }   

    public static Money operator +(Money left, Money right)
    {
        if (left.CurrencyCode != right.CurrencyCode)
        {
            throw new ArgumentException("Currencies don't match.");
        }
        
        return Of(left.Amount + right.Amount, left.CurrencyCode);
    }
    
    public static Money operator -(Money left, Money right)
    {
        if (left.CurrencyCode != right.CurrencyCode)
        {
            throw new ArgumentException("Currencies don't match.");
        }
        
        return Of(left.Amount - right.Amount, left.CurrencyCode);
    }
    
    public static bool operator >(Money left, decimal right) => left.Amount > right;

    public static bool operator <(Money left, decimal right) => left.Amount < right;
    
    public static bool operator >(Money left, Money right) => left.Amount > right.Amount;

    public static bool operator <(Money left, Money right) => left.Amount < right.Amount;
    
    public static bool operator >=(Money left, Money right) => left.Amount >= right.Amount;

    public static bool operator <=(Money left, Money right) => left.Amount <= right.Amount;
    
    public static Money operator *(Percentage percentage, Money money) => Of(percentage.Fraction * money.Amount);
}

public static class MoneyValueExtensions
{
    public static Money Sum(this IEnumerable<Money> values)
        => values
            .Aggregate(
                Money.Of(0),
                (x, y) => x + y);
}