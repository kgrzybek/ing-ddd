﻿using System.Data;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Npgsql;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;

public class DbConnectionFactory : IDbConnectionFactory
{
    private IDbConnection? _connection;
    
    private readonly List<IDbConnection> _allConnections;

    private readonly string _connectionString;

    public DbConnectionFactory(string connectionString)
    {
        _allConnections = new List<IDbConnection>();
        _connectionString = connectionString;
    }

    public void Dispose()
    {
        foreach (var connection in _allConnections)
        {
            if (connection is { State: ConnectionState.Open })
            {
                connection.Dispose();
            }
        }
    }

    public IDbConnection GetOpenConnection()
    {
        if (_connection is not { State: ConnectionState.Open })
        {
            _connection = GetNewConnection();
        }

        return _connection;
    }
    
    private IDbConnection GetNewConnection()
    {
        var connection = new NpgsqlConnection(_connectionString);
        
        connection.Open();
        
        _allConnections.Add(connection);
        
        return connection;
    }
}