using System.Reflection;
using Autofac;
using MediatR;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;

public static class ContainerBuilderExtensions
{
    public static void RegisterScope<TType, TInterface>(this ContainerBuilder builder)
        where TType : notnull
        where TInterface : notnull
    {
        builder.RegisterType<TType>()
            .As<TInterface>()
            .InstancePerLifetimeScope();
    }
    
    public static void RegisterScope<TType>(this ContainerBuilder builder)
        where TType : notnull
    {
        builder.RegisterType<TType>()
            .InstancePerLifetimeScope();
    }
    
    public static void RegisterAllTypesWithInterfaceAsScope<TInterface>(
        this ContainerBuilder builder, params Assembly[] assemblies)
        where TInterface : notnull
    {
        builder.RegisterAssemblyTypes(assemblies)
            .Where(type => type.IsAssignableTo(typeof(TInterface)))
            .AsImplementedInterfaces()
            .InstancePerLifetimeScope();
    }
    
    public static void RegisterPipelineBehaviors(
        this ContainerBuilder builder, 
        params Type[] types)
    {
        foreach (var type in types)
        {
            builder.RegisterPipelineBehavior(type);
        }
    }
    
    public static void RegisterPipelineBehavior(this ContainerBuilder builder, Type type)
    {
        builder
            .RegisterGeneric(type)
            .As(typeof(IPipelineBehavior<,>));
    }
}