﻿namespace Bottega.PhotoStock.BuildingBlocks.Domain;

public abstract class DocumentEntity
{
    protected static void CheckRule(IBusinessRule rule)
    {
        if (rule.IsBroken())
        {
            throw new BusinessRuleValidationException(rule);
        }
    }

    protected List<IDomainEvent> OneDomainEvent(IDomainEvent domainEvent)
    {
        return new List<IDomainEvent>
        {
            domainEvent
        };
    }
    
    protected List<IDomainEvent> NoDomainEvents()
    {
        return new List<IDomainEvent>();
    }
}