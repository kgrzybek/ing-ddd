namespace Bottega.PhotoStock.BuildingBlocks.Domain;

public class DomainEventBase : IDomainEvent
{
    public Guid Id { get; private set; }
    
    public DateTime OccurredOn { get; private set; }

    public DomainEventBase()
    {
        Id = Guid.NewGuid();
        OccurredOn = SystemClock.Now;
    }
}