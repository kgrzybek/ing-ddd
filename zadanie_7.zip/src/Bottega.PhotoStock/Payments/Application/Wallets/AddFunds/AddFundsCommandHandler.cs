using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain;
using Bottega.PhotoStock.Payments.Domain.Wallets;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Wallets.AddFunds;

public class AddFundsCommandHandler : ICommandHandler<AddFundsCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public AddFundsCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(AddFundsCommand command, CancellationToken cancellationToken)
    {
        var wallet = _eventSourcingAggregateRepository.Load<Wallet>(command.PayerId);
        
        wallet.AddFunds(Money.Of(command.Amount));

        await _eventSourcingAggregateRepository.Store(wallet);

        return Unit.Value;
    }
}