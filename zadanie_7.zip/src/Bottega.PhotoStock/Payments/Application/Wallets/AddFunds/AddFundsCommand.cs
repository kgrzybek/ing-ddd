﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Payments.Application.Wallets.AddFunds;

public class AddFundsCommand : CommandBase
{
    public AddFundsCommand(Guid payerId, decimal amount)
    {
        PayerId = payerId;
        Amount = amount;
    }

    public Guid PayerId { get; }
    
    public decimal Amount { get; }
}