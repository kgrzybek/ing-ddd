﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Payments.Application.Wallets.AddWallet;

public class AddWalletCommand : CommandBase
{
    public AddWalletCommand(Guid payerId)
    {
        PayerId = payerId;
    }

    public Guid PayerId { get; }
}