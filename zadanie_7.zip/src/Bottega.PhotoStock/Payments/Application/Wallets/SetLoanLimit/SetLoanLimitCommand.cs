﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Payments.Application.Wallets.SetLoanLimit;

public class SetLoanLimitCommand : CommandBase
{
    public SetLoanLimitCommand(Guid payerId, decimal loanLimit)
    {
        PayerId = payerId;
        LoanLimit = loanLimit;
    }

    public Guid PayerId { get; }
    
    public decimal LoanLimit { get; }
}