using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain;
using Bottega.PhotoStock.Payments.Domain.Wallets;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Wallets.Pay;

public class PayCommandCommandHandler : ICommandHandler<PayCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public PayCommandCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(PayCommand command, CancellationToken cancellationToken)
    {
        var wallet = _eventSourcingAggregateRepository.Load<Wallet>(command.PayerId);
        
        wallet.Pay(Money.Of(command.Amount));

        await _eventSourcingAggregateRepository.Store(wallet);

        return Unit.Value;
    }
}