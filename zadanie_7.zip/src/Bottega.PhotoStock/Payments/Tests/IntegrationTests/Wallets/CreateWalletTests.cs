﻿using Bottega.PhotoStock.Payments.Application.Wallets.AddWallet;
using Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;
using Bottega.PhotoStock.Payments.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.IntegrationTests.Wallets;

[TestFixture]
public class CreateWalletTests : TestBase
{
    [Test]
    public async Task WhenCreateWallet_ThenIsCreated()
    {
        // When
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddWalletCommand(payerId));
        
        // Then
        var wallet = await PaymentsModule.ExecuteQuery(new GetWalletQuery(payerId));
        wallet.PayerId.Should().Be(payerId);
    }
}