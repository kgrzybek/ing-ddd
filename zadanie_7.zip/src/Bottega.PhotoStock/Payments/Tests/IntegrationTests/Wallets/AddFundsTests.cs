﻿using Bottega.PhotoStock.Payments.Application.Wallets.AddFunds;
using Bottega.PhotoStock.Payments.Application.Wallets.AddWallet;
using Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;
using Bottega.PhotoStock.Payments.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.IntegrationTests.Wallets;

[TestFixture]
public class AddFundsTests : TestBase
{
    [Test]
    public async Task GivenWallet_WhenAddFunds_ThenFundsAreAdded()
    {
        // Given
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddWalletCommand(payerId));
        
        // When
        await PaymentsModule.ExecuteCommand(new AddFundsCommand(payerId, 1000));
        
        // Then
        var wallet = await PaymentsModule.ExecuteQuery(new GetWalletQuery(payerId));
        wallet.PayerId.Should().Be(payerId);
        wallet.Balance.Should().Be(1000);
    }
}