using FluentAssertions;

namespace Bottega.PhotoStock.Payments.Domain.UnitTests;

public class MoneyTests
{
    [Test]
    public void GivenMoneyWithTheSameAmountAndCurrency_WhenCompareThem_ThenTheyAreEqual()
    {
        // Given
        var firstMoney = Money.Of(100, "PLN");
        var secondMoney = Money.Of(100, "PLN");
        
        // When
        var areTheyEqual = firstMoney == secondMoney;
        
        // Then
        areTheyEqual.Should().BeTrue();
    }
    
    [Test]
    public void GivenMoneyWithTheSameAmount_ButDifferentCurrency_WhenCompareThem_ThenTheyAreNotEqual()
    {
        // Given
        var firstMoney = Money.Of(100, "PLN");
        var secondMoney = Money.Of(100, "USD");
        
        // When
        var areTheyEqual = firstMoney == secondMoney;
        
        // Then
        areTheyEqual.Should().BeFalse();
    }
    
    [Test]
    public void GivenMoneyWithTheSameCurrency_WhenAddThem_ThenResultIsSumOfThem()
    {
        // Given
        var firstMoney = Money.Of(100, "PLN");
        var secondMoney = Money.Of(400, "PLN");
        
        // When
        var result = firstMoney + secondMoney;
        
        // Then
        result.Should().Be(Money.Of(500, "PLN"));
    }
    
    [Test]
    public void GivenMoneyWithTheDifferentCurrency_WhenAddThem_ThenArgumentExceptionIsThrown()
    {
        // Given
        var firstMoney = Money.Of(100, "PLN");
        var secondMoney = Money.Of(400, "USD");
        
        // When
        var action = () => firstMoney + secondMoney;
        
        // Then
        action.Should().Throw<ArgumentException>().WithMessage("Currencies don't match.");
    }
    
    [Test]
    public void GivenMoneyWithTheDifferentCurrency_WhenSubtractThem_ThenArgumentExceptionIsThrown()
    {
        // Given
        var firstMoney = Money.Of(100, "PLN");
        var secondMoney = Money.Of(50, "USD");
        
        // When
        var action = () => firstMoney - secondMoney;
        
        // Then
        action.Should().Throw<ArgumentException>().WithMessage("Currencies don't match.");
    }
}