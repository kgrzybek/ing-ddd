﻿using Bottega.PhotoStock.Payments.Domain.Wallets;
using Bottega.PhotoStock.Payments.Domain.Wallets.Events;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.Domain.UnitTests.Wallets;

[TestFixture]
public class AddFundsTests
{
    [Test]
    public void GivenWallet_WhenAddFunds_ThenFundsAreAdded()
    {
        // Given
        var wallet = Wallet.Add(Guid.NewGuid());
        
        // When
        wallet.AddFunds(Money.Of(1000));
        
        // Then
        var @event = wallet.GetUncommittedEvents()
            .OfType<FundsAddedDomainEvent>()
            .Single();

        @event.Amount.Should().Be(Money.Of(1000));
    }
}