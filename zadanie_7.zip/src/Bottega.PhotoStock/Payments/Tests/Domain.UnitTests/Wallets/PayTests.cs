﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Wallets;
using Bottega.PhotoStock.Payments.Domain.Wallets.Events;
using Bottega.PhotoStock.Payments.Domain.Wallets.Rules;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.Domain.UnitTests.Wallets;

[TestFixture]
public class PayTests
{
    [Test]
    public void GivenWallet_WithEnoughBalance_WhenPay_ThenBalanceDecreased()
    {
        // Given
        var wallet = Wallet.Add(Guid.NewGuid());
        wallet.AddFunds(Money.Of(1000));
        
        // When
        wallet.Pay(Money.Of(500));
        
        // Then
        var @event = wallet.GetUncommittedEvents()
            .OfType<BalanceDecreasedDomainEvent>()
            .Single();

        @event.Amount.Should().Be(Money.Of(500));
    }
    
    [Test]
    public void GivenWallet_WithNotEnoughBalance_WhenPay_ThenPaymentFailed()
    {
        // Given
        var wallet = Wallet.Add(Guid.NewGuid());
        wallet.AddFunds(Money.Of(1000));
        
        // When
        Action action = () => wallet.Pay(Money.Of(1500));
        
        // Then
        action.Should().Throw<BusinessRuleValidationException>().Where(x => 
            x.BrokenRule.GetType() == typeof(SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule));
    }
    
    [Test]
    public void GivenWallet_WithNotEnoughBalance_ButWithLimitEnough_WhenPay_ThenBalanceDecreasedAndRemainingLoanLimitDecreased()
    {
        // Given
        var wallet = Wallet.Add(Guid.NewGuid());
        wallet.AddFunds(Money.Of(1000));
        
        wallet.SetLoanLimit(Money.Of(600));
        
        // When
        wallet.Pay(Money.Of(1500));
        
        // Then
        var balanceDecreasedDomainEvent = wallet.GetUncommittedEvents()
            .OfType<BalanceDecreasedDomainEvent>()
            .Single();
        balanceDecreasedDomainEvent.Amount.Should().Be(Money.Of(1000));
        
        var loanIncreasedDomainEvent = wallet.GetUncommittedEvents()
            .OfType<LoanIncreasedDomainEvent>()
            .Single();

        loanIncreasedDomainEvent.Amount.Should().Be(Money.Of(500));
    }
    
    [Test]
    public void GivenWallet_WithNotEnoughBalance_AndRemainingLoanLimitIsNotEnough_WhenPay_ThenPaymentFailed()
    {
        // Given
        var wallet = Wallet.Add(Guid.NewGuid());
        wallet.AddFunds(Money.Of(1000));
        
        wallet.SetLoanLimit(Money.Of(400));
        
        // When
        Action action = () => wallet.Pay(Money.Of(1500));
        
        // Then
        action.Should().Throw<BusinessRuleValidationException>().Where(x => 
            x.BrokenRule.GetType() == typeof(SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule));
    }
}