﻿namespace Bottega.PhotoStock.Payments.Domain.Wallets.Events;

public class LoanIncreasedDomainEvent
{
    public LoanIncreasedDomainEvent(Money amount)
    {
        Amount = amount;
    }

    public Money Amount { get; }
}