﻿namespace Bottega.PhotoStock.Payments.Domain.Wallets.Events;

public class FundsAddedDomainEvent
{
    public FundsAddedDomainEvent(Money amount)
    {
        Amount = amount;
    }

    public Money Amount { get; }
}