﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Payments.Domain.Wallets.Rules;

public class SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule : IBusinessRule
{
    private readonly Money _amountToPay;

    private readonly Money _balance;

    private readonly Money _remainingLoanLimit;

    public SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule(
        Money amountToPay,
        Money balance,
        Money remainingLoanLimit)
    {
        _amountToPay = amountToPay;
        _balance = balance;
        _remainingLoanLimit = remainingLoanLimit;
    }

    public bool IsBroken() => _balance + _remainingLoanLimit < _amountToPay;

    public string Code => "SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule";
}