﻿using System.Reflection;
using Autofac;
using MediatR.Extensions.Autofac.DependencyInjection;
using Module = Autofac.Module;

namespace Bottega.PhotoStock.Payments.Infrastructure.Configuration.Mediation;
    
public class MediatorModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        var assemblies = new List<Assembly> { Assemblies.Application, Assemblies.Infrastructure };

        builder.RegisterMediatR(assemblies);
    }
}
