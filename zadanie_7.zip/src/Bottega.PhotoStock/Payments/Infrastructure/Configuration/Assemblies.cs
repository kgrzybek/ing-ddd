using System.Reflection;
using Bottega.PhotoStock.Payments.Application;

namespace Bottega.PhotoStock.Payments.Infrastructure.Configuration;

public static class Assemblies
{
    public static readonly Assembly Application = typeof(IPaymentsModule).Assembly;
    public static readonly Assembly Infrastructure = typeof(PaymentsModule).Assembly;
}