﻿using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using MediatR;

namespace Bottega.PhotoStock.Payments.Infrastructure.Configuration.Processing;

internal static class CommandExecutor
{
    internal static async Task Execute(
        ICommand command, CancellationToken cancellationToken = default)
    {
        await using var scope = PaymentsCompositionRoot.BeginLifetimeScope();

        var mediator = scope.Resolve<IMediator>();

        await mediator.Send(command, cancellationToken);
    }
}