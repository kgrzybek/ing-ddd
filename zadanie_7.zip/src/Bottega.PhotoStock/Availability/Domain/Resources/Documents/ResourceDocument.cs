﻿using Availability.Domain.Resources.Events;
using Availability.Domain.Resources.Rules;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Newtonsoft.Json;

namespace Availability.Domain.Resources.Documents;

public class ResourceDocument : DocumentEntity
{
    public Guid Id { get; private set; }

    [JsonProperty("Blockade")] 
    private Blockade? _blockade;

    [JsonProperty("IsWithdrawn")]
    private bool _isWithdrawn;

    private ResourceDocument()
    {
        // Only for Marten.
    }

    private ResourceDocument(Guid id)
    {
        this.Id = id;
    }
    
    public static ResourceDocument Create(Guid id)
    {
        return new ResourceDocument(id);
    }
    
    public List<IDomainEvent> BlockTemporarily(Guid ownerId, TimeSpan time)
    {
        CheckRule(new WithdrawnResourceCannotBeBlockedRule(_isWithdrawn));
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockade, ownerId));
        
        _blockade = Blockade.CreateTemporary(ownerId, time);

        return OneDomainEvent(new ResourceTemporarilyBlockedDomainEvent(this.Id, _blockade.OwnerId, _blockade.DateTo!.Value));
    }

    public List<IDomainEvent> Unblock(Guid ownerId)
    {
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockade, ownerId));
        
        
        
        return OneDomainEvent(new ResourceUnblockedDomainEvent(this.Id));
    }
    
    public List<IDomainEvent> BlockPermanently(Guid ownerId)
    {
        CheckRule(new WithdrawnResourceCannotBeBlockedRule(_isWithdrawn));
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockade, ownerId));
        
        _blockade = Blockade.CreatePermanent(ownerId);
        
        return OneDomainEvent(new ResourcePermanentlyBlockedDomainEvent(this.Id, _blockade.OwnerId));
    }

    public List<IDomainEvent> Withdraw()
    {
        _isWithdrawn = true;

        return OneDomainEvent(new ResourceWithdrawnDomainEvent(this.Id));
    }

    public ResourceDocumentSnapshot ToSnapshot()
    {
        return new ResourceDocumentSnapshot(Id, _blockade?.DateTo, _blockade?.OwnerId, _isWithdrawn);
    }
}