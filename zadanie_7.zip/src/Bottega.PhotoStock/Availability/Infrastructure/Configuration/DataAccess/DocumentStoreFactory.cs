﻿using Availability.Domain.Resources.Documents;
using Marten;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration.DataAccess;

internal static class DocumentStoreFactory
{
    internal static DocumentStore Create(string connectionString)
    {
        return DocumentStore.For(storeOptions =>
        {
            storeOptions.Connection(connectionString);
            storeOptions.UseDefaultSerialization(
                nonPublicMembersStorage: NonPublicMembersStorage.NonPublicSetters | NonPublicMembersStorage.NonPublicConstructor);
            storeOptions.DatabaseSchemaName = "availability";
            ConfigureResourceDocument(storeOptions);
        });
    }
    
    private static void ConfigureResourceDocument(StoreOptions storeOptions)
    {
        storeOptions.Schema
            .For<ResourceDocument>()
            .Identity(x => x.Id)
            .DocumentAlias("resource_documents")
            .UseOptimisticConcurrency(true);
    }
}