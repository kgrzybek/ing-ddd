﻿using Autofac;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration
{
    internal static class AvailabilityCompositionRoot
    {
        private static IContainer? _container;

        internal static void SetContainer(IContainer container)
        {
            _container = container;
        }

        internal static ILifetimeScope BeginLifetimeScope()
        {
            if (_container is null)
            {
                throw new InvalidOperationException("Cannot begin lifetime scope, the container was not set.");
            }
            
            return _container.BeginLifetimeScope();
        }
    }
}