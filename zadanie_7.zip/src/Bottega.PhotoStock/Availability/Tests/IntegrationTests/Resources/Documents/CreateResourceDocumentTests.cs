﻿using Bottega.PhotoStock.Availability.Application.Resources.Documents.CreateResourceDocument;
using Bottega.PhotoStock.Availability.Application.Resources.Documents.GetResourceDocument;
using Bottega.PhotoStock.Availability.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Availability.IntegrationTests.Resources.Documents;

[TestFixture]
public class CreateResourceDocumentTests : TestBase
{
    [Test]
    public async Task WhenCreateResource_ThenIsCreated()
    {
        // When
        var resourceId = Guid.NewGuid();
        await AvailabilityModule.ExecuteCommand(new CreateResourceDocumentCommand(resourceId));

        // Then
        var resource = await AvailabilityModule.ExecuteQuery(new GetResourceDocumentQuery(resourceId));
        resource.IsWithdrawn.Should().BeFalse();
        resource.Id.Should().Be(resourceId);
        resource.BlockadeDateTo.Should().BeNull();
        resource.BlockadeOwnerId.Should().BeNull();
    }
}