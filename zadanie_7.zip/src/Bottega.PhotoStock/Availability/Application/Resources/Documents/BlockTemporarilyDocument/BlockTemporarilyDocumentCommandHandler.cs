using Availability.Domain.Resources;
using Availability.Domain.Resources.Documents;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Marten;
using MediatR;

namespace Bottega.PhotoStock.Availability.Application.Resources.Documents.BlockTemporarilyDocument;

public class BlockTemporarilyDocumentCommandHandler : ICommandHandler<BlockTemporarilyDocumentCommand>
{
    private readonly IDocumentSession _documentSession;

    public BlockTemporarilyDocumentCommandHandler(IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<Unit> Handle(BlockTemporarilyDocumentCommand command, CancellationToken cancellationToken)
    {
        var resource = await _documentSession.Query<ResourceDocument>()
            .SingleAsync(x => x.Id == command.ResourceId, token: cancellationToken);

        if (resource == null)
        {
            throw new ArgumentException("Invalid Resource Id");
        }
        
        resource.BlockTemporarily(command.OwnerId, command.Time);
        
        _documentSession.Store(resource);

        await _documentSession.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}