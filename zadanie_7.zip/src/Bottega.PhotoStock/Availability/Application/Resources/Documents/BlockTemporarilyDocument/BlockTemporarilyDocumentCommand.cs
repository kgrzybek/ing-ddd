﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Availability.Application.Resources.Documents.BlockTemporarilyDocument;

public class BlockTemporarilyDocumentCommand : CommandBase
{
    public BlockTemporarilyDocumentCommand(Guid resourceId, Guid ownerId, TimeSpan time)
    {
        ResourceId = resourceId;
        OwnerId = ownerId;
        Time = time;
    }

    public Guid ResourceId { get; }
    
    public Guid OwnerId { get; }
    
    public TimeSpan Time { get; }
}