﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Availability.Application.Resources.Documents.CreateResourceDocument;

public class CreateResourceDocumentCommand : CommandBase
{
    public CreateResourceDocumentCommand(Guid resourceId)
    {
        ResourceId = resourceId;
    }

    public Guid ResourceId { get; }
}