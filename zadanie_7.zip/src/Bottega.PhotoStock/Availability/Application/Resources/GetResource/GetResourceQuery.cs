﻿using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Availability.Application.Resources.GetResource;

public class GetResourceQuery : QueryBase<ResourceDto>
{
    public GetResourceQuery(Guid resourceId)
    {
        ResourceId = resourceId;
    }

    public Guid ResourceId { get; }
}