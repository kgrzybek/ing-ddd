﻿namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public static class LoanLimitPolicyFactory
{
    public static ILoanLimitPolicy Create(
        bool isCustomerBlacklisted,
        List<Threshold> thresholds,
        List<OrderData> orders,
        Percentage percentageOfTotalOrders,
        CurrentLoanLimitConfiguration loanLimitConfiguration
    )
    {
        if (isCustomerBlacklisted)
        {
            return new NoLoanPolicy();
        }

        if (loanLimitConfiguration == CurrentLoanLimitConfiguration.Percentage)
        {
            return new PercentageOfTotalOrdersValueLoanLimitPolicy(percentageOfTotalOrders, orders);
        }

        if (loanLimitConfiguration == CurrentLoanLimitConfiguration.ByThreshold)
        {
            return new ByThresholdsLoanLimitPolicy(thresholds, orders);
        }

        return new NoLoanPolicy();
    }
}