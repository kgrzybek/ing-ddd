namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public record OrderData(Money Value);