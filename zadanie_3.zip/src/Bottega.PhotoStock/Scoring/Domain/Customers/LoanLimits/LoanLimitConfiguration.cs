﻿namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public record CurrentLoanLimitConfiguration(string Code)
{
    public static CurrentLoanLimitConfiguration ByThreshold => new CurrentLoanLimitConfiguration(nameof(ByThreshold));
    
    public static CurrentLoanLimitConfiguration Percentage => new CurrentLoanLimitConfiguration(nameof(Percentage));
    
    public static CurrentLoanLimitConfiguration NoLoan => new CurrentLoanLimitConfiguration(nameof(NoLoan));
}