namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public class NoLoanPolicy : ILoanLimitPolicy
{
    public Money Calculate()
    {
        return Money.Of(0);
    }
}