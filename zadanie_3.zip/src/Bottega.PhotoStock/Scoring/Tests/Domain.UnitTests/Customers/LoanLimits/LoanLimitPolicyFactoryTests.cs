﻿using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using FluentAssertions;

namespace Bottega.PhotoStock.Scoring.Domain.UnitTests.Customers.LoanLimits;

[TestFixture]
public class LoanLimitPolicyFactoryTests
{
    [Test]
    public void GivenCustomerIsBlacklisted_WhenCreateLoanLimitPolicy_ThenNoLoanPolicyIsCreated()
    {
        // When
        var loanLimitPolicy = LoanLimitPolicyFactory.Create(
            true, 
            new List<Threshold>
            {
                new Threshold(Money.Of(0), Money.Of(499.99m), Money.Of(100)),
                new Threshold(Money.Of(500), Money.Of(999.99m), Money.Of(300)),
            }, 
            new List<OrderData>(),
            Percentage.Of(10),
            CurrentLoanLimitConfiguration.Percentage);
        
        // Then
        loanLimitPolicy.Should().BeOfType(typeof(NoLoanPolicy));
    }
    
    [Test]
    public void GivenCustomerIsNotBlacklisted_AndLoanConfigurationIsPercentage_WhenCreateLoanLimitPolicy_ThenPercentageOfTotalOrdersIsCreated()
    {
        // When
        var loanLimitPolicy = LoanLimitPolicyFactory.Create(
            false, 
            new List<Threshold>
            {
                new Threshold(Money.Of(0), Money.Of(499.99m), Money.Of(100)),
                new Threshold(Money.Of(500), Money.Of(999.99m), Money.Of(300)),
            }, 
            new List<OrderData>(),
            Percentage.Of(10),
            CurrentLoanLimitConfiguration.Percentage);
        
        // Then
        loanLimitPolicy.Should().BeOfType(typeof(PercentageOfTotalOrdersValueLoanLimitPolicy));
    }
    
    [Test]
    public void GivenCustomerIsNotBlacklisted_AndLoanConfigurationIsByThreshold_WhenCreateLoanLimitPolicy_ThenByThresholdIsCreated()
    {
        // When
        var loanLimitPolicy = LoanLimitPolicyFactory.Create(
            false, 
            new List<Threshold>
            {
                new Threshold(Money.Of(0), Money.Of(499.99m), Money.Of(100)),
                new Threshold(Money.Of(500), Money.Of(999.99m), Money.Of(300)),
            }, 
            new List<OrderData>(),
            Percentage.Of(10),
            CurrentLoanLimitConfiguration.ByThreshold);
        
        // Then
        loanLimitPolicy.Should().BeOfType(typeof(ByThresholdsLoanLimitPolicy));
    }
}