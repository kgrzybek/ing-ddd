using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using FluentAssertions;

namespace Bottega.PhotoStock.Scoring.Domain.UnitTests.Customers.LoanLimits;

[TestFixture]
public class PercentageOfTotalOrdersValueLoanLimitPolicyTests
{
    [Test]
    public void GivenPercentageAndOrders_WhenCalculate_ThenLoanLimitIsPercentageOfTotalValueOfAllOrders()
    {
        // Given
        var percentage = Percentage.Of(20);
        
        var orders = new List<OrderData>();
        orders.Add(new OrderData(Money.Of(300)));
        orders.Add(new OrderData(Money.Of(700)));
        
        var policy = new PercentageOfTotalOrdersValueLoanLimitPolicy(percentage, orders);
        
        // When
        var loanLimit = policy.Calculate();
        
        // Then
        loanLimit.Should().Be(Money.Of(200));
    }
}