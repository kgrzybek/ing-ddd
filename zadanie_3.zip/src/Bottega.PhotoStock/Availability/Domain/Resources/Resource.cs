﻿using Availability.Domain.Resources.Events;
using Availability.Domain.Resources.Rules;
using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources;

public class Resource : Entity
{
    public Guid Id { get; private set; }

    private Blockade? _blockade;

    private bool _isWithdrawn;

    private Resource(Guid id)
    {
        this.Id = id;
    }
    
    public static Resource Create(Guid id)
    {
        return new Resource(id);
    }
    
    public void BlockTemporarily(Guid ownerId, TimeSpan time)
    {
        CheckRule(new WithdrawnResourceCannotBeBlockedRule(_isWithdrawn));
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockade, ownerId));
        
        _blockade = Blockade.CreateTemporary(ownerId, time);
        
        this.AddDomainEvent(new ResourceTemporarilyBlockedDomainEvent(this.Id, _blockade.OwnerId, _blockade.DateTo!.Value));
    }

    public void Unblock(Guid ownerId)
    {
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockade, ownerId));

        _blockade = null;
        
        this.AddDomainEvent(new ResourceUnblockedDomainEvent(this.Id));
    }
    
    public void BlockPermanently(Guid ownerId)
    {
        CheckRule(new WithdrawnResourceCannotBeBlockedRule(_isWithdrawn));
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockade, ownerId));
        
        _blockade = Blockade.CreatePermanent(ownerId);
        
        this.AddDomainEvent(new ResourcePermanentlyBlockedDomainEvent(this.Id, _blockade.OwnerId));
    }

    public void Withdraw()
    {
        _isWithdrawn = true;
        
        this.AddDomainEvent(new ResourceWithdrawnDomainEvent(this.Id));
    }
}