﻿using Availability.Domain.Resources.Events;
using Availability.Domain.Resources.Rules;
using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources;

public class Resource : Entity
{
    public Guid Id { get; private set; }

    private DateTime? _blockadeDateTo;

    private Guid? _blockadeOwnerId;

    private bool _isWithdrawn;

    private Resource(Guid id)
    {
        this.Id = id;
    }
    
    public static Resource Create(Guid id)
    {
        return new Resource(id);
    }
    
    public void BlockTemporarily(Guid ownerId, TimeSpan time)
    {
        CheckRule(new WithdrawnResourceCannotBeBlockedRule(_isWithdrawn));
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockadeOwnerId, _blockadeDateTo, ownerId));
        
        _blockadeOwnerId = ownerId;
        _blockadeDateTo = SystemClock.Now.Add(time);
        
        this.AddDomainEvent(new ResourceTemporarilyBlockedDomainEvent(this.Id, _blockadeOwnerId.Value, _blockadeDateTo.Value));
    }

    public void Unblock(Guid ownerId)
    {
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockadeOwnerId, _blockadeDateTo, ownerId));

        _blockadeDateTo = null;
        _blockadeOwnerId = null;
        
        this.AddDomainEvent(new ResourceUnblockedDomainEvent(this.Id));
    }
    
    public void BlockPermanently(Guid ownerId)
    {
        CheckRule(new WithdrawnResourceCannotBeBlockedRule(_isWithdrawn));
        CheckRule(new ThereAreNoOtherBlockadesRule(_blockadeOwnerId, _blockadeDateTo, ownerId));
        
        _blockadeOwnerId = ownerId;
        _blockadeDateTo = null;
        
        this.AddDomainEvent(new ResourcePermanentlyBlockedDomainEvent(this.Id, _blockadeOwnerId.Value));
    }

    public void Withdraw()
    {
        _isWithdrawn = true;
        
        this.AddDomainEvent(new ResourceWithdrawnDomainEvent(this.Id));
    }
}