﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources.Rules;

public class ThereAreNoOtherBlockadesRule : IBusinessRule
{
    private readonly Guid? _blockadeOwnerId;

    private readonly DateTime? _blockadeDateTo;

    private readonly Guid _ownerId;

    public ThereAreNoOtherBlockadesRule(Guid? blockadeOwnerId, DateTime? blockadeDateTo, Guid ownerId)
    {
        _blockadeOwnerId = blockadeOwnerId;
        _blockadeDateTo = blockadeDateTo;
        _ownerId = ownerId;
    }

    public bool IsBroken() => _blockadeOwnerId.HasValue &&
                              _blockadeOwnerId != _ownerId &&
                              _blockadeDateTo > SystemClock.Now;

    public string Code => "ThereAreNoOtherBlockadesRule";
}