namespace Bottega.PhotoStock.BuildingBlocks.Domain;

public interface IBusinessRule
{
    bool IsBroken();
    
    string Code { get; }
}