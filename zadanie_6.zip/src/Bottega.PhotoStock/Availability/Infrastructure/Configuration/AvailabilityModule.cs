﻿using Bottega.PhotoStock.Availability.Application;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration;

public class AvailabilityModule : IAvailabilityModule
{
    public async Task ExecuteCommand(ICommand command, CancellationToken cancellationToken = default)
    {
        await CommandExecutor.Execute(command, cancellationToken);
    }

    public async Task<TResult> ExecuteQuery<TResult>(
        IQuery<TResult> query, CancellationToken cancellationToken = default)
    {
        return await QueryExecutor.ExecuteQueryAsync(query, cancellationToken);
    }
}