﻿using Autofac;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration.DataAccess;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration.Mediation;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration;

public static class AvailabilityStartup
{
    private static IContainer? _container;

    public static void Initialize(
        string connectionString)
    {
        ConfigureCompositionRoot(
            connectionString);
    }

    private static void ConfigureCompositionRoot(
        string connectionString)
    {
        var containerBuilder = new ContainerBuilder();
        
        containerBuilder.RegisterModule(new DataAccessModule(connectionString));
        containerBuilder.RegisterModule(new MediatorModule());

        _container = containerBuilder.Build();

        AvailabilityCompositionRoot.SetContainer(_container);
    }
}