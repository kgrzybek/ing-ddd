﻿using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using MediatR;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration.Processing;

internal static class CommandExecutor
{
    internal static async Task Execute(
        ICommand command, CancellationToken cancellationToken = default)
    {
        await using var scope = AvailabilityCompositionRoot.BeginLifetimeScope();

        var mediator = scope.Resolve<IMediator>();

        await mediator.Send(command, cancellationToken);
    }
}