﻿using System.Reflection;
using Autofac;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using MediatR.Extensions.Autofac.DependencyInjection;
using Module = Autofac.Module;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration.Mediation;
    
public class MediatorModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterScope<UnitOfWork, IUnitOfWork>();

        var assemblies = new List<Assembly> { Assemblies.Application, Assemblies.Infrastructure };

        builder.RegisterMediatR(assemblies);
        builder.RegisterHandlerDecorators();
    }
}
