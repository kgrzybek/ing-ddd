using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Npgsql;
using Marten;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration.DataAccess;

public class DataAccessModule : Module
{
    private readonly string _connectionString;

    public DataAccessModule(
        string connectionString)
    {
        _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
    }
    
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<DbConnectionFactory>()
            .WithParameter("connectionString", _connectionString)
            .As<IDbConnectionFactory>()
            .InstancePerLifetimeScope();
        
        builder
            .Register(c =>
            {
                var dbContextOptionsBuilder = new DbContextOptionsBuilder<AvailabilityContext>();
                dbContextOptionsBuilder
                    .UseNpgsql(_connectionString, options =>
                    {
                        options.CommandTimeout(5 * 60);
                    })
                    .UseSnakeCaseNamingConvention();

                return new AvailabilityContext(dbContextOptionsBuilder.Options);
            })
            .AsSelf()
            .As<DbContext>()
            .InstancePerLifetimeScope();
        
        builder.RegisterAllTypesWithInterfaceAsScope<IRepository>(
            Assemblies.Infrastructure);
        
        RegisterMarten(builder);
        
        NpgsqlSwitches.RegisterEnableLegacyTimestampBehavior();
    }
    
    private void RegisterMarten(ContainerBuilder builder)
    {
        builder
            .Register(_ => DocumentStoreFactory.Create(_connectionString))
            .As<IDocumentStore>()
            .SingleInstance();
        
        builder
            .Register(factory => factory.Resolve<IDocumentStore>().LightweightSession())
            .As<IDocumentSession>()
            .InstancePerLifetimeScope();

        builder
            .Register(factory => factory.Resolve<IDocumentStore>().QuerySession())
            .As<IQuerySession>()
            .InstancePerLifetimeScope();
    }
}