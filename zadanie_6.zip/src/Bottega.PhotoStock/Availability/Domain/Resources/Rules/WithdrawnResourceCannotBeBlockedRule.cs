﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources.Rules;

public class WithdrawnResourceCannotBeBlockedRule : IBusinessRule
{
    private readonly bool _isWithdrawn;

    public WithdrawnResourceCannotBeBlockedRule(bool isWithdrawn)
    {
        _isWithdrawn = isWithdrawn;
    }

    public bool IsBroken() => _isWithdrawn;

    public string Code => "WithdrawnResourceCannotBeBlocked";
}