﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources.Events;

public class ResourceUnblockedDomainEvent : DomainEventBase
{
    public ResourceUnblockedDomainEvent(Guid resourceId)
    {
        ResourceId = resourceId;
    }
    
    public Guid ResourceId { get; }
}