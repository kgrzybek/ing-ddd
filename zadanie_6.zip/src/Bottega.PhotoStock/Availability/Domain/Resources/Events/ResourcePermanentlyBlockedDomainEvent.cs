﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources.Events;

public class ResourcePermanentlyBlockedDomainEvent : DomainEventBase
{
    public ResourcePermanentlyBlockedDomainEvent(Guid resourceId, Guid ownerId)
    {
        OwnerId = ownerId;
        ResourceId = resourceId;
    }
    
    public Guid ResourceId { get; }

    public Guid OwnerId { get; }
}