namespace Bottega.PhotoStock.Availability.Application.Resources.GetResource;

public class ResourceDto
{
    public Guid ResourceId { get; set; }
    
    public bool IsWithdrawn { get; set; }
    
    public DateTime? BlockadeDateTo { get; set; }
    
    public Guid? BlockadeOwnerId { get; set; }
}