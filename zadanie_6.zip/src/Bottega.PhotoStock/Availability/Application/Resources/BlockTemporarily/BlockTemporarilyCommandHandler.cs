using Availability.Domain.Resources;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using MediatR;

namespace Bottega.PhotoStock.Availability.Application.Resources.BlockTemporarily;

public class BlockTemporarilyCommandHandler : ICommandHandler<BlockTemporarilyCommand>
{
    private readonly IResourceRepository _resourceRepository;

    public BlockTemporarilyCommandHandler(IResourceRepository resourceRepository)
    {
        _resourceRepository = resourceRepository;
    }

    public async Task<Unit> Handle(BlockTemporarilyCommand command, CancellationToken cancellationToken)
    {
        var resource = await _resourceRepository.GetById(command.ResourceId);

        if (resource == null)
        {
            throw new ArgumentException("Invalid Resource Id");
        }
        
        resource.BlockTemporarily(command.OwnerId, command.Time);

        return Unit.Value;
    }
}