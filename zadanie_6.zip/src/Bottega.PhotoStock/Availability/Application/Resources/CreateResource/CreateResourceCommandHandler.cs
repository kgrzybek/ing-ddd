using Availability.Domain.Resources;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using MediatR;

namespace Bottega.PhotoStock.Availability.Application.Resources.CreateResource;

public class CreateResourceCommandHandler : ICommandHandler<CreateResourceCommand>
{
    private readonly IResourceRepository _resourceRepository;

    public CreateResourceCommandHandler(IResourceRepository resourceRepository)
    {
        _resourceRepository = resourceRepository;
    }

    public async Task<Unit> Handle(CreateResourceCommand command, CancellationToken cancellationToken)
    {
        var resource = Resource.Create(command.ResourceId);

        await _resourceRepository.Add(resource);

        return Unit.Value;
    }
}