using System.Data;

namespace Bottega.PhotoStock.BuildingBlocks.Application.Database;

public interface IDbConnectionFactory : IDisposable
{
    IDbConnection GetOpenConnection();
}