namespace Bottega.PhotoStock.BuildingBlocks.Domain;

public class BusinessRuleValidationException : Exception
{
    public IBusinessRule BrokenRule { get; }

    public BusinessRuleValidationException(IBusinessRule brokenRule)
    {
        BrokenRule = brokenRule;
    }

    public override string ToString()
    {
        return BrokenRule.Code;
    }
}