using Microsoft.Extensions.Configuration;

namespace Bottega.PhotoStock.BuildingBlocks.IntegrationTests;

public static class ConfigurationProvider
{
    public static string Get(string variableName)
    {
        var variableValue = GetOptional(variableName);

        if (string.IsNullOrEmpty(variableValue))
        {
            throw new ApplicationException(
                $"Configuration error. Environment variable '{variableName}' is not set. ");
        }

        return variableValue;
    }
    
    public static string? GetOptional(string variableName)
    {
        var configuration = BuildConfiguration();
        return configuration[variableName];
    }

    private static IConfiguration BuildConfiguration()
    {
        return new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
            .AddJsonFile("appsettings.Development.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables(prefix: "WORKSHOP_")
            .Build();
    }
}