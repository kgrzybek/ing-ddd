﻿namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public interface IDiscountPolicy
{
    Money Calculate(List<OrderLine> orderLines);
}