﻿using Bottega.PhotoStock.Scoring.Application.Customers.Documents.CreateCustomerScoringDocument;
using Bottega.PhotoStock.Scoring.Application.Customers.Documents.GetCustomerScoringDocument;
using Bottega.PhotoStock.Scoring.IntegrationTests.SeedWork;
using FluentAssertions;
using NUnit.Framework;

namespace Bottega.PhotoStock.Scoring.IntegrationTests.Customers.Documents;

public class CreateCustomerScoringDocumentTests : TestBase
{
    [Test]
    public async Task WhenCreateCustomerScoring_ThenIsCreated()
    {
        // When
        var customerId = Guid.NewGuid();
        await ScoringModule.ExecuteCommand(new CreateCustomerScoringDocumentCommand(customerId));
        
        // Then
        var scoring = await ScoringModule.ExecuteQuery(new GetCustomerScoringDocumentQuery(customerId));
        scoring.CustomerId.Should().Be(customerId);
        scoring.LoanLimitValue.Should().Be(0);
        scoring.LoanLimitCurrencyCode.Should().Be("PLN");
    }
}