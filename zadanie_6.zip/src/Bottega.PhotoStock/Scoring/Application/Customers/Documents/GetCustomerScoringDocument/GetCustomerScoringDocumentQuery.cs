﻿using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.Documents;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Documents.GetCustomerScoringDocument;

public class GetCustomerScoringDocumentQuery : QueryBase<CustomerScoringDocumentSnapshot>
{
    public GetCustomerScoringDocumentQuery(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}