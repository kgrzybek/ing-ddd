using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Dapper;

namespace Bottega.PhotoStock.Scoring.Application.Customers.GetCustomerScoring;

public class GetCustomerScoringQueryHandler : IQueryHandler<GetCustomerScoringQuery, CustomerScoringDto>
{
    private readonly IDbConnectionFactory _connectionFactory;

    public GetCustomerScoringQueryHandler(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<CustomerScoringDto> Handle(GetCustomerScoringQuery query, CancellationToken cancellationToken)
    {
        var connection = _connectionFactory.GetOpenConnection();

        const string sql = $@"SELECT 
                  customer_scoring.customer_id {nameof(CustomerScoringDto.CustomerId)},
                  customer_scoring.loan_limit_value {nameof(CustomerScoringDto.LoanLimitValue)},
                  customer_scoring.loan_limit_currency {nameof(CustomerScoringDto.LoanLimitCurrencyCode)}
                  FROM scoring.customer_scorings customer_scoring  
                  WHERE customer_scoring.customer_id = :customerId";
        
        return await connection.QuerySingleAsync<CustomerScoringDto>(sql, new
        {
            query.CustomerId
        });
    }
}