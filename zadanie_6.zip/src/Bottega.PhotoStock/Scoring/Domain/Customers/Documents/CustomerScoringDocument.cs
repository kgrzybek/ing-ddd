﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Scoring.Domain.Customers.Events;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Newtonsoft.Json;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.Documents;

public class CustomerScoringDocument : DocumentEntity
{
    public Guid CustomerId { get; private set; }

    [JsonProperty] 
    private Money _loanLimit;

    private CustomerScoringDocument()
    {
        // Only for Marten.
    }
    
    private CustomerScoringDocument(Guid customerId, Money loanLimit)
    {
        CustomerId = customerId;
        _loanLimit = loanLimit;
    }

    public static CustomerScoringDocument Create(Guid customerId)
    {
        return new CustomerScoringDocument(
            customerId,
            Money.Of(0));
    }

    public List<IDomainEvent> ChangeLoanLimit(
        ILoanLimitPolicy loanLimitPolicy)
    {
        var newLoanLimit = loanLimitPolicy.Calculate();

        if (_loanLimit != newLoanLimit)
        {
            _loanLimit = newLoanLimit;

            return OneDomainEvent(new CustomerLoanLimitChangeDomainEvent(newLoanLimit.Amount));
        }

        return NoDomainEvents();
    }

    public CustomerScoringDocumentSnapshot ToSnapshot()
    {
        return new CustomerScoringDocumentSnapshot(CustomerId, _loanLimit.Amount, _loanLimit.CurrencyCode);
    }
}