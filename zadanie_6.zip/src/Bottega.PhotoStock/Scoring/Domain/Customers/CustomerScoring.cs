﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Scoring.Domain.Customers.Events;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

namespace Bottega.PhotoStock.Scoring.Domain.Customers;

public class CustomerScoring : AggregateRootBase
{
    public Guid CustomerId { get; private set; }

    private Money _loanLimit;

    private CustomerScoring()
    {
        // Only for EF.
    }
    
    private CustomerScoring(Guid customerId, Money loanLimit)
    {
        CustomerId = customerId;
        _loanLimit = loanLimit;
    }

    public static CustomerScoring Create(Guid customerId)
    {
        return new CustomerScoring(
            customerId,
            Money.Of(0));
    }

    public void ChangeLoanLimit(
        ILoanLimitPolicy loanLimitPolicy)
    {
        var newLoanLimit = loanLimitPolicy.Calculate();

        if (_loanLimit != newLoanLimit)
        {
            _loanLimit = newLoanLimit;
            
            this.AddDomainEvent(new CustomerLoanLimitChangeDomainEvent(newLoanLimit.Amount));
        }
    }
}