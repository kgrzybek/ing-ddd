﻿namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public record Percentage
{
    public decimal Value { get; }

    public decimal Fraction { get; }
    
    private Percentage()
    {
    }
    
    private Percentage(decimal value)
    {
        Value = Math.Round(value, 4, MidpointRounding.AwayFromZero);
        Fraction = Value / 100;
    }

    public static Percentage FromFraction(decimal fraction)
    {
        return new Percentage(fraction * 100);
    }

    public static Percentage Of(decimal value)
    {
        return new Percentage(value);
    }

    public static Percentage Of(int value)
    {
        return new Percentage(value);
    }

    public static bool operator >(Percentage a, int b) => a.Value > b;

    public static bool operator <(Percentage a, int b) => a.Value < b;

    public static bool operator >(Percentage a, Percentage b) => a.Value > b.Value;

    public static bool operator <(Percentage a, Percentage b) => a.Value < b.Value;

    public static bool operator >=(Percentage a, Percentage b) => a.Value >= b.Value;

    public static bool operator <=(Percentage a, Percentage b) => a.Value <= b.Value;

    public static Percentage operator +(Percentage a, Percentage b) => new Percentage(a.Value + b.Value);
    
    public static Percentage operator -(Percentage a, Percentage b) => new Percentage(a.Value - b.Value);

    public static Percentage operator *(Percentage a, Percentage b) => FromFraction(a.Fraction * b.Fraction);

    public static decimal operator *(Percentage a, decimal b) => a.Fraction * b;
    
    public static decimal operator *(decimal a, Percentage b) => a * b.Fraction;

    public override string ToString()
    {
        return $"{this.Value}%";
    }
}