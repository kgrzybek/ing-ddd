﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Scoring.Domain.Customers;

public interface ILoanLimitConfigurationRepository : IRepository
{
    public Task Add(LoanLimitConfiguration loanLimitConfiguration);
}