﻿using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Bottega.PhotoStock.Scoring.Domain.Customers.Orders;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Domain.Customers.Orders;

public class CustomerOrderEntityTypeConfiguration : IEntityTypeConfiguration<CustomerOrder>
{
    public void Configure(EntityTypeBuilder<CustomerOrder> builder)
    {
        builder.ToTable("customer_orders");
        
        builder.HasKey(x => x.OrderId);
        builder.Property(x => x.OrderId).ValueGeneratedNever();

        builder.Property("_customerId").HasColumnName("customer_id");

        builder.OwnsOne<Money>("_orderValue", property =>
        {
            property.Property(x => x.Amount).HasColumnName("order_value");
            property.Property(x => x.CurrencyCode).HasColumnName("order_currency");
        });
    }
}