using System.Reflection;
using Bottega.PhotoStock.Scoring.Application;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration;

public static class Assemblies
{
    public static readonly Assembly Application = typeof(IScoringModule).Assembly;
    public static readonly Assembly Infrastructure = typeof(ScoringModule).Assembly;
}