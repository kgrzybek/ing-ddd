using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;

internal static class QueryExecutor
{
    internal static async Task<TResult> ExecuteQueryAsync<TResult>(
        IQuery<TResult> query, CancellationToken cancellationToken = default)
    {
        await using var scope = ScoringCompositionRoot.BeginLifetimeScope();
        
        var mediator = scope.Resolve<IMediator>();
        
        return await mediator.Send(query, cancellationToken);
    }
}