using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Processing.UnitOfWorkDecorators;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Mediation;

internal static class MediatorContainerBuilderExtensions
{
    internal static void RegisterHandlerDecorators(this ContainerBuilder builder)
    {
        builder.RegisterPipelineBehaviors(
            typeof(UnitOfWorkCommandHandlerDecorator.WithoutResult<>),
            typeof(UnitOfWorkCommandHandlerDecorator.WithResult<,>));
    }
}