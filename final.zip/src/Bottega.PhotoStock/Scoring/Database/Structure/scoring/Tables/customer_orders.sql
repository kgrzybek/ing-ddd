CREATE TABLE scoring.customer_orders (
    order_id UUID NOT NULL,
    customer_id UUID NOT NULL,
    order_value DECIMAL(18, 2) NOT NULL,
    order_currency VARCHAR(20) NOT NULL,
    CONSTRAINT pk_scoring_customer_orders_order_id PRIMARY KEY (order_id)
);