CREATE TABLE scoring.loan_limit_thresholds (
   id UUID NOT NULL,
   from_value DECIMAL(18, 2) NOT NULL,
   from_currency VARCHAR(20) NOT NULL,
   to_value DECIMAL(18, 2) NOT NULL,
   to_currency VARCHAR(20) NOT NULL,
   loan_limit_value DECIMAL(18, 2) NOT NULL,
   loan_limit_currency VARCHAR(20) NOT NULL,
   CONSTRAINT pk_scoring_loan_limit_thresholds_id PRIMARY KEY (id)
);