CREATE TABLE scoring.inbox_messages (
    id UUID NOT NULL,
    occurred_at TIMESTAMP NOT NULL,
    type VARCHAR(200) NOT NULL,
    data TEXT NOT NULL,
    start_processed_at TIMESTAMP NULL,
    finish_processed_at TIMESTAMP NULL,
    error TEXT NULL,
    CONSTRAINT pk_scoring_inbox_messages PRIMARY KEY (id)
);
