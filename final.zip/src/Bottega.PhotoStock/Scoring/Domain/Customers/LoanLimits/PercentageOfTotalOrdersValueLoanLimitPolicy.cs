namespace Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;

public class PercentageOfTotalOrdersValueLoanLimitPolicy : ILoanLimitPolicy
{
    private readonly Percentage _percentage;
    
    private readonly List<OrderData> _orders;

    public PercentageOfTotalOrdersValueLoanLimitPolicy(Percentage percentage, List<OrderData> orders)
    {
        _percentage = percentage;
        _orders = orders;
    }

    public Money Calculate()
    {
        var allOrdersValue = _orders.Select(x => x.Value).Sum();

        return _percentage * allOrdersValue;
    }
}