﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.Orders;

public interface ICustomerOrderRepository : IRepository
{
    public Task Add(CustomerOrder customerOrder);
}