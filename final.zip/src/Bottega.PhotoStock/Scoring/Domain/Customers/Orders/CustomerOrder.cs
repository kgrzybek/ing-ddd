﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Bottega.PhotoStock.Scoring.Domain.Customers.Orders.Events;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.Orders;

public class CustomerOrder : Entity
{
    public Guid OrderId { get; private set; }

    private Guid _customerId;

    private Money _orderValue;

    private CustomerOrder()
    {
        // Only for EF.
    }

    private CustomerOrder(
        Guid orderId,
        Guid customerId,
        Money orderValue)
    {
        OrderId = orderId;
        _customerId = customerId;
        _orderValue = orderValue;
        
        this.AddDomainEvent(new OrderRegisteredDomainEvent(customerId));
    }

    public static CustomerOrder RegisterOrder(Guid orderId, Guid customerId, Money value)
    {
        return new CustomerOrder(orderId, customerId, value);
    }
}