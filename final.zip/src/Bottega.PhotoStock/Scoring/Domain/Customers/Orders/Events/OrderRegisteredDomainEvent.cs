﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.Orders.Events;

public class OrderRegisteredDomainEvent : DomainEventBase
{
    public OrderRegisteredDomainEvent(Guid customerId)
    {
        CustomerId = customerId;
    }

    public Guid CustomerId { get; }
}