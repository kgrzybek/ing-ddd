﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Scoring.Domain.Customers.Events;

public class CustomerLoanLimitChangeDomainEvent : DomainEventBase
{
    public CustomerLoanLimitChangeDomainEvent(decimal newLoanLimitAmount)
    {
        NewLoanLimitAmount = newLoanLimitAmount;
    }

    public decimal NewLoanLimitAmount { get; }
}