using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.InternalCommands;
using Quartz;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Quartz.Jobs;

[DisallowConcurrentExecution]
internal class ProcessInternalCommandsSequentiallyJob : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        await CommandExecutor.Execute(
            new ProcessInternalCommandsSequentiallyCommand(),
            context.CancellationToken);
    }
}