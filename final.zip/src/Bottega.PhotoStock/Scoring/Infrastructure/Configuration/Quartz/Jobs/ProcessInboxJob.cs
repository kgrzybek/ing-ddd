using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Inbox;
using Quartz;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Quartz.Jobs;

[DisallowConcurrentExecution]
internal class ProcessInboxJob : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        await CommandExecutor.Execute(new ProcessInboxCommand(), context.CancellationToken);
    }
}