using Autofac;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.MessageBus;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Inbox;

internal class InboxModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        var map = InboxMessagesMap.GetMapping();
        
        builder.RegisterType<InboxMessagesMapper>()
            .WithParameter("map", map)
            .SingleInstance();
    }
}