using System.Diagnostics;
using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Application.Integration;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Inbox;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.MessageBus;
using Dapper;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Inbox;

internal class ProcessInboxCommandHandler : ICommandHandler<ProcessInboxCommand>
{
    private readonly InboxMessagesMapper _inboxMessagesMapper;
    
    private readonly IDbConnectionFactory _sqlConnectionFactory;

    public ProcessInboxCommandHandler(
        InboxMessagesMapper inboxMessagesMapper,
        IDbConnectionFactory sqlConnectionFactory)
    {
        _inboxMessagesMapper = inboxMessagesMapper;
        _sqlConnectionFactory = sqlConnectionFactory;
    }
    
    public async Task<Unit> Handle(ProcessInboxCommand command, CancellationToken cancellationToken)
    {
        await using var scope = ScoringCompositionRoot.BeginLifetimeScope();
        var context = scope.Resolve<ScoringContext>();

        var messages = context.InboxMessages
            .Where(o => o.StartProcessedAt == null)
            .OrderBy(o => o.OccurredAt)
            .Take(2000)
            .AsNoTracking()
            .ToList();

        if (!messages.Any())
        {
            return Unit.Value;
        }
        
        var stopwatch = new Stopwatch();
        stopwatch.Start();
        
        foreach (var message in messages)
        {
            try
            {
                await using var innerScope = scope.BeginLifetimeScope();
                
                var mediator = innerScope.Resolve<IMediator>();
                var unitOfWork = innerScope.Resolve<IUnitOfWork>();
                var innerContext = innerScope.Resolve<ScoringContext>();

                innerContext.InboxMessages.Attach(message);
                
                message.SetAsProcessing(DateTime.Now);
                await HandleMessage(message, mediator, cancellationToken);
                message.SetAsProcessed(DateTime.Now);
            
                await unitOfWork.CommitAsync(cancellationToken);
            }
            catch (Exception exc)
            {  
                message.SetAsProcessedWithError(DateTime.Now, exc.ToString());
            
                using var connection = _sqlConnectionFactory.GetOpenConnection();
                await connection.ExecuteAsync(
                    @"UPDATE scoring.inbox_messages
                        SET
                            start_processed_at = :startProcessedAt,
                            finish_processed_at = :finishProcessedAt,
                            error = :error
                        WHERE id = :id",
                    new
                    {
                        id = message.Id,
                        startProcessedAt = message.StartProcessedAt,
                        finishProcessedAt = message.FinishProcessedAt,
                        error = message.Error
                    });
            }
        }
        
        stopwatch.Stop();
        
        return Unit.Value;
    }

    private async Task HandleMessage(
        InboxMessage message,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var type = _inboxMessagesMapper.GetType(message.Type);
                
        var @event = Deserializer.Deserialize(message.Data, type!) as IntegrationEvent
                     ?? throw new InvalidOperationException($"Event of type {type!.Name} is not a {nameof(IntegrationEvent)}.");

        await mediator.Publish(@event, cancellationToken);
    }
}