using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.Sales.IntegrationEvents;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Inbox;

internal static class InboxMessagesMap
{
    public static BiDictionary<string, Type> GetMapping()
    {
        var mapping = new BiDictionary<string, Type>
        {
            { "Sales.OrderPaid", typeof(OrderPaidIntegrationEvent) },
        };

        return mapping;
    }
}