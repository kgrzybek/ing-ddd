using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Outbox;

public class ProcessOutboxCommand : CommandBase
{
}