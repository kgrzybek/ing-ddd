using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Integration;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.MessageBus;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Scheduling;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;

public class ProcessingModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterScope<DomainEventsDispatcher, IDomainEventsDispatcher>();
        builder.RegisterScope<DomainEventsAccessor, IDomainEventsAccessor>();
        builder.RegisterScope<DomainEventNotificationsDispatcher, IDomainEventNotificationsDispatcher>();
        builder.RegisterScope<CommandScheduler, ICommandScheduler>();
        
        builder.RegisterType<InMemoryMessagesBusClient>()
            .As<IMessagesBusClient>()
            .SingleInstance();
        
        builder.RegisterAssemblyTypes(Assemblies.Application)
            .AsClosedTypesOf(typeof(IDomainEventNotification<>))
            .InstancePerDependency();
    }
}