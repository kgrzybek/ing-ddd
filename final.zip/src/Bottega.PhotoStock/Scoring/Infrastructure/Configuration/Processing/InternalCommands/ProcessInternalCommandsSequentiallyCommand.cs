using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.InternalCommands;

public class ProcessInternalCommandsSequentiallyCommand : CommandBase
{
}