using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;
using Dapper;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.InternalCommands;

internal class ProcessInternalCommandsSequentiallyCommandHandler : ICommandHandler<ProcessInternalCommandsSequentiallyCommand>
{
    private readonly IInternalCommandsMapper _internalCommandsMapper;
    
    private readonly IDbConnectionFactory _sqlConnectionFactory;

    public ProcessInternalCommandsSequentiallyCommandHandler(
        IInternalCommandsMapper internalCommandsMapper,
        IDbConnectionFactory sqlConnectionFactory)
    {
        _internalCommandsMapper = internalCommandsMapper;
        _sqlConnectionFactory = sqlConnectionFactory;
    }

    public async Task<Unit> Handle(ProcessInternalCommandsSequentiallyCommand commandSequentially, CancellationToken cancellationToken)
    {
        await using var scope = ScoringCompositionRoot.BeginLifetimeScope();
        var context = scope.Resolve<ScoringContext>();
        
        var internalCommandsList = context.InternalCommands
            .Where(i => i.StartProcessedAt == null)
            .OrderBy(i => i.EnqueueDate)
            .Take(2000)
            .AsNoTracking()
            .ToList();
        
        if (!internalCommandsList.Any())
        {
            return Unit.Value;
        }

        foreach (var internalCommand in internalCommandsList)
        {
            try
            {
                await using var innerScope = scope.BeginLifetimeScope();
                var unitOfWork = innerScope.Resolve<IUnitOfWork>();
                var innerContext = innerScope.Resolve<ScoringContext>();

                innerContext.InternalCommands.Attach(internalCommand);

                internalCommand.SetAsProcessing(DateTime.Now);
                await ProcessCommand(internalCommand, cancellationToken);
                internalCommand.SetAsProcessed(DateTime.Now);
                
                await unitOfWork.CommitAsync(cancellationToken);
            }
            catch (Exception exc)
            {
                internalCommand.SetAsProcessedWithError(DateTime.Now, exc.ToString());

                using var connection = _sqlConnectionFactory.GetOpenConnection();
                await connection.ExecuteAsync(
                    @"UPDATE customers.internal_commands
                        SET
                            start_processed_at = :startProcessedAt,
                            finish_processed_at = :finishProcessedAt,
                            error = :error
                        WHERE id = :id",
                    new
                    {
                        id = internalCommand.Id,
                        startProcessedAt = internalCommand.StartProcessedAt,
                        finishProcessedAt = internalCommand.FinishProcessedAt,
                        error = internalCommand.Error
                    });
            }
        }
        
        return Unit.Value;
    }
    
    private async Task ProcessCommand(InternalCommand internalCommand, CancellationToken cancellationToken)
    {
        var type = _internalCommandsMapper.GetType(internalCommand.Type);
        var dynamicCommand = Deserializer.Deserialize(internalCommand.Data, type);

        var sleepDelays = new[]
        {
            TimeSpan.FromSeconds(1),
            TimeSpan.FromSeconds(1),
        };
        
        if (dynamicCommand is ICommand command)
        {
            await CommandExecutor.Execute(
                command,
                cancellationToken);
            
            return;
        }
        
        if (dynamicCommand is ICommand<Guid> genericCommand)
        {
            await CommandExecutor.Execute(
                genericCommand,
                cancellationToken);
            
            return;
        }
        
        throw new InvalidOperationException($"Type {type.Name} is not implemented an {nameof(ICommand)}");
    }
}