using Bottega.PhotoStock.BuildingBlocks.Infrastructure;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.MessageBus;

public class InboxMessagesMapper
{
    private readonly BiDictionary<string, Type> _map;

    public InboxMessagesMapper(BiDictionary<string, Type> map)
    {
        _map = map;
    }

    public string GetName(Type type)
    {
        return _map.GetBySecond(type);
    }

    public Type GetType(string name)
    {
        return _map.GetByFirst(name);
    }

    public string? TryGetName(Type type)
    {
        return _map.TryGetBySecond(type, out var name) ? name : null;
    }

    public Type? TryGetType(string name)
    {
        return _map.TryGetByFirst(name, out var type) ? type : null;
    }

    public bool HasMapped(Type type) => TryGetName(type) != null;
}