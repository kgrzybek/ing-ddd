using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Integration;
using Bottega.PhotoStock.Sales.IntegrationEvents;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.MessageBus;

internal static class MessageBusStartup
{
    internal static void Initialize()
    {
        SubscribeToIntegrationEvents();
    }

    private static void SubscribeToIntegrationEvents()
    {
        var scope = ScoringCompositionRoot.BeginLifetimeScope();
        var eventBus = scope.Resolve<IMessagesBusClient>();
        var inboxMessagesMapper = scope.Resolve<InboxMessagesMapper>();

        SubscribeToIntegrationEvent<OrderPaidIntegrationEvent>(eventBus, inboxMessagesMapper);
    }

    private static void SubscribeToIntegrationEvent<T>(
        IMessagesBusClient messagesBusClient,
        InboxMessagesMapper inboxMessagesMapper)
        where T : IntegrationEvent
    {
        var type = typeof(T);
        if (!inboxMessagesMapper.HasMapped(type))
        {
            throw new ApplicationException($"{type.FullName} is not mapped.");
        }
        
        messagesBusClient.Subscribe(new IntegrationEventGenericHandler<T>(inboxMessagesMapper));
    }
}