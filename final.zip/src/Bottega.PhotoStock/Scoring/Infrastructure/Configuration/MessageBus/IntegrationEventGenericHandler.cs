using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Integration;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Inbox;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;
using Npgsql;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.MessageBus;

internal class IntegrationEventGenericHandler<T> : IIntegrationEventHandler<T>
    where T : IntegrationEvent
{
    private readonly InboxMessagesMapper _inboxMessagesMapper;

    public IntegrationEventGenericHandler(InboxMessagesMapper inboxMessagesMapper)
    {
        _inboxMessagesMapper = inboxMessagesMapper;
    }

    public async Task Handle(T @event, CancellationToken cancellationToken)
    {
        await using var scope = ScoringCompositionRoot.BeginLifetimeScope();

        var type = @event.GetType().FullName;
        var data = Serializer.Serialize(@event);

        var context = scope.Resolve<ScoringContext>();
        var unitOfWork = scope.Resolve<IUnitOfWork>();

        var typeName = _inboxMessagesMapper.GetName(@event.GetType());
        var inboxMessage = InboxMessage.Create(
            @event.Id,
            @event.OccurredOn,
            typeName,
            data);

        await context.InboxMessages.AddAsync(inboxMessage, cancellationToken);
        
        try
        {
            await unitOfWork.CommitAsync(cancellationToken);
        }
        catch(Exception ex)
        {
            if (ex.GetBaseException() is PostgresException postgresException)
            {
                const string uniqueKeyViolationCode = "23505";
                if (postgresException.SqlState == uniqueKeyViolationCode)
                {
                    return;
                }
            }

            throw;
        }
    }
}