﻿using Autofac;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Mediation;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.MessageBus;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Inbox;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.InternalCommands;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Processing.Outbox;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Quartz;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration;

public static class ScoringStartup
{
    private static IContainer? _container;

    public static async Task Initialize(
        string connectionString,
        int processingIntervalMilliseconds,
        bool runQuartz = true)
    {
        ConfigureCompositionRoot(
            connectionString);
        
        MessageBusStartup.Initialize();
        
        if (runQuartz)
        {
            await QuartzStartup.Initialize(processingIntervalMilliseconds);
        }
    }

    private static void ConfigureCompositionRoot(
        string connectionString)
    {
        var containerBuilder = new ContainerBuilder();
        
        containerBuilder.RegisterModule(new DataAccessModule(connectionString));
        containerBuilder.RegisterModule(new MediatorModule());
        containerBuilder.RegisterModule(new InboxModule());
        containerBuilder.RegisterModule(new ProcessingModule());
        containerBuilder.RegisterModule(new InternalCommandModule());
        containerBuilder.RegisterModule(new OutboxModule());

        _container = containerBuilder.Build();

        ScoringCompositionRoot.SetContainer(_container);
    }
}