﻿using Bottega.PhotoStock.Scoring.Domain.Customers.Documents;
using Marten;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;

internal static class DocumentStoreFactory
{
    internal static DocumentStore Create(string connectionString)
    {
        return DocumentStore.For(storeOptions =>
        {
            storeOptions.Connection(connectionString);
            storeOptions.UseDefaultSerialization(
                nonPublicMembersStorage: 
                NonPublicMembersStorage.NonPublicSetters | 
                NonPublicMembersStorage.NonPublicConstructor);
            storeOptions.DatabaseSchemaName = "scoring";
            ConfigureCustomerScoringDocument(storeOptions);
        });
    }

    private static void ConfigureCustomerScoringDocument(StoreOptions storeOptions)
    {
        storeOptions.Schema
            .For<CustomerScoringDocument>()
            .Identity(x => x.CustomerId)
            .DocumentAlias("customer_scoring_documents")
            .UseOptimisticConcurrency(true);
    }
}