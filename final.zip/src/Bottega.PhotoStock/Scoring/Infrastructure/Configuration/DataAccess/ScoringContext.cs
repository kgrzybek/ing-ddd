using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Inbox;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.Orders;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;

public class ScoringContext :
    DbContext, 
    IDbContextWithInboxMessages,
    IDbContextWithInternalCommands,
    IDbContextWithOutboxMessages
{
    public DbSet<CustomerScoring> CustomerScorings { get; set; }
    
    public DbSet<LoanLimitConfiguration> LoanLimitConfigurations { get; set; }
    
    public DbSet<CustomerOrder> CustomerOrders { get; set; }
    
    public DbSet<InboxMessage> InboxMessages { get; set; }
    
    public DbSet<InternalCommand> InternalCommands { get; set; }
    
    public DbSet<OutboxMessage> OutboxMessages { get; set; }

#pragma warning disable CS8618
    public ScoringContext(DbContextOptions<ScoringContext> options)
        : base(options)
#pragma warning restore CS8618
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // optionsBuilder.UseLoggerFactory(_loggerFactory);
        // optionsBuilder.EnableDetailedErrors();
        // optionsBuilder.EnableSensitiveDataLogging();
    } 
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("scoring");
        modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
    }
}