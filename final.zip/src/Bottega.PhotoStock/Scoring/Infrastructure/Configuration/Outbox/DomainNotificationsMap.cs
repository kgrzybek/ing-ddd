using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.Scoring.Application.Customers.Orders.OrderRegistered;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Outbox;

internal static class DomainNotificationsMap
{
    public static BiDictionary<string, Type> GetMapping()
    {
        var mapping = new BiDictionary<string, Type>
        {
            { "OrderRegistered", typeof(OrderRegisteredNotification) }
        };

        return mapping;
    }
}