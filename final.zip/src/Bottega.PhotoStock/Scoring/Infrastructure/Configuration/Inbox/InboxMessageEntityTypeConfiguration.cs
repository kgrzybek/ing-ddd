using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Inbox;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.Inbox;

public class InboxMessageEntityTypeConfiguration : IEntityTypeConfiguration<InboxMessage>
{
    public void Configure(EntityTypeBuilder<InboxMessage> builder)
    {
        builder.ToTable("inbox_messages");

        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();
        
        builder.Property(x => x.Data);
        builder.Property(x => x.Error);
        builder.Property(x => x.Type);
        builder.Property(x => x.OccurredAt);
        builder.Property(x => x.StartProcessedAt);
        builder.Property(x => x.FinishProcessedAt);
    }
}