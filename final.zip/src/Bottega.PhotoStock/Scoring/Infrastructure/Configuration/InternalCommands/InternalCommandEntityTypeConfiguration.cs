using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.InternalCommands;

internal class InternalCommandEntityTypeConfiguration
    : IEntityTypeConfiguration<InternalCommand>
{
    public void Configure(EntityTypeBuilder<InternalCommand> builder)
    {
        builder.ToTable("internal_commands");

        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();

        builder.Property(x => x.Type);
        builder.Property(x => x.EnqueueDate);
        builder.Property(x => x.Data);
        builder.Property(x => x.Error);
        builder.Property(x => x.StartProcessedAt);
        builder.Property(x => x.FinishProcessedAt);
    }
}