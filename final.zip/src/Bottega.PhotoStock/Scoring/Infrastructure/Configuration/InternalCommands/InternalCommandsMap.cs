using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.Scoring.Application.Customers.ChangeCustomerScoring;
using Bottega.PhotoStock.Scoring.Application.Customers.Orders.RegisterOrder;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Configuration.InternalCommands;

internal static class InternalCommandsMap
{
    public static BiDictionary<string, Type> GetMapping()
    {
        var mapping = new BiDictionary<string, Type>()
        {
            { "RegisterOrder", typeof(RegisterOrderCommand) },
            { "ChangeCustomerScoring", typeof(ChangeCustomerScoringCommand) }
        };

        return mapping;
    }
}