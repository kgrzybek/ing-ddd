﻿using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Domain.Customers;

public class CustomerScoringEntityTypeConfiguration : IEntityTypeConfiguration<CustomerScoring>
{
    public void Configure(EntityTypeBuilder<CustomerScoring> builder)
    {
        builder.ToTable("customer_scorings");
        
        builder.HasKey(x => x.CustomerId);
        builder.Property(x => x.CustomerId).ValueGeneratedNever();

        builder.Property("_versionId").HasColumnName("version_id").IsConcurrencyToken();
        
        builder.OwnsOne<Money>("_loanLimit", property =>
        {
            property.Property(x => x.Amount).HasColumnName("loan_limit_value");
            property.Property(x => x.CurrencyCode).HasColumnName("loan_limit_currency");
        });
    }
}