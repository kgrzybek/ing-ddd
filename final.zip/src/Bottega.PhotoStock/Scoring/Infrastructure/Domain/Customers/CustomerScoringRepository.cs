﻿using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration.DataAccess;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Domain.Customers;

public class CustomerScoringRepository : ICustomerScoringRepository
{
    private readonly ScoringContext _scoringContext;

    public CustomerScoringRepository(ScoringContext scoringContext)
    {
        _scoringContext = scoringContext;
    }

    public async Task Add(CustomerScoring customerScoring)
    {
        await _scoringContext.CustomerScorings.AddAsync(customerScoring);
    }

    public async ValueTask<CustomerScoring?> GetById(Guid customerId)
    {
        return await _scoringContext.CustomerScorings.FindAsync(customerId);
    }
}