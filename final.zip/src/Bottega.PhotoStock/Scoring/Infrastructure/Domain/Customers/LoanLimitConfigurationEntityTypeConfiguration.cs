﻿using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Scoring.Infrastructure.Domain.Customers;

public class LoanLimitConfigurationEntityTypeConfiguration : IEntityTypeConfiguration<LoanLimitConfiguration>
{
    public void Configure(EntityTypeBuilder<LoanLimitConfiguration> builder)
    {
        builder.ToTable("loan_limit_configurations");
        
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();

        builder.OwnsOne<Percentage>("_percentageOfTotalOrders", property =>
        {
            property.Property(x => x.Fraction).HasColumnName("percentage_total_orders");
        });
        
        builder.OwnsOne<CurrentLoanLimitConfiguration>("_currentConfiguration", property =>
        {
            property.Property(x => x.Code).HasColumnName("current_configuration_code");
        });
    }
}