using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using FluentAssertions;

namespace Bottega.PhotoStock.Scoring.Domain.UnitTests.Customers.LoanLimits;

[TestFixture]
public class ByThresholdsLoanLimitPolicyTests
{
    [Test]
    public void GivenThresholdsAndOrders_WhenCalculate_ThenLoanLimitIsBasedOnThreshold()
    {
        // Given
        var thresholds = new List<Threshold>();
        thresholds.Add(new Threshold(Money.Of(0), Money.Of(499.99m), Money.Of(100)));
        thresholds.Add(new Threshold(Money.Of(500), Money.Of(999.99m), Money.Of(300)));
        thresholds.Add(new Threshold(Money.Of(1000), Money.Of(1000000), Money.Of(1000)));
        
        var orders = new List<OrderData>();
        orders.Add(new OrderData(Money.Of(550)));
        
        var policy = new ByThresholdsLoanLimitPolicy(thresholds, orders);

        // When
        var loanLimit = policy.Calculate();
        
        // Then
        loanLimit.Should().Be(Money.Of(300));
    }
}