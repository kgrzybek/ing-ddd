﻿using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.IntegrationTests;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration;
using Dapper;
using NUnit.Framework;

namespace Bottega.PhotoStock.Scoring.IntegrationTests.SeedWork;

public class TestBase
{
    private readonly string _connectionString;
    
    protected IDbConnectionFactory DbConnectionFactory { get; }
    
    protected ScoringModule ScoringModule { get; }
    
    protected TestBase()
    {
        _connectionString = "Host=localhost:9950;Username=SYSTEM;Password=p@ssword111;Database=postgres-db;";
        ScoringModule = new ScoringModule();
        DbConnectionFactory = new DbConnectionFactory(_connectionString);
    }
    
    [SetUp]
    public async Task BeforeEachTest()
    {
        SystemClock.Reset();

        await ClearDatabase();
        
        await ScoringStartup.Initialize(
            _connectionString,
            10);
    }

    private async Task ClearDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();
        
        const string sql = "DELETE FROM scoring.customer_scorings; " +
                           "DELETE FROM scoring.customer_orders; " +
                           "DELETE FROM scoring.loan_limit_configurations; " +
                           "DELETE FROM scoring.loan_limit_thresholds; " +
                           "DELETE FROM scoring.inbox_messages; " +
                           "DELETE FROM scoring.internal_commands; " +
                           "DELETE FROM scoring.outbox_messages; " +
                           "DELETE FROM scoring.blacklist_customers ";

        await connection.ExecuteScalarAsync(sql);
    }
}