﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Bottega.PhotoStock.Scoring.Domain.Customers.Orders;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Orders.RegisterOrder;

public class RegisterOrderCommandHandler : ICommandHandler<RegisterOrderCommand>
{
    private readonly ICustomerOrderRepository _customerOrderRepository;

    public RegisterOrderCommandHandler(ICustomerOrderRepository customerOrderRepository)
    {
        _customerOrderRepository = customerOrderRepository;
    }

    public async Task<Unit> Handle(RegisterOrderCommand command, CancellationToken cancellationToken)
    {
        var customerOrder = CustomerOrder.RegisterOrder(
            command.OrderId,
            command.CustomerId,
            Money.Of(command.OrderValue, command.OrderCurrency));

        await _customerOrderRepository.Add(customerOrder);

        return Unit.Value;
    }
}