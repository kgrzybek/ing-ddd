﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Orders.RegisterOrder;

public class RegisterOrderCommand : CommandBase, IEnqueueableCommand
{
    public RegisterOrderCommand(Guid orderId, Guid customerId, decimal orderValue, string orderCurrency)
    {
        OrderId = orderId;
        CustomerId = customerId;
        OrderValue = orderValue;
        OrderCurrency = orderCurrency;
    }

    public Guid OrderId { get; }
    
    public Guid CustomerId { get; }
    
    public decimal OrderValue { get; }
    
    public string OrderCurrency { get; }
}