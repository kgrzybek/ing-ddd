﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Scoring.Application.Customers.ChangeCustomerScoring;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Orders.OrderRegistered;

public class OrderRegisteredNotificationHandler : INotificationHandler<OrderRegisteredNotification>
{
    private readonly ICommandScheduler _commandScheduler;

    public OrderRegisteredNotificationHandler(ICommandScheduler commandScheduler)
    {
        _commandScheduler = commandScheduler;
    }

    public async Task Handle(OrderRegisteredNotification notification, CancellationToken cancellationToken)
    {
        await _commandScheduler.EnqueueAsync(
            new ChangeCustomerScoringCommand(notification.DomainEvent.CustomerId));
    }
}