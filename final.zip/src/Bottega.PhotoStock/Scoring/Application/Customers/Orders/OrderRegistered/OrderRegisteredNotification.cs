﻿using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.Scoring.Domain.Customers.Orders.Events;
using Newtonsoft.Json;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Orders.OrderRegistered;

public class OrderRegisteredNotification : DomainNotificationBase<OrderRegisteredDomainEvent>
{
    [JsonConstructor]
    public OrderRegisteredNotification(OrderRegisteredDomainEvent domainEvent, Guid id) : base(domainEvent, id)
    {
    }
}