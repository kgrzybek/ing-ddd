﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Sales.IntegrationEvents;
using Bottega.PhotoStock.Scoring.Application.Customers.Orders.RegisterOrder;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Orders.OrderPaid;

public class OrderPaidIntegrationEventHandler : INotificationHandler<OrderPaidIntegrationEvent>
{
    private readonly ICommandScheduler _commandScheduler;

    public OrderPaidIntegrationEventHandler(ICommandScheduler commandScheduler)
    {
        _commandScheduler = commandScheduler;
    }

    public async Task Handle(OrderPaidIntegrationEvent @event, CancellationToken cancellationToken)
    {
        await _commandScheduler.EnqueueAsync(new RegisterOrderCommand(
            @event.OrderId,
            @event.CustomerId,
            @event.Amount,
            @event.CurrencyCode));
    }
}