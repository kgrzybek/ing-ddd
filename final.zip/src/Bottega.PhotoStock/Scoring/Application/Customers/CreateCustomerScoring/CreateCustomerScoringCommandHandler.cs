using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.CreateCustomerScoring;

public class CreateCustomerScoringCommandHandler : ICommandHandler<CreateCustomerScoringCommand>
{
    private readonly ICustomerScoringRepository _customerScoringRepository;

    public CreateCustomerScoringCommandHandler(ICustomerScoringRepository customerScoringRepository)
    {
        _customerScoringRepository = customerScoringRepository;
    }

    public async Task<Unit> Handle(CreateCustomerScoringCommand command, CancellationToken cancellationToken)
    {
        var customerScoring = CustomerScoring.Create(command.CustomerId);

        await _customerScoringRepository.Add(customerScoring);

        return Unit.Value;
    }
}