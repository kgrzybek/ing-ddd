using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Scoring.Domain.Customers;
using Bottega.PhotoStock.Scoring.Domain.Customers.Documents;
using Marten;
using MediatR;

namespace Bottega.PhotoStock.Scoring.Application.Customers.Documents.CreateCustomerScoringDocument;

public class CreateCustomerScoringDocumentCommandHandler : ICommandHandler<CreateCustomerScoringDocumentCommand>
{
    private readonly IDocumentSession _documentSession;

    public CreateCustomerScoringDocumentCommandHandler(IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<Unit> Handle(CreateCustomerScoringDocumentCommand command, CancellationToken cancellationToken)
    {
        var customerScoring = CustomerScoringDocument.Create(command.CustomerId);
        
        _documentSession.Store(customerScoring);

        await _documentSession.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}