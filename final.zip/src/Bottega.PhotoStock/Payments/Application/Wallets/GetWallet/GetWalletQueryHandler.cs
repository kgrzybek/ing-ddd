using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Marten;

namespace Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;

public class GetWalletQueryHandler : IQueryHandler<GetWalletQuery, WalletReadModel>
{
    private readonly IDocumentSession _documentSession;

    public GetWalletQueryHandler(IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<WalletReadModel> Handle(GetWalletQuery query, CancellationToken cancellationToken)
    {
        var wallet = await _documentSession
            .Query<WalletReadModel>()
            .Where(x => x.PayerId == query.PayerId)
            .SingleAsync(token: cancellationToken);

        return wallet;
    }
}