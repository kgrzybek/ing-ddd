﻿using Bottega.PhotoStock.Payments.Domain.Wallets.Events;
using Marten.Events;
using Marten.Events.Aggregation;

namespace Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;

public class WalletReadModelProjection : SingleStreamAggregation<WalletReadModel>
{
    public WalletReadModel Create(IEvent<WalletAddedDomainEvent> walletAdded)
    {
        return new WalletReadModel
        {
            PayerId = walletAdded.Data.PayerId,
            Balance = walletAdded.Data.Balance.Amount,
            Loan =  walletAdded.Data.Loan.Amount,
            LoanLimit = walletAdded.Data.LoanLimit.Amount,
            RemainingLoanLimit = walletAdded.Data.RemainingLoanLimit.Amount
        };
    }
}