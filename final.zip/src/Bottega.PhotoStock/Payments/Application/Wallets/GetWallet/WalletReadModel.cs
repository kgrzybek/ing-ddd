using Bottega.PhotoStock.Payments.Domain.Wallets.Events;

namespace Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;

public class WalletReadModel
{
    public Guid PayerId { get; set; }
    
    public decimal Balance { get; set; }
    
    public decimal Loan { get; set; }
    
    public decimal RemainingLoanLimit { get; set; }
    
    public decimal LoanLimit { get; set; }

    public void Apply(BalanceDecreasedDomainEvent balanceDecreasedDomainEvent)
    {
        Balance -= balanceDecreasedDomainEvent.Amount.Amount;
    }
    
    public void Apply(FundsAddedDomainEvent @event)
    {
        Balance += @event.Amount.Amount;
    }
    
    public void Apply(LoanIncreasedDomainEvent @event)
    {
        Loan += @event.Amount.Amount;
        RemainingLoanLimit = LoanLimit - Loan;
    }
    
    public void Apply(LoanLimitSetDomainEvent @event)
    {
        LoanLimit = @event.LoanLimit.Amount;
        RemainingLoanLimit = LoanLimit - Loan;
    }
}