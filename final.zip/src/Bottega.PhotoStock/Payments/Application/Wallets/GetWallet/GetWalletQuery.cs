﻿using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;

public class GetWalletQuery : QueryBase<WalletReadModel>
{
    public GetWalletQuery(Guid payerId)
    {
        PayerId = payerId;
    }

    public Guid PayerId { get; }
}