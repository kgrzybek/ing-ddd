using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain;
using Bottega.PhotoStock.Payments.Domain.Wallets;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Wallets.SetLoanLimit;

public class SetLoanLimitCommandHandler : ICommandHandler<SetLoanLimitCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public SetLoanLimitCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(SetLoanLimitCommand command, CancellationToken cancellationToken)
    {
        var wallet = _eventSourcingAggregateRepository.Load<Wallet>(command.PayerId);
        
        wallet.SetLoanLimit(Money.Of(command.LoanLimit));

        await _eventSourcingAggregateRepository.Store(wallet);

        return Unit.Value;
    }
}