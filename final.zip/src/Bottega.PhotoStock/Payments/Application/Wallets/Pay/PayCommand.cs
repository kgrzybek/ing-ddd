﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Payments.Application.Wallets.Pay;

public class PayCommand : CommandBase
{
    public PayCommand(Guid payerId, decimal amount)
    {
        PayerId = payerId;
        Amount = amount;
    }

    public Guid PayerId { get; }
    
    public decimal Amount { get; }
}