using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Wallets;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Wallets.AddWallet;

public class AddWalletCommandHandler : ICommandHandler<AddWalletCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public AddWalletCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(AddWalletCommand command, CancellationToken cancellationToken)
    {
        var wallet = Wallet.Add(command.PayerId);

        await _eventSourcingAggregateRepository.Store(wallet);

        return Unit.Value;
    }
}