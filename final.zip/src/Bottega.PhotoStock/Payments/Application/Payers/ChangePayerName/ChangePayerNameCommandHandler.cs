﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Payers;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Payers.ChangePayerName;

public class ChangePayerNameCommandHandler : ICommandHandler<ChangePayerNameCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public ChangePayerNameCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(ChangePayerNameCommand command, CancellationToken cancellationToken)
    {
        var payer = _eventSourcingAggregateRepository.Load<Payer>(command.PayerId);
        
        payer.ChangeName(command.Name);

        await _eventSourcingAggregateRepository.Store(payer);

        return Unit.Value;
    }
}