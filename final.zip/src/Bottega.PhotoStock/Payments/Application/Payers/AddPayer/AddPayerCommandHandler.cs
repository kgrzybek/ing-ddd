﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Payers;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Payers.AddPayer;

public class AddPayerCommandHandler : ICommandHandler<AddPayerCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public AddPayerCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(AddPayerCommand command, CancellationToken cancellationToken)
    {
        var payer = Payer.Add(
            command.PayerId,
            command.Name);

        await _eventSourcingAggregateRepository.Store(payer);

        return Unit.Value;
    }
}