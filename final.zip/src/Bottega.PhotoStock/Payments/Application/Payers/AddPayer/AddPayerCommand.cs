﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Payments.Application.Payers.AddPayer;

public class AddPayerCommand : CommandBase
{
    public AddPayerCommand(Guid payerId, string name)
    {
        PayerId = payerId;
        Name = name;
    }

    public Guid PayerId { get; }
    
    public string Name { get; }
}