﻿using Bottega.PhotoStock.Payments.Domain.Payers.Events;
using Marten.Events;
using Marten.Events.Aggregation;

namespace Bottega.PhotoStock.Payments.Application.Payers.GetPayer;

public class PayerReadModelProjection : SingleStreamAggregation<PayerReadModel>
{
    public PayerReadModel Create(IEvent<PayerAddedDomainEvent> payerCreated)
    {
        return new PayerReadModel
        {
            PayerId = payerCreated.Data.PayerId,
            Name = payerCreated.Data.Name,
            IsActive = payerCreated.Data.IsActive
        };
    }
}