using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Marten;

namespace Bottega.PhotoStock.Payments.Application.Payers.GetPayer;

public class GetPayerQueryHandler : IQueryHandler<GetPayerQuery, PayerReadModel>
{
    private readonly IDocumentSession _documentSession;

    public GetPayerQueryHandler(IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<PayerReadModel> Handle(GetPayerQuery query, CancellationToken cancellationToken)
    {
        var wallet = await _documentSession
            .Query<PayerReadModel>()
            .Where(x => x.PayerId == query.PayerId)
            .SingleAsync(token: cancellationToken);

        return wallet;
    }
}