using Bottega.PhotoStock.Payments.Domain.Payers.Events;

namespace Bottega.PhotoStock.Payments.Application.Payers.GetPayer;

public class PayerReadModel
{
    public Guid PayerId { get; set; }
    
    public string Name { get; set; }
    
    public bool IsActive { get; set; }
    
    public void Apply(PayerNameChangedDomainEvent @event)
    {
        Name = @event.NewName;
    }
    
    public void Apply(PayerDeactivatedDomainEvent @event)
    {
        IsActive = false;
    }
}