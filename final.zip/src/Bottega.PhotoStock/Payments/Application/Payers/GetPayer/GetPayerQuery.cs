﻿using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Payments.Application.Payers.GetPayer;

public class GetPayerQuery : QueryBase<PayerReadModel>
{
    public GetPayerQuery(Guid payerId)
    {
        PayerId = payerId;
    }

    public Guid PayerId { get; }
}