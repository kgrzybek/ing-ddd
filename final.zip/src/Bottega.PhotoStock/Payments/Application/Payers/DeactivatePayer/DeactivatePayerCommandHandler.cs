﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Payers;
using MediatR;

namespace Bottega.PhotoStock.Payments.Application.Payers.DeactivatePayer;

public class DeactivatePayerCommandHandler : ICommandHandler<DeactivatePayerCommand>
{
    private readonly IEventSourcingAggregateRepository _eventSourcingAggregateRepository;

    public DeactivatePayerCommandHandler(IEventSourcingAggregateRepository eventSourcingAggregateRepository)
    {
        _eventSourcingAggregateRepository = eventSourcingAggregateRepository;
    }

    public async Task<Unit> Handle(DeactivatePayerCommand command, CancellationToken cancellationToken)
    {
        var payer = _eventSourcingAggregateRepository.Load<Payer>(command.PayerId);
        
        payer.Deactivate();

        await _eventSourcingAggregateRepository.Store(payer);

        return Unit.Value;
    }
}