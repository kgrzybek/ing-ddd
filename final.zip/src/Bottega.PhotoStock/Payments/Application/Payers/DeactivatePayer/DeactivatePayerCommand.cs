﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Payments.Application.Payers.DeactivatePayer;

public class DeactivatePayerCommand : CommandBase
{
    public DeactivatePayerCommand(Guid payerId)
    {
        PayerId = payerId;
    }

    public Guid PayerId { get; }
}