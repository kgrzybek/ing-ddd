﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Marten;

namespace Bottega.PhotoStock.Payments.Infrastructure.Events
{
    public sealed class AggregateRepository : IEventSourcingAggregateRepository
    {
        private readonly IDocumentStore _store;

        public AggregateRepository(IDocumentStore store)
        {
            _store = store;
        }

        public async Task Store(AggregateRootBaseEventSourcing aggregate)
        {
            using (var session = _store.OpenSession())
            {
                var events = aggregate.GetUncommittedEvents().ToArray();
                session.Events.Append(aggregate.Id, aggregate.Version, events);
                await session.SaveChangesAsync();
            }

            aggregate.ClearUncommittedEvents();
        }

        public T Load<T>(Guid id, int? version = null) where T : AggregateRootBaseEventSourcing
        {
            using var session = _store.LightweightSession();
            
            var aggregate = session.Events.AggregateStream<T>(id, version ?? 0);
            
            return aggregate ?? throw new InvalidOperationException($"No aggregate by id {id}.");
        }
    }
}