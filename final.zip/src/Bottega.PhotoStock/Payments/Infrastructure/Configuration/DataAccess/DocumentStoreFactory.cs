﻿using Bottega.PhotoStock.Payments.Application.Payers.GetPayer;
using Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;
using Marten;
using Marten.Events.Projections;

namespace Bottega.PhotoStock.Payments.Infrastructure.Configuration.DataAccess;

internal static class DocumentStoreFactory
{
    internal static DocumentStore Create(string connectionString)
    {
        return DocumentStore.For(storeOptions =>
        {
            storeOptions.Connection(connectionString);
            storeOptions.UseDefaultSerialization(
                nonPublicMembersStorage: 
                NonPublicMembersStorage.NonPublicSetters | 
                NonPublicMembersStorage.NonPublicConstructor);
            storeOptions.DatabaseSchemaName = "payments";
            RegisterSyncProjections(storeOptions);
            ConfigureWalletReadModel(storeOptions);
            ConfigurePayerReadModel(storeOptions);
        });
    }

    private static void RegisterSyncProjections(StoreOptions storeOptions)
    {
        storeOptions.Projections.Add(new WalletReadModelProjection(), ProjectionLifecycle.Inline);
        storeOptions.Projections.Add(new PayerReadModelProjection(), ProjectionLifecycle.Inline);
    }

    private static void ConfigureWalletReadModel(StoreOptions storeOptions)
    {
        storeOptions.Schema
            .For<WalletReadModel>()
            .Identity(x => x.PayerId)
            .DocumentAlias("wallets_read_model");
    }
    
    private static void ConfigurePayerReadModel(StoreOptions storeOptions)
    {
        storeOptions.Schema
            .For<PayerReadModel>()
            .Identity(x => x.PayerId)
            .DocumentAlias("payers_read_model");
    }
}