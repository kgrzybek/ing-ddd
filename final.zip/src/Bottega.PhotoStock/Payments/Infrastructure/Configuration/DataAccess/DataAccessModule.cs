using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Npgsql;
using Bottega.PhotoStock.Payments.Infrastructure.Events;
using Marten;

namespace Bottega.PhotoStock.Payments.Infrastructure.Configuration.DataAccess;

public class DataAccessModule : Module
{
    private readonly string _connectionString;

    public DataAccessModule(
        string connectionString)
    {
        _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
    }
    
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<DbConnectionFactory>()
            .WithParameter("connectionString", _connectionString)
            .As<IDbConnectionFactory>()
            .InstancePerLifetimeScope();
        
        RegisterMarten(builder);

        NpgsqlSwitches.RegisterEnableLegacyTimestampBehavior();
    }

    private void RegisterMarten(ContainerBuilder builder)
    {
        builder
            .Register(_ => DocumentStoreFactory.Create(_connectionString))
            .As<IDocumentStore>()
            .SingleInstance();
        
        builder
            .Register(factory => factory.Resolve<IDocumentStore>().LightweightSession())
            .As<IDocumentSession>()
            .InstancePerLifetimeScope();

        builder
            .Register(factory => factory.Resolve<IDocumentStore>().QuerySession())
            .As<IQuerySession>()
            .InstancePerLifetimeScope();
        
        builder
            .RegisterType<AggregateRepository>()
            .As<IEventSourcingAggregateRepository>()
            .InstancePerLifetimeScope();
    }
}