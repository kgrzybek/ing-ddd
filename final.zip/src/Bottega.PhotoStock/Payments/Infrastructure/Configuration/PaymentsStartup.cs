﻿using Autofac;
using Bottega.PhotoStock.Payments.Infrastructure.Configuration.DataAccess;
using Bottega.PhotoStock.Payments.Infrastructure.Configuration.Mediation;

namespace Bottega.PhotoStock.Payments.Infrastructure.Configuration;

public static class PaymentsStartup
{
    private static IContainer? _container;

    public static void Initialize(
        string connectionString)
    {
        ConfigureCompositionRoot(
            connectionString);
    }

    private static void ConfigureCompositionRoot(
        string connectionString)
    {
        var containerBuilder = new ContainerBuilder();
        
        containerBuilder.RegisterModule(new DataAccessModule(connectionString));
        containerBuilder.RegisterModule(new MediatorModule());

        _container = containerBuilder.Build();

        PaymentsCompositionRoot.SetContainer(_container);
    }
}