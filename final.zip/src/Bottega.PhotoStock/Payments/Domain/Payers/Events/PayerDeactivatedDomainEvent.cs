﻿namespace Bottega.PhotoStock.Payments.Domain.Payers.Events;

public class PayerDeactivatedDomainEvent
{
}