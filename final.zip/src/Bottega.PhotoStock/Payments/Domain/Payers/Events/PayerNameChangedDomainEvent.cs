﻿namespace Bottega.PhotoStock.Payments.Domain.Payers.Events;

public class PayerNameChangedDomainEvent
{
    public PayerNameChangedDomainEvent(string newName)
    {
        NewName = newName;
    }

    public string NewName { get; }
}