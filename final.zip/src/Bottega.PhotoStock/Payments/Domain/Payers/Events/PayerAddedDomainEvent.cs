﻿namespace Bottega.PhotoStock.Payments.Domain.Payers.Events;

public class PayerAddedDomainEvent
{
    public PayerAddedDomainEvent(Guid payerId, string name, bool isActive)
    {
        Name = name;
        IsActive = isActive;
        PayerId = payerId;
    }
    
    public Guid PayerId { get; }

    public string Name { get; }
    
    public bool IsActive { get; }
}