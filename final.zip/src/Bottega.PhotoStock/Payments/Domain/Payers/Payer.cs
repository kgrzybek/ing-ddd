﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Payers.Events;

namespace Bottega.PhotoStock.Payments.Domain.Payers;

public class Payer : AggregateRootBaseEventSourcing
{
    private string _name;
    
    private bool _isActive;

    private Payer()
    {
        // Only for Marten serialization.
    }

    private Payer(Guid id, string name, bool isActive)
    {
        var @event = new PayerAddedDomainEvent(
            id,
            name,
            isActive);

        Apply(@event);
        
        AddUncommittedEvent(@event);
    }

    private void Apply(PayerAddedDomainEvent @event)
    {
        Id = @event.PayerId;
        _name = @event.Name;
        _isActive = @event.IsActive;

        Version++;
    }

    public static Payer Add(
        Guid id,
        string name)
    {
        return new Payer(id, name, true);
    }

    public void ChangeName(string name)
    {
        var @event = new PayerNameChangedDomainEvent(name);
        
        Apply(@event);
        
        AddUncommittedEvent(@event);
    }

    public void Deactivate()
    {
        var @event = new PayerDeactivatedDomainEvent();
        
        Apply(@event);
        
        AddUncommittedEvent(@event);
    }

    private void Apply(PayerDeactivatedDomainEvent @event)
    {
        _isActive = false;

        Version++;
    }

    private void Apply(PayerNameChangedDomainEvent @event)
    {
        _name = @event.NewName;

        Version++;
    }
}