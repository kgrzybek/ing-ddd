﻿namespace Bottega.PhotoStock.Payments.Domain.Wallets.Events;

public class LoanLimitSetDomainEvent
{
    public LoanLimitSetDomainEvent(Money loanLimit)
    {
        LoanLimit = loanLimit;
    }
    
    public Money LoanLimit { get; }
}