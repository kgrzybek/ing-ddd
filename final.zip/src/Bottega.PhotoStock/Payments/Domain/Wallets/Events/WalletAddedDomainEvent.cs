﻿namespace Bottega.PhotoStock.Payments.Domain.Wallets.Events;

public class WalletAddedDomainEvent
{
    public WalletAddedDomainEvent(
        Guid payerId,
        Money balance,
        Money loanLimit,
        Money remainingLoanLimit,
        Money loan)
    {
        PayerId = payerId;
        Balance = balance;
        LoanLimit = loanLimit;
        RemainingLoanLimit = remainingLoanLimit;
        Loan = loan;
    }

    public Guid PayerId { get; }
    
    public Money Balance { get; }
    
    public Money LoanLimit { get; }
    
    public Money RemainingLoanLimit { get; }
    
    public Money Loan { get; }
}