﻿namespace Bottega.PhotoStock.Payments.Domain.Wallets.Events;

public class BalanceDecreasedDomainEvent
{
    public BalanceDecreasedDomainEvent(Money amount)
    {
        Amount = amount;
    }

    public Money Amount { get; }
}