﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Domain.Wallets.Events;
using Bottega.PhotoStock.Payments.Domain.Wallets.Rules;

namespace Bottega.PhotoStock.Payments.Domain.Wallets;

public class Wallet : AggregateRootBaseEventSourcing
{
    private Money _balance;

    private Money _loan;

    private Money _loanLimit;

    private Money _remainingLoanLimit;

    private Wallet()
    {
        // For Marten deserialization.
    }

    private Wallet(Guid payerId)
    {
        var @event = new WalletAddedDomainEvent(
            payerId,
            Money.Of(0), 
            Money.Of(0),
            Money.Of(0),
            Money.Of(0));

        Apply(@event);
        
        AddUncommittedEvent(@event);
    }
    
    public static Wallet Add(Guid payerId)
    {
        return new Wallet(payerId);
    }

    public void Apply(WalletAddedDomainEvent @event)
    {
        Id = @event.PayerId;
        _balance = Money.Of(@event.Balance);
        _loan = Money.Of(@event.Loan);
        _loanLimit = Money.Of(@event.LoanLimit);
        _remainingLoanLimit = Money.Of(@event.RemainingLoanLimit);
        
        Version++;
    }
    
    public void AddFunds(Money amount)
    {
        var @event = new FundsAddedDomainEvent(amount);
        Apply(@event);
            
        AddUncommittedEvent(@event);
    }

    public void Pay(Money amount)
    {
        CheckRule(new SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule(
            amount,
            _balance,
            _remainingLoanLimit
        ));
        
        if (_balance >= amount)
        {
            var @event = new BalanceDecreasedDomainEvent(amount);
            Apply(@event);
            
            AddUncommittedEvent(@event);
        }
        else if (_balance + _remainingLoanLimit >= amount)
        {
            var balanceDecreasedAmount = Money.Of(_balance);
            var balanceDecreasedEvent = new BalanceDecreasedDomainEvent(balanceDecreasedAmount);
            Apply(balanceDecreasedEvent);
            AddUncommittedEvent(balanceDecreasedEvent);
            
            _balance = Money.Of(0);
            var toLoan = amount - balanceDecreasedAmount;
            
            var loanIncreasedEvent = new LoanIncreasedDomainEvent(toLoan);
            
            Apply(loanIncreasedEvent);
            AddUncommittedEvent(loanIncreasedEvent);
        }
    }

    public void Apply(LoanIncreasedDomainEvent @event)
    {
        _loan += @event.Amount;
        _remainingLoanLimit -= _loanLimit - _loan;
        
        Version++;
    }

    public void SetLoanLimit(Money loanLimit)
    {
        var @event = new LoanLimitSetDomainEvent(loanLimit);
        Apply(@event);
            
        AddUncommittedEvent(@event);
    }
    
    public void Apply(BalanceDecreasedDomainEvent @event)
    {
        _balance -= @event.Amount;

        Version++;
    }
    
    public void Apply(FundsAddedDomainEvent @event)
    {
        _balance += @event.Amount;

        Version++;
    }
    
    public void Apply(LoanLimitSetDomainEvent @event)
    {
        _loanLimit = @event.LoanLimit;
        _remainingLoanLimit = _loanLimit - _loan;

        Version++;
    }
}