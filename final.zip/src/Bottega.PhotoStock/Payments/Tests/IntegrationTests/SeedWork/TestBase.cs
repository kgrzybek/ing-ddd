﻿using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.IntegrationTests;
using Bottega.PhotoStock.Payments.Infrastructure.Configuration;
using Dapper;

namespace Bottega.PhotoStock.Payments.IntegrationTests.SeedWork;

public class TestBase
{
    private readonly string _connectionString;
    
    protected IDbConnectionFactory DbConnectionFactory { get; }
    
    protected PaymentsModule PaymentsModule { get; }
    
    protected TestBase()
    {
        _connectionString = "Host=localhost:9950;Username=SYSTEM;Password=p@ssword111;Database=postgres-db;";
        PaymentsModule = new PaymentsModule();
        DbConnectionFactory = new DbConnectionFactory(_connectionString);
    }
    
    [SetUp]
    public async Task BeforeEachTest()
    {
        SystemClock.Reset();

        await ClearDatabase();
        
        PaymentsStartup.Initialize(_connectionString);
    }

    private async Task ClearDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();

        // Delete data from all Marten's generated tables.
        // const string sql = "DELETE FROM payments.mt_doc_deadletterevent; " +
        //                    "DELETE FROM payments.mt_doc_wallets_read_model; " +
        //                    "DELETE FROM payments.mt_event_progression; " +
        //                    "DELETE FROM payments.mt_events; " +
        //                    "DELETE FROM payments.mt_streams; ";
        //
        // await connection.ExecuteScalarAsync(sql);
    }
}