﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Payments.Application.Wallets.AddFunds;
using Bottega.PhotoStock.Payments.Application.Wallets.AddWallet;
using Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;
using Bottega.PhotoStock.Payments.Application.Wallets.Pay;
using Bottega.PhotoStock.Payments.Application.Wallets.SetLoanLimit;
using Bottega.PhotoStock.Payments.Domain.Wallets.Rules;
using Bottega.PhotoStock.Payments.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.IntegrationTests.Wallets;

[TestFixture]
public class PayTests : TestBase
{
    [Test]
    public async Task GivenWallet_WithEnoughFunds_WhenPay_ThenPaymentIsOk()
    {
        // Given
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddWalletCommand(payerId));
        
        await PaymentsModule.ExecuteCommand(new AddFundsCommand(payerId, 1000));
        
        // When
        await PaymentsModule.ExecuteCommand(new PayCommand(payerId, 400));
        
        // Then
        var wallet = await PaymentsModule.ExecuteQuery(new GetWalletQuery(payerId));
        wallet.PayerId.Should().Be(payerId);
        wallet.Balance.Should().Be(600);
    }
    
    [Test]
    public async Task GivenWallet_WithoutEnoughFunds_WhenPay_ThenPaymentFailed()
    {
        // Given
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddWalletCommand(payerId));
        
        await PaymentsModule.ExecuteCommand(new AddFundsCommand(payerId, 1000));
        
        // When
        Func<Task> pay = async () => await PaymentsModule.ExecuteCommand(new PayCommand(payerId, 1200));
        
        // Then
        await pay.Should().ThrowAsync<BusinessRuleValidationException>()
            .Where(x => 
                x.BrokenRule.GetType() == typeof(SumOfBalanceAndRemainingLoanMustBeGreaterOrEqualThanAmountRule));
    }
    
    [Test]
    public async Task GivenWallet_WithEnoughFundsTogetherWithLoan_WhenPay_ThenPaymentIsOk()
    {
        // Given
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddWalletCommand(payerId));
        
        await PaymentsModule.ExecuteCommand(new AddFundsCommand(payerId, 1000));
        
        await PaymentsModule.ExecuteCommand(new SetLoanLimitCommand(payerId, 500));
        
        // When
        await PaymentsModule.ExecuteCommand(new PayCommand(payerId, 1200));
        
        // Then
        var wallet = await PaymentsModule.ExecuteQuery(new GetWalletQuery(payerId));
        wallet.PayerId.Should().Be(payerId);
        wallet.Balance.Should().Be(0);
        wallet.Loan.Should().Be(200);
        wallet.RemainingLoanLimit.Should().Be(300);
        wallet.LoanLimit.Should().Be(500);
    }
}