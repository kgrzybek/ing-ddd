﻿using Bottega.PhotoStock.Payments.Application.Payers.AddPayer;
using Bottega.PhotoStock.Payments.Application.Payers.GetPayer;
using Bottega.PhotoStock.Payments.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.IntegrationTests.Payers;

public class AddPayerTests : TestBase
{
    [Test]
    public async Task WhenAddPayer_ThenIsAdded()
    {
        // When
        string name = "Payer name";
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddPayerCommand(payerId, name));
        
        // Then
        var payer = await PaymentsModule.ExecuteQuery(new GetPayerQuery(payerId));
        payer.Name.Should().Be(name);
        payer.IsActive.Should().BeTrue();
    }
}