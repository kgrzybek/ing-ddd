﻿using Bottega.PhotoStock.Payments.Application.Payers.AddPayer;
using Bottega.PhotoStock.Payments.Application.Payers.ChangePayerName;
using Bottega.PhotoStock.Payments.Application.Payers.DeactivatePayer;
using Bottega.PhotoStock.Payments.Application.Payers.GetPayer;
using Bottega.PhotoStock.Payments.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Payments.IntegrationTests.Payers;

public class DeactivatePayerTests : TestBase
{
    [Test]
    public async Task GivenPayer_WhenDeactivate_ThenIsDeactivated()
    {
        // Given
        string name = "Payer name";
        var payerId = Guid.NewGuid();
        await PaymentsModule.ExecuteCommand(new AddPayerCommand(payerId, name));
        
        // When
        await PaymentsModule.ExecuteCommand(new DeactivatePayerCommand(payerId));
        
        // Then
        var payer = await PaymentsModule.ExecuteQuery(new GetPayerQuery(payerId));
        payer.IsActive.Should().BeFalse();
    }
}