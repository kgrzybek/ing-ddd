﻿using Bottega.PhotoStock.Availability.Application.Resources.CreateResource;
using Bottega.PhotoStock.Payments.Application.Wallets.AddFunds;
using Bottega.PhotoStock.Payments.Application.Wallets.AddWallet;
using Bottega.PhotoStock.Payments.Application.Wallets.GetWallet;
using Bottega.PhotoStock.Sales.Application.Orders.AddDiscountConfiguration;
using Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;
using Bottega.PhotoStock.Sales.Application.Orders.GetOrder;
using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Bottega.PhotoStock.Scoring.Application.Customers.CreateCustomerScoring;
using Bottega.PhotoStock.Scoring.Application.Customers.CreateLoanLimitConfiguration;
using Bottega.PhotoStock.Scoring.Application.Customers.GetCustomerScoring;
using Bottega.PhotoStock.Scoring.Domain.Customers.LoanLimits;
using Bottega.PhotoStock.SystemTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.SystemTests.Orders;

[TestFixture]
public class CreateOrderTests : TestBase
{
    [Test]
    public async Task CreateOrderTest()
    {
        // Given
        var customerId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        await AvailabilityModule.ExecuteCommand(new CreateResourceCommand(productId));

        await ScoringModule.ExecuteCommand(new CreateLoanLimitConfigurationCommand(
            0.5m,
            CurrentLoanLimitConfiguration.Percentage.Code));

        await ScoringModule.ExecuteCommand(new CreateCustomerScoringCommand(customerId));
        
        await SalesModule.ExecuteCommand(new AddDiscountConfigurationCommand(
            DiscountPolicyConfiguration.NoDiscount.Code,
            0,
            0,
            0));

        await PaymentsModule.ExecuteCommand(new AddWalletCommand(customerId));
        await PaymentsModule.ExecuteCommand(new AddFundsCommand(customerId, 200));
        
        // When
        var orderLines = new List<OrderLineDto>();
        orderLines.Add(new OrderLineDto(productId, 2, 50));
        var orderId = await SalesModule.ExecuteCommand(new CreateOrderCommand(customerId, orderLines, "PLN"));

        await SalesModuleAsyncOperationHelper.WaitForProcessing(DbConnectionFactory);
        await ScoringModuleAsyncOperationHelper.WaitForProcessing(DbConnectionFactory);
        
        // Then
        var order = await SalesModule.ExecuteQuery(new GetOrderQuery(orderId));
        order.CustomerId.Should().Be(customerId);
        order.AfterDiscountValue.Should().Be(100);
        order.StatusCode.Should().Be(OrderStatus.Paid.Code);

        var wallet = await PaymentsModule.ExecuteQuery(new GetWalletQuery(customerId));
        wallet.Balance.Should().Be(100);

        var customerScoring = await ScoringModule.ExecuteQuery(new GetCustomerScoringQuery(customerId));
        customerScoring.LoanLimitValue.Should().Be(50);
    }
}