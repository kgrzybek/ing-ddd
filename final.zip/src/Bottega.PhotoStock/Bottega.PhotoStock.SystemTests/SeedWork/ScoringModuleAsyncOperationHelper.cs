using Bottega.PhotoStock.BuildingBlocks.Application.Database;

namespace Bottega.PhotoStock.SystemTests.SeedWork;

internal static class ScoringModuleAsyncOperationHelper
{
    private static readonly List<string> _waitQueries = new()
    {
        "SELECT COUNT(1) FROM scoring.internal_commands AS internal_command WHERE internal_command.finish_processed_at IS NULL;",
        "SELECT COUNT(1) FROM scoring.inbox_messages AS inbox_message WHERE inbox_message.finish_processed_at IS NULL;",
        "SELECT COUNT(1) FROM scoring.outbox_messages AS outbox_message WHERE outbox_message.finish_processed_at IS NULL;"
    };

    private static readonly List<string> _errorQueries = new()
    {
        @"SELECT internal_command.type, internal_command.error
                    FROM scoring.internal_commands AS internal_command
                    WHERE internal_command.error IS NOT NULL;",

        @"SELECT inbox_message.type, inbox_message.error
                    FROM scoring.inbox_messages AS inbox_message
                    WHERE inbox_message.error IS NOT NULL;",
        
        @"SELECT outbox_message.type, outbox_message.error FROM scoring.outbox_messages AS outbox_message
                    WHERE outbox_message.error IS NOT NULL;"
    };

    internal static async Task WaitForProcessing(
        IDbConnectionFactory connectionFactory,
        int timeoutInSeconds = 60)
    {
        using var connection = connectionFactory.GetOpenConnection();
        await AsyncOperationsHelper.WaitForProcessing(connection, _waitQueries, _errorQueries, timeoutInSeconds);
    }
}