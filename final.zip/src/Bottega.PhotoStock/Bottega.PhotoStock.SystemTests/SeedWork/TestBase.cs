﻿using Bottega.PhotoStock.Availability.Infrastructure.Configuration;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.IntegrationTests;
using Bottega.PhotoStock.Payments.Infrastructure.Configuration;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration;
using Bottega.PhotoStock.Scoring.Infrastructure.Configuration;
using Dapper;

namespace Bottega.PhotoStock.SystemTests.SeedWork;

public class TestBase
{
    private readonly string _connectionString;
    
    protected IDbConnectionFactory DbConnectionFactory { get; }
    
    protected ScoringModule ScoringModule { get; }
    
    protected SalesModule SalesModule { get; }
    
    protected AvailabilityModule AvailabilityModule { get; }
    
    protected PaymentsModule PaymentsModule { get; }
    
    protected TestBase()
    {
        _connectionString = "Host=localhost:9950;Username=SYSTEM;Password=p@ssword111;Database=postgres-db;";
        ScoringModule = new ScoringModule();
        SalesModule = new SalesModule();
        AvailabilityModule = new AvailabilityModule();
        PaymentsModule = new PaymentsModule();
        DbConnectionFactory = new DbConnectionFactory(_connectionString);
    }
    
    [SetUp]
    public async Task BeforeEachTest()
    {
        SystemClock.Reset();

        await ClearSalesDatabase();
        await ClearPaymentsDatabase();
        await ClearScoringDatabase();
        await ClearAvailabilityDatabase();
        
        await ScoringStartup.Initialize(
            _connectionString,
            10);
        
        await SalesStartup.Initialize(
            _connectionString, 
            null,
            null,
            10);
        
        AvailabilityStartup.Initialize(_connectionString);
        
        PaymentsStartup.Initialize(_connectionString);
    }
    
    [TearDown]
    public async Task AfterEachTest()
    {
        await SalesStartup.Stop();
    }

    private async Task ClearScoringDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();
        
        const string sql = "DELETE FROM scoring.customer_scorings; " +
                           "DELETE FROM scoring.customer_orders; " +
                           "DELETE FROM scoring.loan_limit_configurations; " +
                           "DELETE FROM scoring.loan_limit_thresholds; " +
                           "DELETE FROM scoring.inbox_messages; " +
                           "DELETE FROM scoring.internal_commands; " +
                           "DELETE FROM scoring.outbox_messages; " +
                           "DELETE FROM scoring.blacklist_customers ";

        await connection.ExecuteScalarAsync(sql);
    }
    
    private async Task ClearAvailabilityDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();

        const string sql = "DELETE FROM availability.resources; ";

        await connection.ExecuteScalarAsync(sql);
    }
    
    private async Task ClearPaymentsDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();

        // Delete data from all Marten's generated tables.
        // const string sql = "DELETE FROM payments.mt_doc_deadletterevent; " +
        //                    "DELETE FROM payments.mt_doc_wallets_read_model; " +
        //                    "DELETE FROM payments.mt_event_progression; " +
        //                    "DELETE FROM payments.mt_events; " +
        //                    "DELETE FROM payments.mt_streams; ";
        //
        // await connection.ExecuteScalarAsync(sql);
    }
    
    private async Task ClearSalesDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();

        const string sql = "DELETE FROM sales.discount_configurations; " +
                           "DELETE FROM sales.outbox_messages; " +
                           "DELETE FROM sales.internal_commands; " +
                           "DELETE FROM sales.orders; ";

        await connection.ExecuteScalarAsync(sql);
    }
}