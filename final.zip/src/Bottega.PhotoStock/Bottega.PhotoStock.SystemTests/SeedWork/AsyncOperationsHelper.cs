using System.Data;
using System.Diagnostics;
using System.Text;
using Dapper;

namespace Bottega.PhotoStock.SystemTests.SeedWork;

internal static class AsyncOperationsHelper
{
    public static async Task WaitForProcessing(IDbConnection connection, List<string> waitQueries, List<string> errorQueries, int timeoutInSeconds)
    {
        var counts = new Dictionary<int, int>();
        var allProcessed = false;
        
        var start = Stopwatch.StartNew();
        
        while (start.Elapsed.Seconds < timeoutInSeconds)
        {
            for(var i = 0; i < waitQueries.Count; i++)
            {
                var result = await connection.ExecuteScalarAsync<int>(waitQueries[i]);
                counts[i] = result;
            }

            if (counts.All(c => c.Value == 0))
            {
                allProcessed = true;
                break;
            }

            Thread.Sleep(20);
        }

        if (!allProcessed)
        {
            throw new Exception("Timeout for processing elapsed.");
        }

        var errors = await GetProcessingErrors(connection, errorQueries);

        if (!string.IsNullOrWhiteSpace(errors))
        {
            throw new Exception(errors);
        }
    }

    public static async Task<string?> GetProcessingErrors(IDbConnection connection, List<string> queries)
    {
        var errors = new List<(string, string)>();
        
        foreach (var query in queries)
        {
            var result = await connection.QueryAsync<(string, string)>(query);
            errors.AddRange(result);
        }

        if (!errors.Any())
        {
            return string.Empty;
        }

        errors = errors.Distinct().ToList();
        
        var errorMsgs = new StringBuilder();
        errorMsgs.AppendLine($"Async processes failed. {errors.Count} item(s) has errors.");

        for (var i = 0; i < errors.Count; i++)
        {
            var error = errors[i];
            errorMsgs.AppendLine($"Item [{i + 1}] of [{errors.Count}].");
            errorMsgs.AppendLine($"\tType: {error.Item1}");
            errorMsgs.AppendLine($"\tError: {error.Item2}");
            errorMsgs.AppendLine(string.Empty);
        }

        return errorMsgs.ToString();
    }
}