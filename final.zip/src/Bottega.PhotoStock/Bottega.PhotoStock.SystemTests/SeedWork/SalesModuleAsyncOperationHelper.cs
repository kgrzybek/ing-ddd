using Bottega.PhotoStock.BuildingBlocks.Application.Database;

namespace Bottega.PhotoStock.SystemTests.SeedWork;

public class SalesModuleAsyncOperationHelper
{
    private static readonly List<string> _waitQueries = new()
    {
        "SELECT COUNT(1) FROM sales.internal_commands AS internal_command WHERE internal_command.finish_processed_at IS NULL;",
        "SELECT COUNT(1) FROM sales.outbox_messages AS outbox_message WHERE outbox_message.finish_processed_at IS NULL;"
    };

    private static readonly List<string> _errorQueries = new()
    {
        @"SELECT internal_command.type, internal_command.error
                    FROM sales.internal_commands AS internal_command
                    WHERE internal_command.error IS NOT NULL;",

        @"SELECT outbox_message.type, outbox_message.error FROM sales.outbox_messages AS outbox_message
                    WHERE outbox_message.error IS NOT NULL;"
    };

    public static async Task WaitForProcessing(
        IDbConnectionFactory connectionFactory,
        int timeoutInSeconds = 60)
    {
        using var connection = connectionFactory.GetOpenConnection();
        await AsyncOperationsHelper.WaitForProcessing(connection, _waitQueries, _errorQueries, timeoutInSeconds);
    }
}