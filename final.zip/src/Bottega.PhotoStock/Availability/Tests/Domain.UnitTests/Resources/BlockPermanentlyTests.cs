﻿using Availability.Domain.Resources;
using Availability.Domain.Resources.Events;
using Availability.Domain.Resources.Rules;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.DomainTests;
using FluentAssertions;
using NUnit.Framework;

namespace Availability.Domain.UnitTests.Resources;

[TestFixture]
public class BlockPermanentlyTests
{
    [Test]
    public void GivenResourceNotBlocked_WhenBlockPermanently_ThenIsBlocked()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());

        // When
        var ownerId = Guid.NewGuid();
        resource.BlockPermanently(ownerId);
        
        // Then
        resource.Should().PublishDomainEvent<ResourcePermanentlyBlockedDomainEvent>();
    }
    
    [Test]
    public void GivenResourceBlockedTemporarily_WhenBlockPermanentlyByTheSameOwner_ThenIsBlocked()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());
        
        SystemClock.Set(new DateTime(2023, 1, 10, 11, 0 , 0));
        var ownerId = Guid.NewGuid();
        var time = TimeSpan.FromHours(1);
        resource.BlockTemporarily(ownerId, time);
        
        // When
        resource.BlockPermanently(ownerId);
        
        // Then
        resource.Should().PublishDomainEvent<ResourcePermanentlyBlockedDomainEvent>();
    }
    
    [Test]
    public void GivenResourceBlockedTemporarily_WhenBlockPermanentlyByTheDifferentOwner_ThenIsNotBlocked()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());
        
        SystemClock.Set(new DateTime(2023, 1, 10, 11, 0 , 0));
        var ownerId = Guid.NewGuid();
        var time = TimeSpan.FromHours(1);
        resource.BlockTemporarily(ownerId, time);
        
        // When
        var anotherOwnerId = Guid.NewGuid();
        Action blockPermanently = () => resource.BlockPermanently(anotherOwnerId);
        
        // Then
        blockPermanently.Should().BreakRule<ThereAreNoOtherBlockadesRule>();
    }
    
    [Test]
    public void GivenResourceIsWithdrawn_WhenBlockPermanently_ThenIsNotBlocked()
    {
        // Given
        var resource = Resource.Create(Guid.NewGuid());
        
        SystemClock.Set(new DateTime(2023, 1, 10, 11, 0 , 0));
        var ownerId = Guid.NewGuid();
        var time = TimeSpan.FromHours(1);
        resource.BlockTemporarily(ownerId, time);
        resource.Withdraw();
        
        // When
        Action blockPermanently = () => resource.BlockPermanently(ownerId);
        
        // Then
        blockPermanently.Should().BreakRule<WithdrawnResourceCannotBeBlockedRule>();
    }
}