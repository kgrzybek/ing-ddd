﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Availability.Application.Resources.CreateResource;

public class CreateResourceCommand : CommandBase
{
    public CreateResourceCommand(Guid resourceId)
    {
        ResourceId = resourceId;
    }

    public Guid ResourceId { get; }
}