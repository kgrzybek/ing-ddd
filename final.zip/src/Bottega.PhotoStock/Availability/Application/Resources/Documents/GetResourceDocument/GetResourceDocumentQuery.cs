﻿using Availability.Domain.Resources.Documents;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Availability.Application.Resources.Documents.GetResourceDocument;

public class GetResourceDocumentQuery : QueryBase<ResourceDocumentSnapshot>
{
    public GetResourceDocumentQuery(Guid resourceId)
    {
        ResourceId = resourceId;
    }

    public Guid ResourceId { get; }
}