using Availability.Domain.Resources.Documents;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Marten;

namespace Bottega.PhotoStock.Availability.Application.Resources.Documents.GetResourceDocument;

public class GetResourceDocumentQueryHandler : IQueryHandler<GetResourceDocumentQuery, ResourceDocumentSnapshot>
{
    private readonly IDocumentSession _documentSession;

    public GetResourceDocumentQueryHandler(IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<ResourceDocumentSnapshot> Handle(GetResourceDocumentQuery query, CancellationToken cancellationToken)
    {
        var resource = await _documentSession.Query<ResourceDocument>()
            .SingleAsync(x => x.Id == query.ResourceId, cancellationToken);

        return resource.ToSnapshot();
    }
}