using Availability.Domain.Resources.Documents;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Marten;
using MediatR;

namespace Bottega.PhotoStock.Availability.Application.Resources.Documents.CreateResourceDocument;

public class CreateResourceDocumentCommandHandler : ICommandHandler<CreateResourceDocumentCommand>
{
    private readonly IDocumentSession _documentSession;

    public CreateResourceDocumentCommandHandler(IDocumentSession documentSession)
    {
        _documentSession = documentSession;
    }

    public async Task<Unit> Handle(CreateResourceDocumentCommand command, CancellationToken cancellationToken)
    {
        var resource = ResourceDocument.Create(command.ResourceId);
        
        _documentSession.Store(resource);

        await _documentSession.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}