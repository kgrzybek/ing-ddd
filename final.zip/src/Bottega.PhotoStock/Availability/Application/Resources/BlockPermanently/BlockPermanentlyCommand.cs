﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Availability.Application.Resources.BlockPermanently;

public class BlockPermanentlyCommand : CommandBase
{
    public BlockPermanentlyCommand(Guid resourceId, Guid ownerId)
    {
        ResourceId = resourceId;
        OwnerId = ownerId;
    }

    public Guid ResourceId { get; }
    
    public Guid OwnerId { get; }
}