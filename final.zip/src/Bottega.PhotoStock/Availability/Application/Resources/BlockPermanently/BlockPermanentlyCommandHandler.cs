using Availability.Domain.Resources;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using MediatR;

namespace Bottega.PhotoStock.Availability.Application.Resources.BlockPermanently;

public class BlockPermanentlyCommandHandler : ICommandHandler<BlockPermanentlyCommand>
{
    private readonly IResourceRepository _resourceRepository;

    public BlockPermanentlyCommandHandler(IResourceRepository resourceRepository)
    {
        _resourceRepository = resourceRepository;
    }

    public async Task<Unit> Handle(BlockPermanentlyCommand command, CancellationToken cancellationToken)
    {
        var resource = await _resourceRepository.GetById(command.ResourceId);

        if (resource == null)
        {
            throw new ArgumentException("Invalid Resource Id");
        }
        
        resource.BlockPermanently(command.OwnerId);

        return Unit.Value;
    }
}