﻿using Availability.Domain.Resources;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Availability.Infrastructure.Domain.Resources;

public class ResourceEntityTypeConfiguration : IEntityTypeConfiguration<Resource>
{
    public void Configure(EntityTypeBuilder<Resource> builder)
    {
        builder.ToTable("resources");
        
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();

        builder.Property("_isWithdrawn").HasColumnName("is_withdrawn");
        builder.Property("_versionId").HasColumnName("version_id").IsConcurrencyToken();

        builder.OwnsOne<Blockade>("_blockade", property =>
        {
            property.Property(x => x.OwnerId).HasColumnName("blockade_owner_id");
            property.Property(x => x.DateTo).HasColumnName("blockade_date_to");
        });
    }
}