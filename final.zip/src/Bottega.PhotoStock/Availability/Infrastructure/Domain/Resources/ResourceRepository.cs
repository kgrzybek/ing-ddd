﻿using Availability.Domain.Resources;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration.DataAccess;

namespace Bottega.PhotoStock.Availability.Infrastructure.Domain.Resources;

public class ResourceRepository : IResourceRepository
{
    private readonly AvailabilityContext _context;

    public ResourceRepository(AvailabilityContext context)
    {
        _context = context;
    }

    public async Task Add(Resource resource)
    {
        await _context.Resources.AddAsync(resource);
    }

    public async ValueTask<Resource?> GetById(Guid resourceId)
    {
        return await _context.Resources.FindAsync(resourceId);
    }
}