using System.Reflection;
using Bottega.PhotoStock.Availability.Application;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration;

public static class Assemblies
{
    public static readonly Assembly Application = typeof(IAvailabilityModule).Assembly;
    public static readonly Assembly Infrastructure = typeof(AvailabilityModule).Assembly;
}