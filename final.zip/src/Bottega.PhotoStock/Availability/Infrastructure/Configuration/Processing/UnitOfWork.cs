using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Availability.Infrastructure.Configuration.Processing;

public class UnitOfWork : IUnitOfWork
{
    private readonly DbContext _context;

    public UnitOfWork(
        DbContext context)
    {
        _context = context;
    }
    
    public async Task<int> CommitAsync(CancellationToken cancellationToken)
    {
        IncreaseChangedAggregateVersions();
        
        var result = await _context.SaveChangesAsync(cancellationToken);

        return result;
    }
    
    private void IncreaseChangedAggregateVersions()
    {
        var aggregates = _context.ChangeTracker
            .Entries<AggregateRootBase>()
            .Where(x => x.Entity.DomainEvents.Any())
            .Select(x => x.Entity).ToList();

        foreach (var entity in aggregates)
        {
            entity.IncreaseVersion();
        }
    }
}