﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources;

public interface IResourceRepository : IRepository
{
    public Task Add(Resource resource);
    
    public ValueTask<Resource?> GetById(Guid resourceId);
}