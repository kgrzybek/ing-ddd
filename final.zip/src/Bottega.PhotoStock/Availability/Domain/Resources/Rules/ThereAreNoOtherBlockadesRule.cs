﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Availability.Domain.Resources.Rules;

public class ThereAreNoOtherBlockadesRule : IBusinessRule
{
    private readonly Blockade? _blockade;

    private readonly Guid _ownerId;

    public ThereAreNoOtherBlockadesRule(Blockade? blockade, Guid ownerId)
    {
        _ownerId = ownerId;
        _blockade = blockade;
    }

    public bool IsBroken() => _blockade != null &&
                              _blockade.HasBlockadeForDifferentOwner(_ownerId);

    public string Code => "ThereAreNoOtherBlockadesRule";
}