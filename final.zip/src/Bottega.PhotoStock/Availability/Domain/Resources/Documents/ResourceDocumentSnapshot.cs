﻿namespace Availability.Domain.Resources.Documents;

public record ResourceDocumentSnapshot(
    Guid Id,
    DateTime? BlockadeDateTo,
    Guid? BlockadeOwnerId,
    bool IsWithdrawn)
{
}