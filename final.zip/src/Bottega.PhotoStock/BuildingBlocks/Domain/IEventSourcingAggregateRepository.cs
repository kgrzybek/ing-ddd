﻿namespace Bottega.PhotoStock.BuildingBlocks.Domain
{
    public interface IEventSourcingAggregateRepository
    {
        Task Store(AggregateRootBaseEventSourcing aggregate);

        T Load<T>(Guid id, int? version = null) where T : AggregateRootBaseEventSourcing;
    }
}