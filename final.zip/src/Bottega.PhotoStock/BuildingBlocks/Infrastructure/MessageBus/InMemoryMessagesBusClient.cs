using Bottega.PhotoStock.BuildingBlocks.Application.Integration;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.MessageBus;

public class InMemoryMessagesBusClient : IMessagesBusClient
{
    public Task Publish<T>(T @event, CancellationToken cancellationToken)
        where T : IntegrationEvent
    {
        return InMemoryMessagesBus.Instance.Publish(@event, cancellationToken);
    }

    public void Subscribe<T>(IIntegrationEventHandler<T> handler)
        where T : IntegrationEvent
    {
        InMemoryMessagesBus.Instance.Subscribe(handler);
    }
}