using JsonNet.ContractResolvers;
using Newtonsoft.Json;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure;

public static class Deserializer
{
    private static JsonSerializerSettings serializer = new()
    {
        ContractResolver = new PrivateSetterContractResolver(),
    };
    
    public static object? Deserialize(string @object, Type type)
    {
        return JsonConvert.DeserializeObject(@object, type, serializer);
    }
}

public static class Serializer
{
    private static JsonSerializerSettings serializer = new();
    
    public static string Serialize(object @object)
    {
        return JsonConvert.SerializeObject(@object, serializer);
    }
}