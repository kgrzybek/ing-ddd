using Autofac;
using Autofac.Core;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using MediatR;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;

public class DomainEventsDispatcher : IDomainEventsDispatcher
{
    private readonly IDomainEventsAccessor _domainEventsAccessor;
    private readonly ILifetimeScope _scope;
    private readonly IMediator _mediator;
    private readonly IDomainEventNotificationsDispatcher _domainNotificationsDispatcher;

    public DomainEventsDispatcher(
        IDomainEventsAccessor domainEventsAccessor,
        ILifetimeScope scope,
        IMediator mediator,
        IDomainEventNotificationsDispatcher domainNotificationsDispatcher)
    {
        _domainEventsAccessor = domainEventsAccessor;
        _scope = scope;
        _mediator = mediator;
        _domainNotificationsDispatcher = domainNotificationsDispatcher;
    }
    
    public async Task DispatchEventsAsync(CancellationToken cancellationToken)
    {
        var domainEvents = _domainEventsAccessor.GetAllDomainEvents();
        _domainEventsAccessor.ClearAllDomainEvents();

        await DispatchDomainEvents(domainEvents, cancellationToken);
        await DispatchDomainNotifications(domainEvents, cancellationToken);
    }

    private async Task DispatchDomainEvents(IReadOnlyCollection<IDomainEvent> domainEvents, CancellationToken cancellationToken)
    {
        foreach (var domainEvent in domainEvents)
        {
            await _mediator.Publish(domainEvent, cancellationToken);
        }
    }

    private async Task DispatchDomainNotifications(IEnumerable<IDomainEvent> domainEvents, CancellationToken cancellationToken)
    {
        foreach (var domainEvent in domainEvents)
        {
            var domainNotification = GetOptionalDomainNotification(domainEvent);

            if (domainNotification != null)
            {
                await _domainNotificationsDispatcher.Dispatch(domainNotification, cancellationToken);
            }
        }
    }

    private IDomainEventNotification? GetOptionalDomainNotification(IDomainEvent domainEvent)
    {
        var domainEvenNotificationType = typeof(IDomainEventNotification<>);
        var domainNotificationWithGenericType = domainEvenNotificationType.MakeGenericType(domainEvent.GetType());

        var domainNotification = _scope.ResolveOptional(domainNotificationWithGenericType, new List<Parameter>
        {
            new NamedParameter("domainEvent", domainEvent),
            new NamedParameter("id", domainEvent.Id)
        });

        return domainNotification as IDomainEventNotification;
    }
}