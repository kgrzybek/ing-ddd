using System.Data;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;

public class DomainEventNotificationsDispatcher : IDomainEventNotificationsDispatcher
{
    private readonly IOutbox _outbox;
    private readonly IDomainNotificationsMapper _domainNotificationsMapper;

    public DomainEventNotificationsDispatcher(
        IOutbox outbox,
        IDomainNotificationsMapper domainNotificationsMapper)
    {
        _outbox = outbox;
        _domainNotificationsMapper = domainNotificationsMapper;
    }

    public async Task Dispatch(
        IEnumerable<IDomainEventNotification> domainEventNotifications,
        CancellationToken cancellationToken)
    {
        var messages = new List<OutboxMessage>();

        foreach (var domainNotification in domainEventNotifications)
        {
            messages.Add(BuildOutboxMessage(domainNotification));
        }

        await _outbox.Add(messages, cancellationToken);
    }
    
    public async Task Dispatch(
        IDbConnection connection,
        IEnumerable<IDomainEventNotification> domainEventNotifications,
        CancellationToken cancellationToken)
    {
        var messages = new List<OutboxMessage>();
        
        foreach(var domainEventNotification in domainEventNotifications)
        {
           var message = BuildOutboxMessage(domainEventNotification);
           messages.Add(message);
        }

        await _outbox.Add(connection, messages, cancellationToken);
    }

    public async Task Dispatch(IDomainEventNotification domainEventNotification, CancellationToken cancellationToken)
    {
        var outboxMessage = BuildOutboxMessage(domainEventNotification);
        await _outbox.Add(outboxMessage, cancellationToken);
    }
    
    private OutboxMessage BuildOutboxMessage(IDomainEventNotification domainNotification)
    {
        var notificationName = _domainNotificationsMapper.GetName(domainNotification.GetType());

        if (notificationName == null)
        {
            throw new InvalidOperationException(
                $"Type {domainNotification.GetType().Name} does not have a mapped name.");
        }
        var data = Serializer.Serialize(domainNotification);
        var outboxMessage = OutboxMessage.Create(
            domainNotification.Id,
            domainNotification.OccurredOn,
            notificationName,
            data);

        return outboxMessage;
    }
}