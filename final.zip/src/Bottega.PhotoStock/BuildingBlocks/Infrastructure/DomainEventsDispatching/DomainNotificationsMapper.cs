namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;

public class DomainNotificationsMapper : IDomainNotificationsMapper
{
    private readonly BiDictionary<string, Type> _domainNotificationsMap;

    public DomainNotificationsMapper(BiDictionary<string, Type> domainNotificationsMap)
    {
        _domainNotificationsMap = domainNotificationsMap;
    }

    public string GetName(Type type)
    {
        return _domainNotificationsMap.GetBySecond(type);
    }

    public Type GetType(string name)
    {
        return _domainNotificationsMap.GetByFirst(name);
    }
}