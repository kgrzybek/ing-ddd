using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;

public interface IDomainEventsAccessor
{
    IReadOnlyCollection<IDomainEvent> GetAllDomainEvents();

    void ClearAllDomainEvents();
}