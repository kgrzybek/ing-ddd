using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Scheduling;

public class CommandScheduler : ICommandScheduler
{
    private readonly IInternalCommandsMapper _internalCommandsMapper;
    
    private readonly IDbContextWithInternalCommands _dbContext;

    public CommandScheduler(
        IInternalCommandsMapper internalCommandsMapper,
        IDbContextWithInternalCommands dbContext)
    {
        _internalCommandsMapper = internalCommandsMapper;
        _dbContext = dbContext;
    }

    public Task EnqueueAsync(IEnqueueableCommand command)
    {
        var commandType = _internalCommandsMapper.TryGetName(command.GetType());

        if (commandType is null)
        {
            throw new InvalidOperationException($"Cannot find name of internal command {command.GetType()}");
        }
        
        var data = Serializer.Serialize(command);
        
        var internalCommand = InternalCommand.Create(
            command.Id,
            commandType,
            DateTime.Now,
            data);

        _dbContext.InternalCommands.Add(internalCommand);
        
        return Task.CompletedTask;
    }
}