using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;

public interface IDbContextWithInternalCommands
{
    DbSet<InternalCommand> InternalCommands { get; set; }
}