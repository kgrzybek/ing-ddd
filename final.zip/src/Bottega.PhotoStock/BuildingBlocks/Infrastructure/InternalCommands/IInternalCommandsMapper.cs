namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;

public interface IInternalCommandsMapper
{
    string GetName(Type type);

    Type GetType(string name);
    
    string? TryGetName(Type type);

    Type? TryGetType(string name);
}