namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;

public class InternalCommand
{
    public Guid Id { get; set; }

    public string Type { get; }
    
    public DateTime EnqueueDate { get; }

    public string Data { get; }
    
    public string? Error { get; private set; }
    
    public DateTime? StartProcessedAt { get; private set; }
    
    public DateTime? FinishProcessedAt { get; private set; }

#pragma warning disable CS8618
    private InternalCommand()
#pragma warning restore CS8618
    {
        // For EF only.
    }
    
    private InternalCommand(
        Guid id, 
        string type, 
        DateTime enqueueDate, 
        string data)
    {
        Id = id;
        Type = type;
        EnqueueDate = enqueueDate;
        Data = data;
    }

    public static InternalCommand Create(
        Guid id, 
        string type, 
        DateTime enqueueDate, 
        string data)
    {
        return new InternalCommand(id, type, enqueueDate, data);
    }

    public void SetAsProcessing(DateTime processingStartDate)
    {
        StartProcessedAt = processingStartDate;
    }
    
    public void SetAsProcessed(DateTime processingEndDate)
    {
        FinishProcessedAt = processingEndDate;
    }
    
    public void SetAsProcessedWithError(DateTime processingEndDate, string error)
    {
        FinishProcessedAt = processingEndDate;
        Error = error;
    }
}