using System.Data;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;

public class DbOutbox : IOutbox
{
    private readonly IDbContextWithOutboxMessages _context;

    public DbOutbox(IDbContextWithOutboxMessages context)
    {
        _context = context;
    }

    public Task Add(OutboxMessage message, CancellationToken cancellationToken)
    {
        _context.OutboxMessages.Add(message);
        return Task.CompletedTask;
    }

    public async Task Add(IEnumerable<OutboxMessage> messages, CancellationToken cancellationToken)
    {
        await _context.OutboxMessages.AddRangeAsync(messages, cancellationToken);
    }

    public Task Add(IDbConnection connection, IEnumerable<OutboxMessage> messages, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public Task Save()
    {
        // Save is done automatically using EF Core Change Tracking mechanism during SaveChanges.
        return Task.CompletedTask; 
    }
}