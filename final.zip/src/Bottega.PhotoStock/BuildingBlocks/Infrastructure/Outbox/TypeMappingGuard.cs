using System.Reflection;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;

public static class TypeMappingGuard
{
    public static void CheckMappings(Assembly assembly, Type parentType, BiDictionary<string, Type> mapping)
    {
        var types = assembly
            .GetTypes()
            .Where(x => x.IsAssignableTo(parentType))
            .ToList();

        var notMappedTypes = new List<Type>();
        foreach (var type in types)
        {
            mapping.TryGetBySecond(type, out var name);

            if (string.IsNullOrWhiteSpace(name))
            {
                notMappedTypes.Add(type);
            }
        }

        if (notMappedTypes.Any())
        {
            throw new ApplicationException(
                $"Types of {parentType.Name} are not mapped: {notMappedTypes.Select(x => x.FullName).Aggregate((x, y) => x + "," + y)}");
        }
    }
}