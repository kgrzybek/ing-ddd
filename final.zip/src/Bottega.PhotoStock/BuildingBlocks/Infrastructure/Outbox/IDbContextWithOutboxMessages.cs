using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;

public interface IDbContextWithOutboxMessages
{
    DbSet<OutboxMessage> OutboxMessages { get; set; }
}