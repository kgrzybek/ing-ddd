using System.Data;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;

public interface IOutbox
{
    Task Add(OutboxMessage message, CancellationToken cancellationToken);
    
    Task Add(IEnumerable<OutboxMessage> messages, CancellationToken cancellationToken);
    
    Task Add(IDbConnection connection, IEnumerable<OutboxMessage> messages, CancellationToken cancellationToken);

    Task Save();
}