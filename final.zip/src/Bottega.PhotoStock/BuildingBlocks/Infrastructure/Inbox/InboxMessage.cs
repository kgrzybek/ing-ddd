namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Inbox;

public class InboxMessage
{
    public Guid Id { get; }

    public string Type { get; }

    public string Data { get; }

    public DateTime OccurredAt { get; }

    public DateTime? StartProcessedAt { get; private set; }
    
    public DateTime? FinishProcessedAt { get; private set; }
    
    public string? Error { get; private set; }

#pragma warning disable CS8618
    private InboxMessage()
#pragma warning restore CS8618
    {
        // For EF only.
    }

    private InboxMessage(Guid id, DateTime occurredAt, string type, string data)
    {
        Id = id;
        OccurredAt = occurredAt;
        Type = type;
        Data = data;
    }
    
    public static InboxMessage Create(Guid id, DateTime occurredOn, string type, string data)
    {
        return new InboxMessage(id, occurredOn, type, data);
    }
    
    public void SetAsProcessing(DateTime processingStartDate)
    {
        StartProcessedAt = processingStartDate;
    }
    
    public void SetAsProcessed(DateTime processingEndDate)
    {
        FinishProcessedAt = processingEndDate;
    }
    
    public void SetAsProcessedWithError(DateTime processingEndDate, string error)
    {
        FinishProcessedAt = processingEndDate;
        Error = error;
    }
}