using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.BuildingBlocks.Infrastructure.Inbox;

public interface IDbContextWithInboxMessages
{
    DbSet<InboxMessage> InboxMessages { get; set; }
}