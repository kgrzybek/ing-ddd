namespace Bottega.PhotoStock.BuildingBlocks.Application.Commands;

public interface ICommandScheduler
{
    Task EnqueueAsync(IEnqueueableCommand command);
}