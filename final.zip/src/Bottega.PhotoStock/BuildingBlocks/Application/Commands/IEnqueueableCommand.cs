namespace Bottega.PhotoStock.BuildingBlocks.Application.Commands;

public interface IEnqueueableCommand
{
    public Guid Id { get; }
}