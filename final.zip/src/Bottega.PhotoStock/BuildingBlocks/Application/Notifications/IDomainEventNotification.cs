using MediatR;

namespace Bottega.PhotoStock.BuildingBlocks.Application.Notifications;

public interface IDomainEventNotification<out TEventType> : IDomainEventNotification
{
    TEventType DomainEvent { get; }
}

public interface IDomainEventNotification : INotification
{
    Guid Id { get; }
        
    DateTime OccurredOn { get; }
}