using System.Data;

namespace Bottega.PhotoStock.BuildingBlocks.Application.Notifications;

public interface IDomainEventNotificationsDispatcher
{
    Task Dispatch(
        IDbConnection connection,
        IEnumerable<IDomainEventNotification> domainEventNotifications,
        CancellationToken cancellationToken);
    
    Task Dispatch(
        IEnumerable<IDomainEventNotification> domainEventNotifications,
        CancellationToken cancellationToken);
    
    Task Dispatch(
        IDomainEventNotification domainEventNotification,
        CancellationToken cancellationToken);
}