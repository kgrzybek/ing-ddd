using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.BuildingBlocks.Application.Notifications;

public class DomainNotificationBase<T> : IDomainEventNotification<T>
    where T : IDomainEvent
{
    public T DomainEvent { get; }

    public Guid Id { get; private set; }
        
    public DateTime OccurredOn { get; private set; }

    public DomainNotificationBase(T domainEvent, Guid id)
    {
        Id = id;
        DomainEvent = domainEvent;
        OccurredOn = domainEvent.OccurredOn;
    }
}
    
public class DomainNotificationBase : IDomainEventNotification
{
    public Guid Id { get; private set; }
        
    public DateTime OccurredOn { get; private set; }

    public DomainNotificationBase(Guid id, DateTime occurredOn)
    {
        Id = id;
        OccurredOn = occurredOn;
    }
}