namespace Bottega.PhotoStock.BuildingBlocks.Application.Integration;

public interface IMessagesBusClient
{
    Task Publish<T>(T @event, CancellationToken cancellationToken)
        where T : IntegrationEvent;

    void Subscribe<T>(IIntegrationEventHandler<T> handler)
        where T : IntegrationEvent;
}