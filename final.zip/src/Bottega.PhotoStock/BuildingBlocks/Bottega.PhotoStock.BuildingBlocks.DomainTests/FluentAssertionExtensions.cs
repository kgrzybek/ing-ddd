using Bottega.PhotoStock.BuildingBlocks.Domain;
using FluentAssertions;

namespace Bottega.PhotoStock.BuildingBlocks.DomainTests;

public static class FluentAssertionExtensions
{
    public static T PublishDomainEvent<T>(this FluentAssertions.Primitives.ObjectAssertions assertions)
        where T : IDomainEvent
    {
        var entity = (Entity)assertions.Subject;

        var domainEvent = entity.DomainEvents.OfType<T>().SingleOrDefault();

        if (domainEvent == null)
        {
            throw new Exception($"{typeof(T).Name} event not published");
        }

        return domainEvent;
    }
    
    public static void PublishDomainEvents<T>(this FluentAssertions.Primitives.ObjectAssertions assertions, int count)
        where T : IDomainEvent
    {
        var entity = (Entity)assertions.Subject;

        var domainEvents = entity.DomainEvents.OfType<T>().ToList();

        if (domainEvents == null)
        {
            throw new Exception($"{typeof(T).Name} event not published");
        }

        if (domainEvents.Count != count)
        {
            throw new Exception($"Expected to publish {count} event of type {typeof(T).Name}, published {domainEvents.Count}.");
        }
    }

    public static void BreakRule<TRule>(this FluentAssertions.Specialized.ActionAssertions assertions)
        where TRule : class, IBusinessRule
    {
        assertions.Subject
            .Should().Throw<BusinessRuleValidationException>(typeof(TRule).Name)
            .And
            .BrokenRule.Should().BeOfType<TRule>();
    }
}