﻿namespace Bottega.PhotoStock.Sales.Application.Orders;

public interface IPaymentService
{
    Task Pay(Guid customerId, decimal amount);
}