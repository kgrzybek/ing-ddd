﻿using System.Text.Json.Serialization;
using Bottega.PhotoStock.BuildingBlocks.Application.Integration;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.Sales.Domain.Orders.Events;
using Bottega.PhotoStock.Sales.IntegrationEvents;
using MediatR;

namespace Bottega.PhotoStock.Sales.Application.Orders.OrderPaid;

public class OrderPaidNotification : DomainNotificationBase<OrderPaidDomainEvent>
{
    [JsonConstructor]
    public OrderPaidNotification(OrderPaidDomainEvent domainEvent, Guid id) : base(domainEvent, id)
    {
    }
}

public class OrderPaidNotificationHandler : INotificationHandler<OrderPaidNotification>
{
    private readonly IMessagesBusClient _messagesBusClient;

    public OrderPaidNotificationHandler(IMessagesBusClient messagesBusClient)
    {
        _messagesBusClient = messagesBusClient;
    }

    public async Task Handle(OrderPaidNotification notification, CancellationToken cancellationToken)
    {
        var orderPaidIntegrationEvent = new OrderPaidIntegrationEvent(
            Guid.NewGuid(),
            DateTime.Now,
            notification.DomainEvent.OrderId,
            notification.DomainEvent.CustomerId,
            notification.DomainEvent.Amount,
            notification.DomainEvent.CurrencyCode);

        await _messagesBusClient.Publish(orderPaidIntegrationEvent, cancellationToken);
    }
}