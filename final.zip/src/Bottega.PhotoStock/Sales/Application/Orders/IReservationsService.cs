﻿namespace Bottega.PhotoStock.Sales.Application.Orders;

public interface IReservationsService
{
    Task Reserve(List<Guid> productIds, Guid customerId);
}