﻿using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Sales.Application.Orders.GetOrder;

public class GetOrderQuery : QueryBase<OrderDto>
{
    public GetOrderQuery(Guid orderId)
    {
        OrderId = orderId;
    }

    public Guid OrderId { get; }
}