﻿namespace Bottega.PhotoStock.Sales.Application.Orders.GetOrder;

public class OrderDto
{
    public Guid Id { get; set; }
    
    public Guid CustomerId { get; set; }
    
    public decimal BeforeDiscountValue { get; set; }
    
    public decimal DiscountValue { get; set; }
    
    public decimal AfterDiscountValue { get; set; }
    
    public string StatusCode { get; set; }
}