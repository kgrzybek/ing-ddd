﻿using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Dapper;

namespace Bottega.PhotoStock.Sales.Application.Orders.GetOrder;

public class GetOrderQueryHandler : IQueryHandler<GetOrderQuery, OrderDto>
{
    private readonly IDbConnectionFactory _connectionFactory;

    public GetOrderQueryHandler(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<OrderDto> Handle(GetOrderQuery query, CancellationToken cancellationToken)
    {
        var connection = _connectionFactory.GetOpenConnection();

        string sql = @$"SELECT 
                        orders.id {nameof(OrderDto.Id)},
                        orders.customer_id {nameof(OrderDto.CustomerId)},
                        orders.before_discount_value {nameof(OrderDto.BeforeDiscountValue)},
                        orders.discount_value {nameof(OrderDto.DiscountValue)},
                        orders.after_discount_value {nameof(OrderDto.AfterDiscountValue)},
                        orders.status_code {nameof(OrderDto.StatusCode)}
                        FROM sales.orders orders
                        WHERE orders.id = :orderId";
        return await connection.QuerySingleAsync<OrderDto>(sql, new
        {
            query.OrderId
        });
    }
}