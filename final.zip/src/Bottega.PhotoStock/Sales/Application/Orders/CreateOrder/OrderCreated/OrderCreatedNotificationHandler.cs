using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Sales.Application.Orders.PayForOrder;
using MediatR;

namespace Bottega.PhotoStock.Sales.Application.Orders.CreateOrder.OrderCreated;

public class OrderCreatedNotificationHandler : INotificationHandler<OrderCreatedNotification>
{
    private readonly ICommandScheduler _commandScheduler;

    public OrderCreatedNotificationHandler(ICommandScheduler commandScheduler)
    {
        _commandScheduler = commandScheduler;
    }

    public async Task Handle(OrderCreatedNotification notification, CancellationToken cancellationToken)
    {
        await _commandScheduler.EnqueueAsync(new PayForOrderCommand(
            notification.DomainEvent.CustomerId,
            notification.DomainEvent.AfterDiscountValue,
            notification.DomainEvent.OrderId));
    }
}