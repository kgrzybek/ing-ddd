﻿using System.Text.Json.Serialization;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.Sales.Domain.Orders.Events;

namespace Bottega.PhotoStock.Sales.Application.Orders.CreateOrder.OrderCreated;

public class OrderCreatedNotification : DomainNotificationBase<OrderCreatedDomainEvent>
{
    [JsonConstructor]
    public OrderCreatedNotification(OrderCreatedDomainEvent domainEvent, Guid id) : base(domainEvent, id)
    {
    }
}