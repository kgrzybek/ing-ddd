﻿namespace Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;

public record OrderLineDto(Guid ProductId, int Quantity, decimal UnitPrice);