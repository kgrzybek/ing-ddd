﻿namespace Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;

public class DiscountConfigurationDto
{
    public string ConfigurationCode { get; set; }
    
    public int SameProductsNumber { get; set; }
    
    public decimal SameProductsPercentage { get; set; }
    
    public decimal PercentageOfTotalValue { get; set; }
}