﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;

public class CreateOrderCommand : CommandBase<Guid>
{
    public List<OrderLineDto> OrderLines { get; }

    public CreateOrderCommand(Guid customerId, List<OrderLineDto> orderLines, string currencyCode)
    {
        CustomerId = customerId;
        OrderLines = orderLines;
        CurrencyCode = currencyCode;
    }

    public Guid CustomerId { get; }
    
    public string CurrencyCode { get; }
}