﻿using System.Data;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Dapper;

namespace Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;

public class CreateOrderCommandHandler : ICommandHandler<CreateOrderCommand, Guid>
{
    private readonly IOrderRepository _orderRepository;

    private readonly IDbConnectionFactory _dbConnectionFactory;

    private readonly IReservationsService _reservationsService;

    public CreateOrderCommandHandler(
        IOrderRepository orderRepository,
        IDbConnectionFactory dbConnectionFactory, 
        IReservationsService reservationsService)
    {
        _orderRepository = orderRepository;
        _dbConnectionFactory = dbConnectionFactory;
        _reservationsService = reservationsService;
    }

    public async Task<Guid> Handle(CreateOrderCommand command, CancellationToken cancellationToken)
    {
        var productIds = command.OrderLines.Select(x => x.ProductId).ToList();
        await _reservationsService.Reserve(productIds, command.CustomerId);
        
        var connection = _dbConnectionFactory.GetOpenConnection();

        var configuration = await GetDiscountConfiguration(connection);
        
        var discountPolicy = DiscountPolicyFactory.Create(
            DiscountPolicyConfiguration.OfCode(configuration.ConfigurationCode),
            configuration.SameProductsNumber,
            Percentage.FromFraction(configuration.SameProductsPercentage),
            Percentage.Of(configuration.PercentageOfTotalValue));
        
        var orderLines = command.OrderLines
            .Select(x => new OrderLine(x.ProductId, x.Quantity,
            Money.Of(x.UnitPrice, command.CurrencyCode)))
            .ToList();
        
        var order = Order.Create(command.CustomerId, discountPolicy, orderLines);

        await _orderRepository.Add(order);

        return order.Id;
    }
    
    private static async Task<DiscountConfigurationDto> GetDiscountConfiguration(IDbConnection connection)
    {
        const string sql = $@"SELECT 
                discount_configuration.configuration_code {nameof(DiscountConfigurationDto.ConfigurationCode)},
                discount_configuration.same_products_number {nameof(DiscountConfigurationDto.SameProductsNumber)},
                discount_configuration.same_products_percentage {nameof(DiscountConfigurationDto.SameProductsPercentage)},
                discount_configuration.percentage_total_orders {nameof(DiscountConfigurationDto.PercentageOfTotalValue)}
            FROM sales.discount_configurations discount_configuration limit 1";

        return await connection.QuerySingleAsync<DiscountConfigurationDto>(sql);
    }
}