﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using MediatR;

namespace Bottega.PhotoStock.Sales.Application.Orders.AddDiscountConfiguration;

public class AddDiscountConfigurationCommandHandler : ICommandHandler<AddDiscountConfigurationCommand>
{
    private readonly IDiscountConfigurationRepository _discountConfigurationRepository;

    public AddDiscountConfigurationCommandHandler(IDiscountConfigurationRepository discountConfigurationRepository)
    {
        _discountConfigurationRepository = discountConfigurationRepository;
    }

    public async Task<Unit> Handle(AddDiscountConfigurationCommand command, CancellationToken cancellationToken)
    {
        var configuration = DiscountConfiguration.Create(
            DiscountPolicyConfiguration.OfCode(command.ConfigurationCode),
            command.SameProductsNumber,
            Percentage.FromFraction(command.SameProductsPercentage),
            Percentage.FromFraction(command.PercentageOfTotalValue));

        await _discountConfigurationRepository.Add(configuration);

        return Unit.Value;
    }
}