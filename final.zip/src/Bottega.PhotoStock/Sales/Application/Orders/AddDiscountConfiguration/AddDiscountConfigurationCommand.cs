﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Sales.Application.Orders.AddDiscountConfiguration;

public class AddDiscountConfigurationCommand : CommandBase
{
    public AddDiscountConfigurationCommand(
        string configurationCode,
        int sameProductsNumber,
        decimal sameProductsPercentage,
        decimal percentageOfTotalValue)
    {
        ConfigurationCode = configurationCode;
        SameProductsNumber = sameProductsNumber;
        SameProductsPercentage = sameProductsPercentage;
        PercentageOfTotalValue = percentageOfTotalValue;
    }

    public string ConfigurationCode { get; }
    
    public int SameProductsNumber { get; }
    
    public decimal SameProductsPercentage { get; }
    
    public decimal PercentageOfTotalValue { get; }
}