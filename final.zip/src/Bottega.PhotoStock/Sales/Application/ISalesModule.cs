﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;

namespace Bottega.PhotoStock.Sales.Application;

public interface ISalesModule
{
    Task ExecuteCommand(ICommand command, CancellationToken cancellationToken = default);
    
    Task<TResult> ExecuteQuery<TResult>(IQuery<TResult> query, CancellationToken cancellationToken = default);
}