﻿using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Database;
using Bottega.PhotoStock.BuildingBlocks.IntegrationTests;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration;
using Bottega.PhotoStock.Sales.IntegrationTests.Orders;
using Dapper;

namespace Bottega.PhotoStock.Sales.IntegrationTests.SeedWork;

public class TestBase
{
    private readonly string _connectionString;
    
    protected IDbConnectionFactory DbConnectionFactory { get; }
    
    protected SalesModule SalesModule { get; }
    
    protected ReservationsServiceFake ReservationsService { get; }
    
    protected PaymentsServiceFake PaymentsService { get; }
    
    protected TestBase()
    {
        _connectionString = "Host=localhost:9950;Username=SYSTEM;Password=p@ssword111;Database=postgres-db;";
        SalesModule = new SalesModule();
        DbConnectionFactory = new DbConnectionFactory(_connectionString);
        ReservationsService = new ReservationsServiceFake();
        PaymentsService = new PaymentsServiceFake();
    }
    
    [SetUp]
    public async Task BeforeEachTest()
    {
        SystemClock.Reset();

        await ClearDatabase();
        
        await SalesStartup.Initialize(
            _connectionString,
            ReservationsService,
            PaymentsService,
            10);
    }
    
    [TearDown]
    public async Task AfterEachTest()
    {
        await SalesStartup.Stop();
    }

    private async Task ClearDatabase()
    {
        using var connection = DbConnectionFactory.GetOpenConnection();

        const string sql = "DELETE FROM sales.discount_configurations; " +
                           "DELETE FROM sales.outbox_messages; " +
                           "DELETE FROM sales.internal_commands; " +
                           "DELETE FROM sales.orders; ";

        await connection.ExecuteScalarAsync(sql);
    }
}