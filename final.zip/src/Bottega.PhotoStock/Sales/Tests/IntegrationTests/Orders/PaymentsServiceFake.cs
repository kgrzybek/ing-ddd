﻿using Bottega.PhotoStock.Sales.Application.Orders;

namespace Bottega.PhotoStock.Sales.IntegrationTests.Orders;

public class PaymentsServiceFake : IPaymentService
{
    public async Task Pay(Guid customerId, decimal amount)
    {
    }
}