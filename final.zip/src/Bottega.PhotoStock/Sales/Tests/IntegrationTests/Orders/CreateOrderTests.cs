﻿using Bottega.PhotoStock.Sales.Application.Orders.AddDiscountConfiguration;
using Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;
using Bottega.PhotoStock.Sales.Application.Orders.GetOrder;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Bottega.PhotoStock.Sales.IntegrationTests.SeedWork;
using FluentAssertions;

namespace Bottega.PhotoStock.Sales.IntegrationTests.Orders;

[TestFixture]
public class CreateOrderTests : TestBase
{
    [Test]
    public async Task WhenCreateOrder_ThenIsCreated()
    {
        // Given
        await SalesModule.ExecuteCommand(new AddDiscountConfigurationCommand(
            DiscountPolicyConfiguration.NoDiscount.Code,
            0,
            0,
            0));
        
        // When
        var customerId = Guid.NewGuid();
        var orderLines = new List<OrderLineDto>();
        orderLines.Add(new OrderLineDto(Guid.NewGuid(), 2, 50));
        var orderId = await SalesModule.ExecuteCommand(new CreateOrderCommand(
            customerId,
            orderLines,
            "PLN"));
        
        // Then
        var order = await SalesModule.ExecuteQuery(new GetOrderQuery(orderId));
        order.AfterDiscountValue.Should().Be(100);
    }
}