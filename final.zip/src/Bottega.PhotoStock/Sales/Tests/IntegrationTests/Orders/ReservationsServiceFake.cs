﻿using Bottega.PhotoStock.Sales.Application.Orders;

namespace Bottega.PhotoStock.Sales.IntegrationTests.Orders;

public class ReservationsServiceFake : IReservationsService
{
    public async Task Reserve(List<Guid> productIds, Guid customerId)
    {
        
    }
}