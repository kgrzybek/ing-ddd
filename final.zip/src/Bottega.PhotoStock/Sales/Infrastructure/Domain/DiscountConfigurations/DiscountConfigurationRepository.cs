﻿using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.DataAccess;

namespace Bottega.PhotoStock.Sales.Infrastructure.Domain.DiscountConfigurations;

public class DiscountConfigurationRepository : IDiscountConfigurationRepository
{
    private readonly SalesContext _salesContext;

    public DiscountConfigurationRepository(SalesContext salesContext)
    {
        _salesContext = salesContext;
    }

    public async Task Add(DiscountConfiguration discountConfiguration)
    {
        await _salesContext.DiscountConfigurations.AddAsync(discountConfiguration);
    }
}