﻿using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Sales.Infrastructure.Domain.DiscountConfigurations;

public class DiscountConfigurationEntityTypeConfiguration : IEntityTypeConfiguration<DiscountConfiguration>
{
    public void Configure(EntityTypeBuilder<DiscountConfiguration> builder)
    {
        builder.ToTable("discount_configurations");
        
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();

        builder.Property("_sameProductsNumber").HasColumnName("same_products_number");
        
        builder.OwnsOne<DiscountPolicyConfiguration>("_configuration", property =>
        {
            property.Property(x => x.Code).HasColumnName("configuration_code");
        });
        
        builder.OwnsOne<Percentage>("_percentageOfTotalValue", property =>
        {
            property.Property(x => x.Fraction).HasColumnName("percentage_total_orders");
        });
        
        builder.OwnsOne<Percentage>("_sameProductsPercentage", property =>
        {
            property.Property(x => x.Fraction).HasColumnName("same_products_percentage");
        });
    }
}