﻿using Bottega.PhotoStock.Sales.Domain.Orders;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bottega.PhotoStock.Sales.Infrastructure.Domain.Orders;

public class OrderEntityTypeConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.ToTable("orders");
        
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();

        builder.Property("_customerId").HasColumnName("customer_id");
        
        builder.OwnsOne<Money>("_beforeDiscountValue", property =>
        {
            property.Property(x => x.Amount).HasColumnName("before_discount_value");
            property.Property(x => x.CurrencyCode).HasColumnName("before_discount_currency");
        });

        builder.OwnsOne<Money>("_discount", property =>
        {
            property.Property(x => x.Amount).HasColumnName("discount_value");
            property.Property(x => x.CurrencyCode).HasColumnName("discount_currency");
        });
        
        builder.OwnsOne<Money>("_afterDiscountValue", property =>
        {
            property.Property(x => x.Amount).HasColumnName("after_discount_value");
            property.Property(x => x.CurrencyCode).HasColumnName("after_discount_currency");
        });
        
        builder.OwnsOne<OrderStatus>("_orderStatus", property =>
        {
            property.Property(x => x.Code).HasColumnName("status_code");
        });
    }
}