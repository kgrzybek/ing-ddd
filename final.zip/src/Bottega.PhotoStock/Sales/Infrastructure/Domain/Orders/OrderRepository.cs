﻿using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.DataAccess;

namespace Bottega.PhotoStock.Sales.Infrastructure.Domain.Orders;

public class OrderRepository : IOrderRepository
{
    private readonly SalesContext _salesContext;

    public OrderRepository(SalesContext salesContext)
    {
        _salesContext = salesContext;
    }

    public async Task Add(Order order)
    {
        await _salesContext.Orders.AddAsync(order);
    }

    public async ValueTask<Order?> GetById(Guid orderId)
    {
        return await _salesContext.Orders.FindAsync(orderId);
    }
}