using System.Collections.Specialized;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Quartz.Jobs;
using Quartz;
using Quartz.Impl;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Quartz;

internal static class QuartzStartup
{
    private static IScheduler? _scheduler;

    internal static async Task Initialize(
        int processingIntervalMilliseconds)
    {
        await ConfigureScheduler();
        await ConfigureJobs(processingIntervalMilliseconds);
    }

    internal static async Task StopQuartz()
    {
        if (_scheduler is null)
        {
            return;
        }

        await _scheduler.Shutdown();
    }

    private static async Task ConfigureScheduler()
    {
        var schedulerConfiguration = new NameValueCollection
        {
            {"quartz.scheduler.instanceName", "Sales"}
        };

        var schedulerFactory = new StdSchedulerFactory(schedulerConfiguration);

        _scheduler = await schedulerFactory.GetScheduler();
        await _scheduler.Start();
    }

    private static async Task ConfigureJobs(int processingIntervalMilliseconds)
    {
        await ConfigureJob<ProcessOutboxJob>(TimeSpan.FromMilliseconds(processingIntervalMilliseconds));

        await ConfigureJob<ProcessInternalCommandsSequentiallyJob>(
            TimeSpan.FromMilliseconds(processingIntervalMilliseconds));

    }

    private static Task ConfigureJob<TJob>(TimeSpan interval)
        where TJob : IJob
    {
        var trigger = TriggerBuilder
            .Create()
            .StartNow()
            .WithSimpleSchedule(s => s
                .WithInterval(interval)
                .RepeatForever())
            .Build();

        return ConfigureJob<TJob>(trigger);
    }

    private static Task ConfigureJob<TJob>(string cronSchedule)
        where TJob : IJob
    {
        var trigger = TriggerBuilder
            .Create()
            .StartNow()
            .WithCronSchedule(cronSchedule)
            .Build();

        return ConfigureJob<TJob>(trigger);
    }

    private static async Task ConfigureJob<TJob>(ITrigger trigger)
        where TJob : IJob
    {
        var job = JobBuilder.Create<TJob>().Build();

        if (_scheduler is null)
        {
            throw new InvalidOperationException("The scheduler is not initialized.");
        }

        await _scheduler.ScheduleJob(job, trigger);
    }
}