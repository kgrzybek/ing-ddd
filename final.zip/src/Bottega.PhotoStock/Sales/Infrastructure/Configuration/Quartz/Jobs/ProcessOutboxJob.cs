using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.Outbox;
using Quartz;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Quartz.Jobs;

[DisallowConcurrentExecution]
internal class ProcessOutboxJob : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        await CommandExecutor.Execute(new ProcessOutboxCommand(), context.CancellationToken);
    }
}