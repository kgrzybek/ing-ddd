﻿using Autofac;
using Bottega.PhotoStock.Availability.Application;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.Sales.Application.Orders;
using Bottega.PhotoStock.Sales.Infrastructure.Reservations;
using Module = Autofac.Module;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Reservations;
    
public class ReservationsModule : Module
{
    private readonly IReservationsService? _reservationsService;

    public ReservationsModule(IReservationsService? reservationsService)
    {
        _reservationsService = reservationsService;
    }

    protected override void Load(ContainerBuilder builder)
    {
        if (_reservationsService != null)
        {
            builder.RegisterInstance(_reservationsService);
        }
        else
        {
            builder.RegisterScope<AvailabilityGateway, IReservationsService>();
            builder.RegisterScope<AvailabilityModule, IAvailabilityModule>();
        }
    }
}
