using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.InternalCommands;

public class ProcessInternalCommandsSequentiallyCommand : CommandBase
{
}