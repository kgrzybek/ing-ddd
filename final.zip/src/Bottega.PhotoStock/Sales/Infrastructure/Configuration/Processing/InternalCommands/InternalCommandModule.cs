using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.InternalCommands;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.InternalCommands;

internal class InternalCommandModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        var internalCommands = InternalCommandsMap.GetMapping();
        TypeMappingGuard.CheckMappings(
            Availability.Infrastructure.Configuration.Assemblies.Application, 
            typeof(IEnqueueableCommand), 
            internalCommands);
        
        builder.RegisterType<InternalCommandsMapper>()
            .As<IInternalCommandsMapper>()
            .WithParameter("internalCommandsMap", internalCommands)
            .SingleInstance();
    }
}