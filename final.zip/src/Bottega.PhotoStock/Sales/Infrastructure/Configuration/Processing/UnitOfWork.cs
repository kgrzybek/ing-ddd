using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing;

public class UnitOfWork : IUnitOfWork
{
    private readonly DbContext _context;

    private readonly IDomainEventsDispatcher _domainEventsDispatcher;

    public UnitOfWork(
        DbContext context,
        IDomainEventsDispatcher domainEventsDispatcher)
    {
        _context = context;
        _domainEventsDispatcher = domainEventsDispatcher;
    }
    
    public async Task<int> CommitAsync(CancellationToken cancellationToken)
    {
        await _domainEventsDispatcher.DispatchEventsAsync(cancellationToken);
        IncreaseChangedAggregateVersions();

        var result = await _context.SaveChangesAsync(cancellationToken);

        return result;
    }

    private void IncreaseChangedAggregateVersions()
    {
        var aggregates = _context.ChangeTracker
            .Entries<AggregateRootBase>()
            .Where(x => x.Entity.DomainEvents.Any())
            .Select(x => x.Entity).ToList();

        foreach (var entity in aggregates)
        {
            entity.IncreaseVersion();
        }
    }
}