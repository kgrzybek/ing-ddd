using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Database;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.DataAccess;
using Dapper;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.Outbox;

internal class ProcessOutboxCommandHandler : ICommandHandler<ProcessOutboxCommand>
{
    private readonly IDomainNotificationsMapper _domainNotificationsMapper;
    private readonly IDbConnectionFactory _sqlConnectionFactory;

    public ProcessOutboxCommandHandler(
        IDomainNotificationsMapper domainNotificationsMapper,
        IDbConnectionFactory sqlConnectionFactory)
    {
        _domainNotificationsMapper = domainNotificationsMapper;
        _sqlConnectionFactory = sqlConnectionFactory;
    }

    public async Task<Unit> Handle(ProcessOutboxCommand command, CancellationToken cancellationToken)
    {
        await using var scope = SalesCompositionRoot.BeginLifetimeScope();
        var context = scope.Resolve<SalesContext>();
        
        var messages = context.OutboxMessages
            .Where(o => o.StartProcessedAt == null)
            .OrderBy(o => o.OccurredAt)
            .Take(2000)
            .AsNoTracking()
            .ToList();

        if (!messages.Any())
        {
            return Unit.Value;
        }
        
        foreach (var message in messages)
        {
            try
            {
                await using var innerScope = scope.BeginLifetimeScope();
                var mediator = innerScope.Resolve<IMediator>();
                var unitOfWork = innerScope.Resolve<IUnitOfWork>();
                var innerContext = innerScope.Resolve<SalesContext>();

                innerContext.OutboxMessages.Attach(message);
                
                message.SetAsProcessing(DateTime.Now);
                await HandleMessage(message, mediator, cancellationToken);
                message.SetAsProcessed(DateTime.Now);
            
                await unitOfWork.CommitAsync(cancellationToken);
            }
            catch (Exception exc)
            {
                message.SetAsProcessedWithError(DateTime.Now, exc.ToString());
            
                using var connection = _sqlConnectionFactory.GetOpenConnection();
                await connection.ExecuteAsync(
                    @"UPDATE sales.outbox_messages
                        SET
                            start_processed_at = :startProcessedAt,
                            finish_processed_at = :finishProcessedAt,
                            error = :error
                        WHERE id = :id",
                    new
                    {
                        id = message.Id,
                        startProcessedAt = message.StartProcessedAt,
                        finishProcessedAt = message.FinishProcessedAt,
                        error = message.Error
                    });
            }
        }
        
        return Unit.Value;
    }
    
    private async Task HandleMessage(
        OutboxMessage message,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var type = _domainNotificationsMapper.GetType(message.Type);
        var @event = Deserializer.Deserialize(message.Data, type);
            
        if (@event is not IDomainEventNotification)
        {
            throw new InvalidOperationException($"Event of type {type.Name} is not a {nameof(IDomainEventNotification)}.");
        }
                
        await mediator.Publish(@event, cancellationToken);
    }
}