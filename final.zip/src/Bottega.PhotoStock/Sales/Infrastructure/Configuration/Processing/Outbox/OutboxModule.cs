using Autofac;
using Bottega.PhotoStock.BuildingBlocks.Application.Notifications;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.DomainEventsDispatching;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Outbox;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.Outbox;

public class OutboxModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        var domainNotificationMapping = DomainNotificationsMap.GetMapping();
        TypeMappingGuard.CheckMappings(Assemblies.Application, typeof(IDomainEventNotification), domainNotificationMapping);
        
        builder.RegisterScope<DbOutbox, IOutbox>();
        builder.RegisterScope<DomainEventNotificationsDispatcher, IDomainEventNotificationsDispatcher>();
        
        builder.RegisterType<DomainNotificationsMapper>()
            .As<IDomainNotificationsMapper>()
            .WithParameter("domainNotificationsMap", domainNotificationMapping)
            .SingleInstance();
    }
}