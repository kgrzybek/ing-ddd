using Bottega.PhotoStock.BuildingBlocks.Application.Commands;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.Outbox;

public class ProcessOutboxCommand : CommandBase
{
}