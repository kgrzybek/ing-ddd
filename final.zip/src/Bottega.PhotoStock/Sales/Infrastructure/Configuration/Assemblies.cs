using System.Reflection;
using Bottega.PhotoStock.Sales.Application;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration;

public static class Assemblies
{
    public static readonly Assembly Application = typeof(ISalesModule).Assembly;
    public static readonly Assembly Infrastructure = typeof(SalesModule).Assembly;
}