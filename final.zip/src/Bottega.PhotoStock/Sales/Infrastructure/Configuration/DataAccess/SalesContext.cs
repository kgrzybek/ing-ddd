using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.Outbox;
using Bottega.PhotoStock.Sales.Domain.Orders;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Microsoft.EntityFrameworkCore;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.DataAccess;

public class SalesContext :
    DbContext, IDbContextWithOutboxMessages, IDbContextWithInternalCommands
{
    public DbSet<Order> Orders { get; set; }
    
    public DbSet<DiscountConfiguration> DiscountConfigurations { get; set; }
    
    public DbSet<OutboxMessage> OutboxMessages { get; set; }
    
    public DbSet<InternalCommand> InternalCommands { get; set; }
    
#pragma warning disable CS8618
    public SalesContext(DbContextOptions<SalesContext> options)
        : base(options)
#pragma warning restore CS8618
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // optionsBuilder.UseLoggerFactory(_loggerFactory);
        // optionsBuilder.EnableDetailedErrors();
        // optionsBuilder.EnableSensitiveDataLogging();
    } 
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("sales");
        modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
    }
}