using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.Sales.Application.Orders.CreateOrder;
using Bottega.PhotoStock.Sales.Application.Orders.CreateOrder.OrderCreated;
using Bottega.PhotoStock.Sales.Application.Orders.OrderPaid;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Outbox;

internal static class DomainNotificationsMap
{
    public static BiDictionary<string, Type> GetMapping()
    {
        var mapping = new BiDictionary<string, Type>
        {
            { "OrderCreated", typeof(OrderCreatedNotification) },
            { "OrderPaid", typeof(OrderPaidNotification) }
        };

        return mapping;
    }
}