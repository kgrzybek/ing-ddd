using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.Sales.Application.Orders.PayForOrder;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.InternalCommands;

internal static class InternalCommandsMap
{
    public static BiDictionary<string, Type> GetMapping()
    {
        var mapping = new BiDictionary<string, Type>()
        {
            { "PayForOrder", typeof(PayForOrderCommand) },
        };

        return mapping;
    }
}