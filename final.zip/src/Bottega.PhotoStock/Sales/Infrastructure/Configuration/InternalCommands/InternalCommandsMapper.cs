using Bottega.PhotoStock.BuildingBlocks.Infrastructure;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.InternalCommands;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.InternalCommands;

public class InternalCommandsMapper : IInternalCommandsMapper
{
    private readonly BiDictionary<string, Type> _internalCommandsMap;

    public InternalCommandsMapper(BiDictionary<string, Type> internalCommandsMap)
    {
        _internalCommandsMap = internalCommandsMap;
    }

    public string GetName(Type type)
    {
        return _internalCommandsMap.GetBySecond(type);
    }

    public Type GetType(string name)
    {
        return _internalCommandsMap.GetByFirst(name);
    }

    public string? TryGetName(Type type)
    {
        return _internalCommandsMap.TryGetBySecond(type, out var name) ? name : null;
    }

    public Type? TryGetType(string name)
    {
        return _internalCommandsMap.TryGetByFirst(name, out var type) ? type : null;
    }
}