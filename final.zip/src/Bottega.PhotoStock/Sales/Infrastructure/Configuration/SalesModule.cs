﻿using Bottega.PhotoStock.BuildingBlocks.Application.Commands;
using Bottega.PhotoStock.BuildingBlocks.Application.Queries;
using Bottega.PhotoStock.Sales.Application;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration;

public class SalesModule : ISalesModule
{
    public async Task ExecuteCommand(ICommand command, CancellationToken cancellationToken = default)
    {
        await CommandExecutor.Execute(command, cancellationToken);
    }

    public async Task<TResult> ExecuteCommand<TResult>(
        ICommand<TResult> command, CancellationToken cancellationToken = default)
    {
        return await CommandExecutor.Execute(command, cancellationToken);
    }

    public async Task<TResult> ExecuteQuery<TResult>(
        IQuery<TResult> query, CancellationToken cancellationToken = default)
    {
        return await QueryExecutor.ExecuteQueryAsync(query, cancellationToken);
    }
}