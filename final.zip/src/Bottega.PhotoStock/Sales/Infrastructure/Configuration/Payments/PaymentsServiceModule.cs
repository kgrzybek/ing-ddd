﻿using Autofac;
using Bottega.PhotoStock.Availability.Application;
using Bottega.PhotoStock.Availability.Infrastructure.Configuration;
using Bottega.PhotoStock.BuildingBlocks.Infrastructure.IoC;
using Bottega.PhotoStock.Payments.Application;
using Bottega.PhotoStock.Payments.Infrastructure.Configuration;
using Bottega.PhotoStock.Sales.Application.Orders;
using Bottega.PhotoStock.Sales.Infrastructure.Payments;
using Bottega.PhotoStock.Sales.Infrastructure.Reservations;
using Module = Autofac.Module;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration.Payments;
    
public class PaymentsServiceModule : Module
{
    private readonly IPaymentService? _paymentService;

    public PaymentsServiceModule(IPaymentService? paymentService)
    {
        _paymentService = paymentService;
    }

    protected override void Load(ContainerBuilder builder)
    {
        if (_paymentService != null)
        {
            builder.RegisterInstance(_paymentService);
        }
        else
        {
            builder.RegisterScope<PaymentsGateway, IPaymentService>();
            builder.RegisterScope<PaymentsModule, IPaymentsModule>();
        }
    }
}
