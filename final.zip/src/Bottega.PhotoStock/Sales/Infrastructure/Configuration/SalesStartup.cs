﻿using Autofac;
using Bottega.PhotoStock.Sales.Application.Orders;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.DataAccess;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Mediation;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Payments;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.InternalCommands;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Processing.Outbox;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Quartz;
using Bottega.PhotoStock.Sales.Infrastructure.Configuration.Reservations;

namespace Bottega.PhotoStock.Sales.Infrastructure.Configuration;

public static class SalesStartup
{
    private static IContainer? _container;

    public static async Task Initialize(
        string connectionString,
        IReservationsService? reservationsService,
        IPaymentService? paymentService,
        int processingIntervalMilliseconds,
        bool runQuartz = true)
    {
        ConfigureCompositionRoot(
            connectionString,
            reservationsService,
            paymentService);

        if (runQuartz)
        {
            await QuartzStartup.Initialize(processingIntervalMilliseconds);
        }
    }

    private static void ConfigureCompositionRoot(
        string connectionString,
        IReservationsService? reservationsService,
        IPaymentService? paymentService)
    {
        var containerBuilder = new ContainerBuilder();
        
        containerBuilder.RegisterModule(new DataAccessModule(connectionString));
        containerBuilder.RegisterModule(new MediatorModule());
        containerBuilder.RegisterModule(new ReservationsModule(reservationsService));
        containerBuilder.RegisterModule(new PaymentsServiceModule(paymentService));
        containerBuilder.RegisterModule(new OutboxModule());
        containerBuilder.RegisterModule(new ProcessingModule());
        containerBuilder.RegisterModule(new InternalCommandModule());

        _container = containerBuilder.Build();

       SalesCompositionRoot.SetContainer(_container);
    }
    
    public static async Task Stop()
    {
        await QuartzStartup.StopQuartz();
    }
}