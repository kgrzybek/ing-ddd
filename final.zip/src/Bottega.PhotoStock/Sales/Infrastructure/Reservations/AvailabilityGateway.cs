﻿using Bottega.PhotoStock.Availability.Application;
using Bottega.PhotoStock.Availability.Application.Resources.BlockPermanently;
using Bottega.PhotoStock.Sales.Application.Orders;

namespace Bottega.PhotoStock.Sales.Infrastructure.Reservations;

public class AvailabilityGateway : IReservationsService
{
    private readonly IAvailabilityModule _availabilityModule;

    public AvailabilityGateway(IAvailabilityModule availabilityModule)
    {
        _availabilityModule = availabilityModule;
    }

    public async Task Reserve(List<Guid> productIds, Guid customerId)
    {
        // Model adaptation
        foreach (var productId in productIds)
        {
            // Model translation
            var resourceId = productId;
            var ownerId = customerId;

            await _availabilityModule.ExecuteCommand(new BlockPermanentlyCommand(resourceId, ownerId));
        }
    }
}