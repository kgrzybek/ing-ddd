﻿using Bottega.PhotoStock.Payments.Application;
using Bottega.PhotoStock.Payments.Application.Wallets.Pay;
using Bottega.PhotoStock.Sales.Application.Orders;

namespace Bottega.PhotoStock.Sales.Infrastructure.Payments;

public class PaymentsGateway : IPaymentService
{
    private readonly IPaymentsModule _paymentsModule;

    public PaymentsGateway(IPaymentsModule paymentsModule)
    {
        _paymentsModule = paymentsModule;
    }

    public async Task Pay(Guid customerId, decimal amount)
    {
        var payerId = customerId;
        await _paymentsModule.ExecuteCommand(new PayCommand(payerId, amount));
    }
}