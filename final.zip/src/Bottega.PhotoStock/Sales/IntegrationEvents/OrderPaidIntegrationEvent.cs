﻿using Bottega.PhotoStock.BuildingBlocks.Application.Integration;

namespace Bottega.PhotoStock.Sales.IntegrationEvents;

public class OrderPaidIntegrationEvent : IntegrationEvent
{
    public Guid OrderId { get; }
    
    public Guid CustomerId { get; }
    
    public decimal Amount { get; }
    
    public string CurrencyCode { get; }
    
    public OrderPaidIntegrationEvent(
        Guid id,
        DateTime occurredOn,
        Guid orderId,
        Guid customerId,
        decimal amount,
        string currencyCode) : base(id, occurredOn)
    {
        OrderId = orderId;
        Amount = amount;
        CurrencyCode = currencyCode;
        CustomerId = customerId;
    }
}