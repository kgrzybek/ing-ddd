CREATE TABLE sales.outbox_messages (
    id UUID,
    occurred_at TIMESTAMP NOT NULL,
    type VARCHAR(100) NOT NULL,
    data TEXT NOT NULL,
    start_processed_at TIMESTAMP NULL,
    finish_processed_at TIMESTAMP NULL, 
    error TEXT NULL,
    CONSTRAINT pk_sales_outbox_messages_id PRIMARY KEY (id)
);