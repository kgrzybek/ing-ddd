CREATE TABLE sales.discount_configurations (
   id UUID NOT NULL,
   configuration_code VARCHAR(50) NOT NULL,
   same_products_number INTEGER NOT NULL,
   percentage_total_orders DECIMAL(18, 4) NOT NULL,
   same_products_percentage DECIMAL(18, 4) NOT NULL,
   CONSTRAINT pk_sales_discount_configurations_id PRIMARY KEY (id)
);