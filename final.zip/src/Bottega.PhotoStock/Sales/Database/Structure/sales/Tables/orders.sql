CREATE TABLE sales.orders (
    id UUID NOT NULL,
    customer_id UUID NOT NULL,
    before_discount_value DECIMAL(18, 2) NOT NULL,
    before_discount_currency VARCHAR(20) NOT NULL,
    discount_value DECIMAL(18, 2) NOT NULL,
    discount_currency VARCHAR(20) NOT NULL,
    after_discount_value DECIMAL(18, 2) NOT NULL,
    after_discount_currency VARCHAR(20) NOT NULL,
    status_code VARCHAR(20) NOT NULL,
    CONSTRAINT pk_sales_orders_id PRIMARY KEY (id)
);