CREATE SCHEMA IF NOT EXISTS sales AUTHORIZATION "SYSTEM";

DROP TABLE IF EXISTS sales.discount_configurations;
CREATE TABLE sales.discount_configurations (
   id UUID NOT NULL,
   configuration_code VARCHAR(50) NOT NULL,
   same_products_number INTEGER NOT NULL,
   percentage_total_orders DECIMAL(18, 4) NOT NULL,
   same_products_percentage DECIMAL(18, 4) NOT NULL,
   CONSTRAINT pk_sales_discount_configurations_id PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sales.internal_commands;
CREATE TABLE sales.internal_commands (
    id UUID NOT NULL,
    enqueue_date TIMESTAMP NOT NULL,
    type VARCHAR(100) NOT NULL,
    data TEXT NOT NULL,
    start_processed_at TIMESTAMP NULL,
    finish_processed_at TIMESTAMP NULL,
    error TEXT,
    CONSTRAINT pk_sales_internal_commands_id PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sales.orders;
CREATE TABLE sales.orders (
    id UUID NOT NULL,
    customer_id UUID NOT NULL,
    before_discount_value DECIMAL(18, 2) NOT NULL,
    before_discount_currency VARCHAR(20) NOT NULL,
    discount_value DECIMAL(18, 2) NOT NULL,
    discount_currency VARCHAR(20) NOT NULL,
    after_discount_value DECIMAL(18, 2) NOT NULL,
    after_discount_currency VARCHAR(20) NOT NULL,
    status_code VARCHAR(20) NOT NULL,
    CONSTRAINT pk_sales_orders_id PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sales.outbox_messages;
CREATE TABLE sales.outbox_messages (
    id UUID,
    occurred_at TIMESTAMP NOT NULL,
    type VARCHAR(100) NOT NULL,
    data TEXT NOT NULL,
    start_processed_at TIMESTAMP NULL,
    finish_processed_at TIMESTAMP NULL, 
    error TEXT NULL,
    CONSTRAINT pk_sales_outbox_messages_id PRIMARY KEY (id)
);