﻿namespace Bottega.PhotoStock.Sales.Domain.Orders;

public record OrderStatus(string Code)
{
    public static OrderStatus WaitingForPayment => new OrderStatus(nameof(WaitingForPayment));
    
    public static OrderStatus Paid => new OrderStatus(nameof(Paid));
}