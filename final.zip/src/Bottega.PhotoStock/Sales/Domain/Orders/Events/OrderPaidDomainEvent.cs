﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Sales.Domain.Orders.Events;

public class OrderPaidDomainEvent : DomainEventBase
{
    public OrderPaidDomainEvent(Guid orderId, Guid customerId, decimal amount, string currencyCode)
    {
        OrderId = orderId;
        Amount = amount;
        CurrencyCode = currencyCode;
        CustomerId = customerId;
    }

    public Guid OrderId { get; }
    
    public Guid CustomerId { get; }
    
    public decimal Amount { get; }
    
    public string CurrencyCode { get; }
}