﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Sales.Domain.Orders.Events;

public class OrderCreatedDomainEvent : DomainEventBase
{
    public OrderCreatedDomainEvent(
        Guid customerId,
        decimal beforeDiscountValue,
        decimal discountValue,
        decimal afterDiscountValue,
        Guid orderId)
    {
        CustomerId = customerId;
        BeforeDiscountValue = beforeDiscountValue;
        DiscountValue = discountValue;
        AfterDiscountValue = afterDiscountValue;
        OrderId = orderId;
    }

    public Guid CustomerId { get; }
    
    public decimal BeforeDiscountValue { get; }
    
    public decimal DiscountValue { get; }
    
    public decimal AfterDiscountValue { get; }
    
    public Guid OrderId { get; }
}