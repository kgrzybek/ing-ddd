﻿namespace Bottega.PhotoStock.Sales.Domain.Orders;

internal static class OrderCalculator
{
    internal static Money CalculateBeforeDiscountValue(List<OrderLine> orderLines)
    {
        return orderLines.Select(x => x.Quantity * x.UnitPrice).Sum();
    }
}