namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public class PercentageOfTotalValueDiscountPolicy : IDiscountPolicy
{
    private readonly Percentage _percentage;

    public PercentageOfTotalValueDiscountPolicy(Percentage percentage)
    {
        _percentage = percentage;
    }

    public Money Calculate(List<OrderLine> orderLines)
    {
        var total = OrderCalculator.CalculateBeforeDiscountValue(orderLines);

        return _percentage * total;
    }
}