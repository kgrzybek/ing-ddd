namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public class SameProductDiscountPolicy : IDiscountPolicy
{
    private readonly int _numberOfProduct;

    private readonly Percentage _discount;

    public SameProductDiscountPolicy(int numberOfProduct, Percentage discount)
    {
        _numberOfProduct = numberOfProduct;
        _discount = discount;
    }

    public Money Calculate(List<OrderLine> orderLines)
    {
        var totalDiscount = Money.Of(0);
        foreach (var orderLine in orderLines)
        {
            for (int i = 1; i <= orderLine.Quantity; i++)
            {
                if (i % _numberOfProduct == 0)
                {
                    totalDiscount += _discount * orderLine.UnitPrice;
                }
            }
        }

        return totalDiscount;
    }
}