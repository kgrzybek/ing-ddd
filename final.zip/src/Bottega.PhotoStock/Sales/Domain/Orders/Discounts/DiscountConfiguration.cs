﻿namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public class DiscountConfiguration
{
    public Guid Id { get; private set; }

    private DiscountPolicyConfiguration _configuration;

    private int _sameProductsNumber;

    private Percentage _sameProductsPercentage;
    
    private Percentage _percentageOfTotalValue;

    private DiscountConfiguration()
    {
        // Only EF.
    }

    private DiscountConfiguration(
        DiscountPolicyConfiguration configuration,
        int sameProductsNumber,
        Percentage sameProductsPercentage,
        Percentage percentageOfTotalValue)
    {
        _configuration = configuration;
        _sameProductsNumber = sameProductsNumber;
        _sameProductsPercentage = sameProductsPercentage;
        _percentageOfTotalValue = percentageOfTotalValue;
    }

    public static DiscountConfiguration Create(
        DiscountPolicyConfiguration configuration,
        int sameProductsNumber,
        Percentage sameProductsPercentage,
        Percentage percentageOfTotalValue)
    {
        return new DiscountConfiguration(configuration, sameProductsNumber, sameProductsPercentage, percentageOfTotalValue);
    }
}