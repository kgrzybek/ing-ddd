﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public interface IDiscountConfigurationRepository : IRepository
{
    public Task Add(DiscountConfiguration configuration);
}