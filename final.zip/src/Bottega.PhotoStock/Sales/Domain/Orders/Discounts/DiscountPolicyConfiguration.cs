﻿namespace Bottega.PhotoStock.Sales.Domain.Orders.Discounts;

public record DiscountPolicyConfiguration(string Code)
{
    public static DiscountPolicyConfiguration SameProduct => new DiscountPolicyConfiguration(nameof(SameProduct));
    
    public static DiscountPolicyConfiguration PercentageOfTotalValue => new DiscountPolicyConfiguration(nameof(PercentageOfTotalValue));
    
    public static DiscountPolicyConfiguration NoDiscount => new DiscountPolicyConfiguration(nameof(NoDiscount));

    public static DiscountPolicyConfiguration OfCode(string code) => new DiscountPolicyConfiguration(code);
}