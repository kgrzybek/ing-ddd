﻿using Bottega.PhotoStock.BuildingBlocks.Domain;

namespace Bottega.PhotoStock.Sales.Domain.Orders;

public interface IOrderRepository : IRepository
{
    public Task Add(Order order);

    public ValueTask<Order?> GetById(Guid orderId);
}