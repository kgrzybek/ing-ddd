﻿using Bottega.PhotoStock.BuildingBlocks.Domain;
using Bottega.PhotoStock.Sales.Domain.Orders.Discounts;
using Bottega.PhotoStock.Sales.Domain.Orders.Events;

namespace Bottega.PhotoStock.Sales.Domain.Orders;

public class Order : Entity
{
    public Guid Id { get; private set; }

    private Order()
    {
        // Only EF.
    }
    
    private Order(Guid customerId,
        Money beforeDiscountValue,
        Money discount,
        Money afterDiscountValue,
        OrderStatus orderStatus)
    {
        Id = Guid.NewGuid();
        _customerId = customerId;
        _discount = discount;
        _beforeDiscountValue = beforeDiscountValue;
        _afterDiscountValue = afterDiscountValue;
        _orderStatus = orderStatus;

        this.AddDomainEvent(new OrderCreatedDomainEvent(
            _customerId,
            _beforeDiscountValue.Amount, 
            _discount.Amount,
            _afterDiscountValue.Amount,
            Id
            ));
    }

    private Guid _customerId;

    private Money _discount;

    private Money _beforeDiscountValue;

    private Money _afterDiscountValue;

    private OrderStatus _orderStatus;

    public static Order Create(
        Guid customerId,
        IDiscountPolicy discountPolicy,
        List<OrderLine> orderLines)
    {
        var beforeDiscountValue = OrderCalculator.CalculateBeforeDiscountValue(orderLines);
        var discount = discountPolicy.Calculate(orderLines);
        var afterDiscountValue = beforeDiscountValue - discount;
        
        return new Order(
            customerId,
            beforeDiscountValue,
            discount,
            afterDiscountValue,
            OrderStatus.WaitingForPayment);
    }

    public void MarkAsPaid()
    {
        _orderStatus = OrderStatus.Paid;
        
        this.AddDomainEvent(new OrderPaidDomainEvent(
            this.Id, 
            _customerId,
            _afterDiscountValue.Amount,
            _afterDiscountValue.CurrencyCode));
    }
}